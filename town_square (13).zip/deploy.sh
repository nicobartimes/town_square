#!/bin/bash

# Firebase deployment script for Town Square app

echo "🚀 Starting Firebase deployment..."

# Deploy Firestore rules and indexes
echo "📋 Deploying Firestore rules and indexes..."
firebase deploy --only firestore

# Deploy Storage rules
echo "📁 Deploying Storage rules..."
firebase deploy --only storage

# Build Flutter web app
echo "🔨 Building Flutter web app..."
flutter build web

# Deploy hosting (web app)
echo "🌐 Deploying web app to Firebase Hosting..."
firebase deploy --only hosting

echo "✅ Deployment completed!"
echo "🔗 Your app should be available at: https://YOUR_PROJECT_ID.web.app"