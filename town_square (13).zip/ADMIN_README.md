# Town Square Admin Panel

A comprehensive web-based admin panel for managing your Town Square news and classifieds app.

## Features

### 📊 **Dashboard Overview**
- Real-time content statistics
- Quick actions for content management
- Recent activity monitoring
- Empty database detection with sample data seeding

### 📰 **News Management** 
- Add, edit, and delete news articles
- Category filtering and search
- Content visibility controls
- Reading time calculation
- View count tracking

### 🎥 **Video News Management**
- Manage YouTube video integration
- Auto-thumbnail generation
- Duration and category management
- View analytics

### 📋 **Classifieds Management**
- **Job Listings**: Full job posting management with categories, salary ranges, and premium options
- **Business Directory**: Complete business listing with ratings, operating hours, and contact info
- **Real Estate**: Property listings with detailed specs, pricing, and image galleries  
- **Rentals**: Rental property management with furnished/unfurnished options and deposit tracking

### 📈 **Analytics & Insights**
- Content performance metrics
- Category breakdowns
- Premium vs free listing analytics
- Recent activity tracking
- Top performing content identification

### ⚙️ **Settings & Configuration**
- Account management
- Password security
- Content categories management
- Database backup and cleanup tools
- System reset capabilities (with safety confirmations)

## Getting Started

### 1. Firebase Setup
```bash
# Make sure you have Firebase configured
# The admin panel requires:
# - Firebase Authentication
# - Cloud Firestore
# - Firebase Hosting (optional)
```

### 2. Running the Admin Panel
```bash
# The admin panel is integrated into the main app
# To access it, run the admin_main.dart instead of main.dart

flutter run lib/admin/admin_main.dart
```

### 3. Initial Setup
1. **Create Admin Account**: Set up Firebase Authentication with an admin email
2. **Seed Sample Data**: Use the "Add Sample Data" button on the dashboard if starting with an empty database
3. **Configure Categories**: Customize content categories in the settings

### 4. Database Structure
The admin panel manages the following Firestore collections:
- `news_articles`: News content with categories, tags, and view tracking
- `video_news`: YouTube video integration with metadata
- `job_listings`: Job postings with categories and premium features  
- `business_listings`: Business directory with ratings and reviews
- `real_estate_listings`: Property sales with detailed specifications
- `rental_listings`: Rental properties with furnished options

## Security Features

### Authentication
- Firebase Authentication integration
- Admin-only access controls
- Session management
- Password change functionality

### Data Protection
- Firestore security rules
- Input validation and sanitization
- Safe database operations with confirmations
- Backup and recovery options

## Content Management Best Practices

### News Articles
- Use compelling headlines and clear descriptions
- Optimize images for web (recommended: 800px width)
- Add relevant tags for better searchability
- Set appropriate reading time estimates

### Video News  
- Use high-quality YouTube videos
- Ensure thumbnails are properly sized
- Add accurate duration information
- Categorize content appropriately

### Classifieds
- **Jobs**: Include salary ranges, requirements, and company information
- **Businesses**: Add operating hours, contact details, and service descriptions
- **Real Estate**: Provide detailed property specs and high-quality images
- **Rentals**: Specify furnished status, deposit amounts, and amenities

### Premium Listings
- Premium listings get enhanced visibility
- Use premium status for featured content
- Monitor premium vs free performance in analytics

## Technical Details

### Architecture
- **Frontend**: Flutter web application with Material Design 3
- **Backend**: Firebase (Authentication, Firestore, Storage)
- **State Management**: StatefulWidget with real-time Firestore streams
- **Data Validation**: Form validation with custom rules

### Performance
- Lazy loading for large datasets
- Pagination for content lists
- Optimized Firestore queries with indexes
- Image optimization recommendations

### Responsive Design
- Optimized for desktop admin use
- Navigation rail for easy section switching
- Card-based layout for content organization
- Modal dialogs for detailed editing

## Support

For issues or questions:
1. Check the Firebase console for authentication and database issues
2. Review Firestore security rules if permission errors occur
3. Use the settings panel for database maintenance and cleanup
4. Monitor analytics for unusual content performance patterns

## Updates

The admin panel supports:
- Real-time content updates
- Live statistics refresh
- Instant search and filtering
- Automatic view count tracking

---

**Note**: This admin panel is designed for content management. For user-facing features, use the main Town Square app.