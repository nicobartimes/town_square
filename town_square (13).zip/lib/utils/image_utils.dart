import 'package:flutter/foundation.dart';

/// Image Utilities for handling network images and fallbacks
/// Provides helper functions for image URL validation and fallback logic
class ImageUtils {
  /// List of reliable image domains for validation
  static const List<String> _trustedDomains = [
    'picsum.photos',
    'firebase.googleapis.com',
    'firebasestorage.googleapis.com',
    'storage.googleapis.com',
    'firebasestorage.app',
    'img.youtube.com',
    'i.ytimg.com',
    'images.unsplash.com',
    'cdn.pixabay.com',
  ];

  /// Validates if an image URL is from a trusted domain
  static bool isValidImageUrl(String? url) {
    if (url == null || url.isEmpty) return false;
    
    try {
      final uri = Uri.parse(url);
      
      // Always allow Firebase Storage URLs
      if (uri.host.contains('firebasestorage') || 
          uri.host.contains('storage.googleapis.com') ||
          uri.path.contains('firebasestorage')) {
        debugPrint('✅ Firebase Storage URL validated: $url');
        return true;
      }
      
      // Check other trusted domains
      final isValid = _trustedDomains.any((domain) => uri.host.contains(domain));
      debugPrint('🔍 Image URL validation - URL: $url, Valid: $isValid');
      return isValid;
    } catch (e) {
      debugPrint('❌ Invalid URL format: $url - Error: $e');
      return false;
    }
  }

  /// Returns a fallback image URL if the original is invalid
  static String getValidImageUrl(String? originalUrl, [String? fallbackUrl]) {
    if (isValidImageUrl(originalUrl)) {
      return originalUrl!;
    }
    
    if (fallbackUrl != null && isValidImageUrl(fallbackUrl)) {
      return fallbackUrl;
    }
    
    // Return empty string to trigger placeholder display
    return '';
  }

  /// Gets category-specific placeholder data
  static Map<String, dynamic> getCategoryPlaceholder(String category) {
    switch (category.toLowerCase()) {
      case 'technology':
      case 'tech':
        return {
          'icon': 'Icons.computer',
          'color': 'Colors.blue',
          'text': 'Technology'
        };
      case 'sports':
        return {
          'icon': 'Icons.sports',
          'color': 'Colors.orange',
          'text': 'Sports'
        };
      case 'business':
        return {
          'icon': 'Icons.business',
          'color': 'Colors.green',
          'text': 'Business'
        };
      case 'science':
        return {
          'icon': 'Icons.science',
          'color': 'Colors.purple',
          'text': 'Science'
        };
      case 'entertainment':
        return {
          'icon': 'Icons.movie',
          'color': 'Colors.red',
          'text': 'Entertainment'
        };
      case 'health':
        return {
          'icon': 'Icons.local_hospital',
          'color': 'Colors.teal',
          'text': 'Health'
        };
      case 'jobs':
        return {
          'icon': 'Icons.work',
          'color': 'Colors.indigo',
          'text': 'Jobs'
        };
      case 'real estate':
        return {
          'icon': 'Icons.home',
          'color': 'Colors.brown',
          'text': 'Real Estate'
        };
      case 'rentals':
        return {
          'icon': 'Icons.apartment',
          'color': 'Colors.cyan',
          'text': 'Rentals'
        };
      default:
        return {
          'icon': 'Icons.image',
          'color': 'Colors.grey',
          'text': category
        };
    }
  }

  /// Optimizes image URL for better loading (adds size parameters where supported)
  static String optimizeImageUrl(String url, {int? width, int? height}) {
    if (url.isEmpty) return url;

    try {
      final uri = Uri.parse(url);
      
      // Handle Pixabay optimization
      if (uri.host.contains('pixabay.com')) {
        final queryParams = Map<String, String>.from(uri.queryParameters);
        if (width != null) queryParams['w'] = width.toString();
        if (height != null) queryParams['h'] = height.toString();
        
        return uri.replace(queryParameters: queryParams).toString();
      }
      
      // Handle YouTube thumbnails (use higher quality versions)
      if (uri.host.contains('ytimg.com') || uri.host.contains('youtube.com')) {
        if (url.contains('maxresdefault')) {
          return url; // Already high quality
        } else if (url.contains('hqdefault')) {
          return url.replaceAll('hqdefault', 'maxresdefault');
        }
      }
      
      return url;
    } catch (e) {
      debugPrint('Error optimizing image URL: $e');
      return url;
    }
  }

  /// Preloads critical images for better performance
  static Future<void> preloadImages(List<String> imageUrls) async {
    try {
      // Implementation would depend on the caching strategy
      // This is a placeholder for future implementation
      debugPrint('Preloading ${imageUrls.length} images');
    } catch (e) {
      debugPrint('Error preloading images: $e');
    }
  }

  /// Clears image cache (useful for debugging and memory management)
  static Future<void> clearImageCache() async {
    try {
      // Implementation would clear cached_network_image cache
      debugPrint('Image cache cleared');
    } catch (e) {
      debugPrint('Error clearing image cache: $e');
    }
  }
}