import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';
import 'package:town_square/models/news_article.dart';
import 'package:town_square/widgets/enhanced_image_widget.dart';
import 'package:town_square/widgets/image_upload_widget.dart';
import 'package:town_square/services/image_upload_service.dart';

class AdminNewsManagement extends StatefulWidget {
  const AdminNewsManagement({super.key});

  @override
  State<AdminNewsManagement> createState() => _AdminNewsManagementState();
}

class _AdminNewsManagementState extends State<AdminNewsManagement> {
  final _searchController = TextEditingController();
  String _selectedCategory = 'All';
  bool _showActiveOnly = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'News Management',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _showAddNewsDialog(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Add News Article'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _buildFilters(),
            const SizedBox(height: 16),
            Expanded(child: _buildNewsList()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  labelText: 'Search articles...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 16),
            DropdownButton<String>(
              value: _selectedCategory,
              items: ['All', ...Categories.newsCategories]
                  .map((category) => DropdownMenuItem(
                        value: category,
                        child: Text(category),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => _selectedCategory = value ?? 'All'),
            ),
            const SizedBox(width: 16),
            Row(
              children: [
                Checkbox(
                  value: _showActiveOnly,
                  onChanged: (value) => setState(() => _showActiveOnly = value ?? false),
                ),
                const Text('Active only'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsList() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getNewsStream(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) {
          return const Center(child: Text('No news articles found'));
        }

        return ListView.separated(
          itemCount: docs.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data() as Map<String, dynamic>;
            final article = NewsArticle.fromJson({...data, 'id': doc.id});
            
            return _buildNewsCard(article);
          },
        );
      },
    );
  }

  Stream<QuerySnapshot> _getNewsStream() {
    var query = FirebaseFirestore.instance
        .collection(FirestoreCollections.newsArticles)
        .orderBy(FirestoreFields.publishedAt, descending: true);

    if (_selectedCategory != 'All') {
      query = query.where(FirestoreFields.category, isEqualTo: _selectedCategory);
    }

    if (_showActiveOnly) {
      query = query.where(FirestoreFields.isActive, isEqualTo: true);
    }

    return query.snapshots();
  }

  Widget _buildNewsCard(NewsArticle article) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: NetworkImageWithFallback(
                    imageUrl: article.imageUrl,
                    width: 80,
                    height: 60,
                    fit: BoxFit.cover,
                    fallbackIcon: Icons.article,
                    fallbackText: 'Article',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        article.title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        article.description,
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              article.category,
                              style: TextStyle(
                                fontSize: 12,
                                color: Theme.of(context).colorScheme.primary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            DateFormat('MMM dd, yyyy').format(article.publishedAt),
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            article.isActive ? Icons.visibility : Icons.visibility_off,
                            size: 16,
                            color: article.isActive ? Colors.green : Colors.grey,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleArticleAction(value, article),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit_outlined),
                          SizedBox(width: 8),
                          Text('Edit'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_status',
                      child: Row(
                        children: [
                          Icon(article.isActive ? Icons.visibility_off : Icons.visibility),
                          const SizedBox(width: 8),
                          Text(article.isActive ? 'Hide' : 'Show'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleArticleAction(String action, NewsArticle article) async {
    switch (action) {
      case 'edit':
        _showEditNewsDialog(context, article);
        break;
      case 'toggle_status':
        await _toggleArticleStatus(article);
        break;
      case 'delete':
        await _deleteArticle(article);
        break;
    }
  }

  Future<void> _toggleArticleStatus(NewsArticle article) async {
    try {
      await FirebaseFirestore.instance
          .collection(FirestoreCollections.newsArticles)
          .doc(article.id)
          .update({
        FirestoreFields.isActive: !article.isActive,
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Article ${article.isActive ? 'hidden' : 'shown'} successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating article: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteArticle(NewsArticle article) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Article'),
        content: Text('Are you sure you want to delete "${article.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await FirebaseFirestore.instance
          .collection(FirestoreCollections.newsArticles)
          .doc(article.id)
          .delete();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Article deleted successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting article: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showAddNewsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const NewsArticleDialog(),
    );
  }

  void _showEditNewsDialog(BuildContext context, NewsArticle article) {
    showDialog(
      context: context,
      builder: (context) => NewsArticleDialog(article: article),
    );
  }
}

class NewsArticleDialog extends StatefulWidget {
  final NewsArticle? article;

  const NewsArticleDialog({super.key, this.article});

  @override
  State<NewsArticleDialog> createState() => _NewsArticleDialogState();
}

class _NewsArticleDialogState extends State<NewsArticleDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _contentController = TextEditingController();
  final _authorController = TextEditingController();
  final _tagsController = TextEditingController();
  String _selectedCategory = Categories.newsCategories.first;
  String? _imageUrl;
  bool _isActive = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.article != null) {
      _titleController.text = widget.article!.title;
      _descriptionController.text = widget.article!.description;
      _contentController.text = widget.article!.content;
      _authorController.text = widget.article!.author;
      _imageUrl = widget.article!.imageUrl;
      _tagsController.text = widget.article!.tags.join(', ');
      _selectedCategory = widget.article!.category;
      _isActive = widget.article!.isActive;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _contentController.dispose();
    _authorController.dispose();
    _tagsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 800,
        height: 600,
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  widget.article == null ? 'Add News Article' : 'Edit News Article',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _titleController,
                        decoration: const InputDecoration(
                          labelText: 'Title *',
                          border: OutlineInputBorder(),
                        ),
                        maxLength: ValidationRules.maxTitleLength,
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Title is required';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _descriptionController,
                        decoration: const InputDecoration(
                          labelText: 'Description *',
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 3,
                        maxLength: ValidationRules.maxDescriptionLength,
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Description is required';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _contentController,
                        decoration: const InputDecoration(
                          labelText: 'Content *',
                          border: OutlineInputBorder(),
                          alignLabelWithHint: true,
                        ),
                        maxLines: 8,
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Content is required';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _authorController,
                              decoration: const InputDecoration(
                                labelText: 'Author *',
                                border: OutlineInputBorder(),
                              ),
                              validator: (value) {
                                if (value?.isEmpty ?? true) return 'Author is required';
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _selectedCategory,
                              decoration: const InputDecoration(
                                labelText: 'Category',
                                border: OutlineInputBorder(),
                              ),
                              items: Categories.newsCategories
                                  .map((category) => DropdownMenuItem(
                                        value: category,
                                        child: Text(category),
                                      ))
                                  .toList(),
                              onChanged: (value) => setState(() => _selectedCategory = value!),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Article Image *',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(height: 8),
                          Center(
                            child: ImageUploadWidget(
                              initialImageUrl: _imageUrl,
                              folder: ImageFolders.news,
                              fileName: 'article_${DateTime.now().millisecondsSinceEpoch}',
                              width: 300,
                              height: 200,
                              placeholder: 'Upload article image',
                              required: true,
                              onImageChanged: (url) => setState(() => _imageUrl = url),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _tagsController,
                        decoration: const InputDecoration(
                          labelText: 'Tags (comma separated)',
                          border: OutlineInputBorder(),
                          hintText: 'breaking, urgent, local',
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Checkbox(
                            value: _isActive,
                            onChanged: (value) => setState(() => _isActive = value ?? true),
                          ),
                          const Text('Active (visible to users)'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _isLoading ? null : _saveArticle,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(widget.article == null ? 'Add Article' : 'Update Article'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveArticle() async {
    if (!_formKey.currentState!.validate()) return;
    
    if (_imageUrl == null || _imageUrl!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please upload an image for the article'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final tags = _tagsController.text
          .split(',')
          .map((tag) => tag.trim())
          .where((tag) => tag.isNotEmpty)
          .toList();

      final articleData = {
        FirestoreFields.title: _titleController.text.trim(),
        FirestoreFields.description: _descriptionController.text.trim(),
        FirestoreFields.content: _contentController.text.trim(),
        FirestoreFields.author: _authorController.text.trim(),
        FirestoreFields.category: _selectedCategory,
        FirestoreFields.imageUrl: _imageUrl!,
        FirestoreFields.tags: tags,
        FirestoreFields.isActive: _isActive,
        FirestoreFields.readTime: _calculateReadTime(_contentController.text),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      };

      if (widget.article == null) {
        // Add new article
        articleData[FirestoreFields.publishedAt] = FieldValue.serverTimestamp();
        articleData[FirestoreFields.createdAt] = FieldValue.serverTimestamp();
        articleData[FirestoreFields.viewCount] = 0;

        await FirebaseFirestore.instance
            .collection(FirestoreCollections.newsArticles)
            .add(articleData);
      } else {
        // Update existing article
        await FirebaseFirestore.instance
            .collection(FirestoreCollections.newsArticles)
            .doc(widget.article!.id)
            .update(articleData);
      }

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              widget.article == null 
                  ? 'Article added successfully' 
                  : 'Article updated successfully',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving article: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  int _calculateReadTime(String content) {
    const wordsPerMinute = 200;
    final wordCount = content.split(RegExp(r'\s+')).length;
    return (wordCount / wordsPerMinute).ceil().clamp(1, double.infinity).toInt();
  }
}