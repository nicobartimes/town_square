import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

class AdminAnalytics extends StatefulWidget {
  const AdminAnalytics({super.key});

  @override
  State<AdminAnalytics> createState() => _AdminAnalyticsState();
}

class _AdminAnalyticsState extends State<AdminAnalytics> {
  Map<String, dynamic> _stats = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
  }

  Future<void> _loadAnalytics() async {
    setState(() => _isLoading = true);
    
    try {
      final results = await Future.wait([
        // Content counts
        FirebaseFirestore.instance.collection(FirestoreCollections.newsArticles).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.videoNews).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.jobListings).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.businessListings).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.realEstateListings).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.rentalListings).count().get(),
        
        // Active content
        FirebaseFirestore.instance.collection(FirestoreCollections.newsArticles)
            .where(FirestoreFields.isActive, isEqualTo: true).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.videoNews)
            .where(FirestoreFields.isActive, isEqualTo: true).count().get(),
        
        // Premium classifieds
        FirebaseFirestore.instance.collection(FirestoreCollections.jobListings)
            .where(FirestoreFields.isPremium, isEqualTo: true).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.businessListings)
            .where(FirestoreFields.isPremium, isEqualTo: true).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.realEstateListings)
            .where(FirestoreFields.isPremium, isEqualTo: true).count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.rentalListings)
            .where(FirestoreFields.isPremium, isEqualTo: true).count().get(),
            
        // Recent content (last 7 days)
        FirebaseFirestore.instance.collection(FirestoreCollections.newsArticles)
            .where(FirestoreFields.createdAt, isGreaterThan: Timestamp.fromDate(DateTime.now().subtract(const Duration(days: 7))))
            .count().get(),
        FirebaseFirestore.instance.collection(FirestoreCollections.jobListings)
            .where(FirestoreFields.createdAt, isGreaterThan: Timestamp.fromDate(DateTime.now().subtract(const Duration(days: 7))))
            .count().get(),
      ]);

      // Get top content by views
      final topNews = await FirebaseFirestore.instance
          .collection(FirestoreCollections.newsArticles)
          .orderBy(FirestoreFields.viewCount, descending: true)
          .limit(5)
          .get();
          
      final topVideos = await FirebaseFirestore.instance
          .collection(FirestoreCollections.videoNews)
          .orderBy(FirestoreFields.viewCount, descending: true)
          .limit(5)
          .get();

      // Category breakdown for jobs
      final jobCategoriesSnapshot = await FirebaseFirestore.instance
          .collection(FirestoreCollections.jobListings)
          .get();
      
      final Map<String, int> jobCategories = {};
      for (var doc in jobCategoriesSnapshot.docs) {
        final category = doc.data()[FirestoreFields.category] ?? 'Other';
        jobCategories[category] = (jobCategories[category] ?? 0) + 1;
      }

      setState(() {
        _stats = {
          // Total counts
          'total_news': results[0].count ?? 0,
          'total_videos': results[1].count ?? 0,
          'total_jobs': results[2].count ?? 0,
          'total_businesses': results[3].count ?? 0,
          'total_real_estate': results[4].count ?? 0,
          'total_rentals': results[5].count ?? 0,
          
          // Active counts
          'active_news': results[6].count ?? 0,
          'active_videos': results[7].count ?? 0,
          
          // Premium counts
          'premium_jobs': results[8].count ?? 0,
          'premium_businesses': results[9].count ?? 0,
          'premium_real_estate': results[10].count ?? 0,
          'premium_rentals': results[11].count ?? 0,
          
          // Recent additions
          'recent_news': results[12].count ?? 0,
          'recent_jobs': results[13].count ?? 0,
          
          // Top content
          'top_news': topNews.docs,
          'top_videos': topVideos.docs,
          
          // Categories
          'job_categories': jobCategories,
        };
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Analytics & Insights',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _loadAnalytics,
                icon: const Icon(Icons.refresh),
                label: const Text('Refresh'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildOverviewCards(),
          const SizedBox(height: 32),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _buildContentBreakdown()),
              const SizedBox(width: 16),
              Expanded(child: _buildRecentActivity()),
            ],
          ),
          const SizedBox(height: 32),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _buildTopContent()),
              const SizedBox(width: 16),
              Expanded(child: _buildCategoryBreakdown()),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewCards() {
    final totalContent = (_stats['total_news'] ?? 0) + 
                        (_stats['total_videos'] ?? 0) +
                        (_stats['total_jobs'] ?? 0) +
                        (_stats['total_businesses'] ?? 0) +
                        (_stats['total_real_estate'] ?? 0) +
                        (_stats['total_rentals'] ?? 0);
    
    final totalClassifieds = (_stats['total_jobs'] ?? 0) +
                           (_stats['total_businesses'] ?? 0) +
                           (_stats['total_real_estate'] ?? 0) +
                           (_stats['total_rentals'] ?? 0);
    
    final totalPremium = (_stats['premium_jobs'] ?? 0) +
                        (_stats['premium_businesses'] ?? 0) +
                        (_stats['premium_real_estate'] ?? 0) +
                        (_stats['premium_rentals'] ?? 0);

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 4,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.2,
      children: [
        _buildStatCard(
          'Total Content',
          totalContent.toString(),
          Icons.article,
          Colors.blue,
          '${_stats['recent_news'] ?? 0} new this week',
        ),
        _buildStatCard(
          'News Articles',
          (_stats['total_news'] ?? 0).toString(),
          Icons.article_outlined,
          Colors.green,
          '${_stats['active_news'] ?? 0} active',
        ),
        _buildStatCard(
          'Video News',
          (_stats['total_videos'] ?? 0).toString(),
          Icons.video_library,
          Colors.red,
          '${_stats['active_videos'] ?? 0} active',
        ),
        _buildStatCard(
          'Classifieds',
          totalClassifieds.toString(),
          Icons.business,
          Colors.orange,
          '$totalPremium premium',
        ),
      ],
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color, String subtitle) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContentBreakdown() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Content Breakdown',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            _buildBreakdownItem('News Articles', _stats['total_news'] ?? 0, Colors.blue),
            _buildBreakdownItem('Video News', _stats['total_videos'] ?? 0, Colors.red),
            _buildBreakdownItem('Job Listings', _stats['total_jobs'] ?? 0, Colors.green),
            _buildBreakdownItem('Business Listings', _stats['total_businesses'] ?? 0, Colors.orange),
            _buildBreakdownItem('Real Estate', _stats['total_real_estate'] ?? 0, Colors.purple),
            _buildBreakdownItem('Rentals', _stats['total_rentals'] ?? 0, Colors.teal),
          ],
        ),
      ),
    );
  }

  Widget _buildBreakdownItem(String label, int count, Color color) {
    final total = (_stats['total_news'] ?? 0) + 
                  (_stats['total_videos'] ?? 0) +
                  (_stats['total_jobs'] ?? 0) +
                  (_stats['total_businesses'] ?? 0) +
                  (_stats['total_real_estate'] ?? 0) +
                  (_stats['total_rentals'] ?? 0);
    
    final percentage = total > 0 ? (count / total * 100) : 0.0;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label),
              Text(
                '$count (${percentage.toStringAsFixed(1)}%)',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: total > 0 ? count / total : 0,
            backgroundColor: Colors.grey[200],
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentActivity() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recent Activity (7 days)',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            _buildActivityItem(
              'News Articles Added',
              _stats['recent_news'] ?? 0,
              Icons.article,
              Colors.blue,
            ),
            _buildActivityItem(
              'Job Listings Added',
              _stats['recent_jobs'] ?? 0,
              Icons.work,
              Colors.green,
            ),
            _buildActivityItem(
              'Premium Upgrades',
              (_stats['premium_jobs'] ?? 0) + (_stats['premium_businesses'] ?? 0),
              Icons.star,
              Colors.amber,
            ),
            _buildActivityItem(
              'Active Content',
              (_stats['active_news'] ?? 0) + (_stats['active_videos'] ?? 0),
              Icons.visibility,
              Colors.orange,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityItem(String label, int count, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: color.withValues(alpha: 0.1),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  count.toString(),
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopContent() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Top Performing Content',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Top News Articles',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 8),
            ..._buildTopContentList(_stats['top_news'] ?? [], true),
            const SizedBox(height: 16),
            Text(
              'Top Video News',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: Colors.red,
              ),
            ),
            const SizedBox(height: 8),
            ..._buildTopContentList(_stats['top_videos'] ?? [], false),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildTopContentList(List<QueryDocumentSnapshot> docs, bool isNews) {
    if (docs.isEmpty) {
      return [
        Text(
          'No content available',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Colors.grey[600],
          ),
        ),
      ];
    }

    return docs.take(3).map((doc) {
      final data = doc.data() as Map<String, dynamic>;
      final title = data[FirestoreFields.title] ?? 'No title';
      final viewCount = data[FirestoreFields.viewCount] ?? 0;
      
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Icon(
              isNews ? Icons.article : Icons.play_circle_outline,
              size: 16,
              color: isNews ? Colors.blue : Colors.red,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                title,
                style: Theme.of(context).textTheme.bodySmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              '$viewCount views',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  Widget _buildCategoryBreakdown() {
    final jobCategories = _stats['job_categories'] as Map<String, int>? ?? {};
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Job Categories Distribution',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            if (jobCategories.isEmpty)
              Text(
                'No job listings available',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey[600],
                ),
              )
            else
              ...(jobCategories.entries
                  .toList()
                  ..sort((a, b) => b.value.compareTo(a.value)))
                  .take(6)
                  .map((entry) => _buildCategoryItem(entry.key, entry.value)),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildMiniStat('Total Jobs', _stats['total_jobs'] ?? 0, Colors.blue),
                _buildMiniStat('Premium', _stats['premium_jobs'] ?? 0, Colors.amber),
                _buildMiniStat('Active', (_stats['total_jobs'] ?? 0) - 0, Colors.green),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryItem(String category, int count) {
    final totalJobs = _stats['total_jobs'] ?? 1;
    final percentage = count / totalJobs * 100;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              category,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          Container(
            width: 60,
            alignment: Alignment.centerRight,
            child: Text(
              count.toString(),
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 40,
            alignment: Alignment.centerRight,
            child: Text(
              '${percentage.toStringAsFixed(0)}%',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniStat(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}