import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';
import 'package:town_square/models/video_news.dart';
import 'package:town_square/widgets/enhanced_image_widget.dart';

class AdminVideoNewsManagement extends StatefulWidget {
  const AdminVideoNewsManagement({super.key});

  @override
  State<AdminVideoNewsManagement> createState() => _AdminVideoNewsManagementState();
}

class _AdminVideoNewsManagementState extends State<AdminVideoNewsManagement> {
  final _searchController = TextEditingController();
  String _selectedCategory = 'All';
  bool _showActiveOnly = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Video News Management',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _showAddVideoDialog(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Add Video News'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _buildFilters(),
            const SizedBox(height: 16),
            Expanded(child: _buildVideosList()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  labelText: 'Search videos...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 16),
            DropdownButton<String>(
              value: _selectedCategory,
              items: ['All', ...Categories.newsCategories]
                  .map((category) => DropdownMenuItem(
                        value: category,
                        child: Text(category),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => _selectedCategory = value ?? 'All'),
            ),
            const SizedBox(width: 16),
            Row(
              children: [
                Checkbox(
                  value: _showActiveOnly,
                  onChanged: (value) => setState(() => _showActiveOnly = value ?? false),
                ),
                const Text('Active only'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideosList() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getVideosStream(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) {
          return const Center(child: Text('No video news found'));
        }

        return ListView.separated(
          itemCount: docs.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data() as Map<String, dynamic>;
            final video = VideoNews.fromJson({...data, 'id': doc.id});
            
            return _buildVideoCard(video);
          },
        );
      },
    );
  }

  Stream<QuerySnapshot> _getVideosStream() {
    var query = FirebaseFirestore.instance
        .collection(FirestoreCollections.videoNews)
        .orderBy(FirestoreFields.publishedAt, descending: true);

    if (_selectedCategory != 'All') {
      query = query.where(FirestoreFields.category, isEqualTo: _selectedCategory);
    }

    if (_showActiveOnly) {
      query = query.where(FirestoreFields.isActive, isEqualTo: true);
    }

    return query.snapshots();
  }

  Widget _buildVideoCard(VideoNews video) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: NetworkImageWithFallback(
                        imageUrl: video.thumbnailUrl,
                        width: 120,
                        height: 80,
                        fit: BoxFit.cover,
                        fallbackIcon: Icons.video_library,
                        fallbackText: 'Video',
                      ),
                    ),
                    Positioned(
                      bottom: 4,
                      right: 4,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.8),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          video.duration,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                    const Positioned(
                      top: 50,
                      left: 50,
                      child: Icon(
                        Icons.play_circle_fill,
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        video.title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        video.description,
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.red.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              video.category,
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.red,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            DateFormat('MMM dd, yyyy').format(video.publishedAt),
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            Icons.visibility,
                            size: 14,
                            color: Colors.grey[600],
                          ),
                          const SizedBox(width: 2),
                          Text(
                            '${video.viewCount}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            video.isActive ? Icons.visibility : Icons.visibility_off,
                            size: 16,
                            color: video.isActive ? Colors.green : Colors.grey,
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Video ID: ${video.videoId}',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey[600],
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleVideoAction(value, video),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit_outlined),
                          SizedBox(width: 8),
                          Text('Edit'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_status',
                      child: Row(
                        children: [
                          Icon(video.isActive ? Icons.visibility_off : Icons.visibility),
                          const SizedBox(width: 8),
                          Text(video.isActive ? 'Hide' : 'Show'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleVideoAction(String action, VideoNews video) async {
    switch (action) {
      case 'edit':
        _showEditVideoDialog(context, video);
        break;
      case 'toggle_status':
        await _toggleVideoStatus(video);
        break;
      case 'delete':
        await _deleteVideo(video);
        break;
    }
  }

  Future<void> _toggleVideoStatus(VideoNews video) async {
    try {
      await FirebaseFirestore.instance
          .collection(FirestoreCollections.videoNews)
          .doc(video.id)
          .update({
        FirestoreFields.isActive: !video.isActive,
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Video ${video.isActive ? 'hidden' : 'shown'} successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating video: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteVideo(VideoNews video) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Video'),
        content: Text('Are you sure you want to delete "${video.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await FirebaseFirestore.instance
          .collection(FirestoreCollections.videoNews)
          .doc(video.id)
          .delete();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video deleted successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting video: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showAddVideoDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const VideoNewsDialog(),
    );
  }

  void _showEditVideoDialog(BuildContext context, VideoNews video) {
    showDialog(
      context: context,
      builder: (context) => VideoNewsDialog(video: video),
    );
  }
}

class VideoNewsDialog extends StatefulWidget {
  final VideoNews? video;

  const VideoNewsDialog({super.key, this.video});

  @override
  State<VideoNewsDialog> createState() => _VideoNewsDialogState();
}

class _VideoNewsDialogState extends State<VideoNewsDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _videoIdController = TextEditingController();
  final _durationController = TextEditingController();
  final _thumbnailController = TextEditingController();
  String _selectedCategory = Categories.newsCategories.first;
  bool _isActive = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.video != null) {
      _titleController.text = widget.video!.title;
      _descriptionController.text = widget.video!.description;
      _videoIdController.text = widget.video!.videoId;
      _durationController.text = widget.video!.duration;
      _thumbnailController.text = widget.video!.thumbnailUrl;
      _selectedCategory = widget.video!.category;
      _isActive = widget.video!.isActive;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _videoIdController.dispose();
    _durationController.dispose();
    _thumbnailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 700,
        height: 600,
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  widget.video == null ? 'Add Video News' : 'Edit Video News',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _titleController,
                        decoration: const InputDecoration(
                          labelText: 'Title *',
                          border: OutlineInputBorder(),
                        ),
                        maxLength: ValidationRules.maxTitleLength,
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Title is required';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _descriptionController,
                        decoration: const InputDecoration(
                          labelText: 'Description *',
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 3,
                        maxLength: ValidationRules.maxDescriptionLength,
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Description is required';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: TextFormField(
                              controller: _videoIdController,
                              decoration: const InputDecoration(
                                labelText: 'YouTube Video ID *',
                                border: OutlineInputBorder(),
                                hintText: 'dQw4w9WgXcQ',
                              ),
                              validator: (value) {
                                if (value?.isEmpty ?? true) return 'Video ID is required';
                                if (value!.length < 8) return 'Invalid YouTube video ID';
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: TextFormField(
                              controller: _durationController,
                              decoration: const InputDecoration(
                                labelText: 'Duration *',
                                border: OutlineInputBorder(),
                                hintText: '5:30',
                              ),
                              validator: (value) {
                                if (value?.isEmpty ?? true) return 'Duration is required';
                                if (!RegExp(r'^\d+:\d{2}$').hasMatch(value!)) {
                                  return 'Format: MM:SS';
                                }
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _selectedCategory,
                              decoration: const InputDecoration(
                                labelText: 'Category',
                                border: OutlineInputBorder(),
                              ),
                              items: Categories.newsCategories
                                  .map((category) => DropdownMenuItem(
                                        value: category,
                                        child: Text(category),
                                      ))
                                  .toList(),
                              onChanged: (value) => setState(() => _selectedCategory = value!),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _thumbnailController,
                        decoration: const InputDecoration(
                          labelText: 'Thumbnail URL *',
                          border: OutlineInputBorder(),
                          hintText: 'https://img.youtube.com/vi/VIDEO_ID/maxresdefault.jpg',
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Thumbnail URL is required';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Checkbox(
                            value: _isActive,
                            onChanged: (value) => setState(() => _isActive = value ?? true),
                          ),
                          const Text('Active (visible to users)'),
                          const Spacer(),
                          if (_videoIdController.text.isNotEmpty)
                            ElevatedButton.icon(
                              onPressed: _generateThumbnail,
                              icon: const Icon(Icons.auto_fix_high),
                              label: const Text('Auto Thumbnail'),
                            ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      if (_thumbnailController.text.isNotEmpty)
                        Container(
                          height: 120,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey[300]!),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: NetworkImageWithFallback(
                              imageUrl: _thumbnailController.text,
                              fit: BoxFit.cover,
                              fallbackIcon: Icons.video_library,
                              fallbackText: 'Invalid thumbnail URL',
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _isLoading ? null : _saveVideo,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(widget.video == null ? 'Add Video' : 'Update Video'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _generateThumbnail() {
    if (_videoIdController.text.isNotEmpty) {
      _thumbnailController.text = 
          'https://img.youtube.com/vi/${_videoIdController.text}/maxresdefault.jpg';
      setState(() {});
    }
  }

  Future<void> _saveVideo() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final videoData = {
        FirestoreFields.title: _titleController.text.trim(),
        FirestoreFields.description: _descriptionController.text.trim(),
        FirestoreFields.videoId: _videoIdController.text.trim(),
        FirestoreFields.duration: _durationController.text.trim(),
        FirestoreFields.thumbnailUrl: _thumbnailController.text.trim(),
        FirestoreFields.category: _selectedCategory,
        FirestoreFields.isActive: _isActive,
        FirestoreFields.videoUrl: 'https://www.youtube.com/watch?v=${_videoIdController.text.trim()}',
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      };

      if (widget.video == null) {
        // Add new video
        videoData[FirestoreFields.publishedAt] = FieldValue.serverTimestamp();
        videoData[FirestoreFields.createdAt] = FieldValue.serverTimestamp();
        videoData[FirestoreFields.viewCount] = 0;

        await FirebaseFirestore.instance
            .collection(FirestoreCollections.videoNews)
            .add(videoData);
      } else {
        // Update existing video
        await FirebaseFirestore.instance
            .collection(FirestoreCollections.videoNews)
            .doc(widget.video!.id)
            .update(videoData);
      }

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              widget.video == null 
                  ? 'Video added successfully' 
                  : 'Video updated successfully',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving video: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
}