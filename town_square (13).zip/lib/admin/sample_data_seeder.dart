import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

class SampleDataSeeder {
  static final _firestore = FirebaseFirestore.instance;

  static Future<bool> seedDatabase(BuildContext context) async {
    try {
      // Show loading dialog
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Seeding database with sample data...'),
            ],
          ),
        ),
      );

      // Seed data in parallel
      await Future.wait([
        _seedNewsArticles(),
        _seedVideoNews(),
        _seedJobListings(),
        _seedBusinessListings(),
        _seedRealEstateListings(),
        _seedRentalListings(),
      ]);

      // Close loading dialog
      if (context.mounted) {
        Navigator.of(context).pop();
      }

      return true;
    } catch (e) {
      // Close loading dialog if still open
      if (context.mounted) {
        Navigator.of(context).pop();
        
        // Show error dialog
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Error'),
            content: Text('Failed to seed database: $e'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
      return false;
    }
  }

  static Future<void> _seedNewsArticles() async {
    final articles = [
      {
        FirestoreFields.title: 'Breaking: Major Technology Conference Announced for 2025',
        FirestoreFields.description: 'TechWorld 2025 conference announced with focus on AI and sustainable technology.',
        FirestoreFields.content: 'The annual TechWorld conference has been announced for March 2025, featuring keynotes from industry leaders and demonstrations of cutting-edge technologies. This year\'s theme focuses on artificial intelligence, sustainable technology, and the future of work.\n\nExpected attendees include representatives from major tech companies, startups, and academic institutions. The three-day event will feature workshops, panel discussions, and networking opportunities.\n\nRegistration opens next month with early bird pricing available for the first 1000 registrants.',
        FirestoreFields.author: 'Tech Today',
        FirestoreFields.category: 'Technology',
        FirestoreFields.imageUrl: 'https://picsum.photos/800/600?random=1',
        FirestoreFields.tags: ['tech', 'conference', 'AI'],
        FirestoreFields.readTime: 3,
        FirestoreFields.viewCount: 1250,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Local Housing Market Shows Strong Growth This Quarter',
        FirestoreFields.description: 'Local real estate market grows 8% with high demand from buyers.',
        FirestoreFields.content: 'The local real estate market has demonstrated remarkable resilience and growth throughout the current quarter, with property values increasing by 8% compared to the same period last year.\n\nReal estate experts attribute this growth to several factors including low interest rates, increased demand from remote workers, and limited housing inventory. First-time homebuyers are particularly active in the market.',
        FirestoreFields.author: 'City News',
        FirestoreFields.category: 'Business',
        FirestoreFields.imageUrl: 'https://picsum.photos/800/600?random=2',
        FirestoreFields.tags: ['real estate', 'market', 'growth'],
        FirestoreFields.readTime: 4,
        FirestoreFields.viewCount: 890,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Championship Finals Draw Record Crowds',
        FirestoreFields.description: 'Championship finals breaks attendance records with thrilling overtime victory.',
        FirestoreFields.content: 'Last night\'s championship game broke attendance records with over 75,000 fans packing the stadium to witness one of the most exciting finales in recent memory.\n\nThe match went into overtime, with spectacular plays from both teams keeping fans on the edge of their seats. The winning goal came in the final minutes of extra time.',
        FirestoreFields.author: 'Sports Central',
        FirestoreFields.category: 'Sports',
        FirestoreFields.imageUrl: 'https://picsum.photos/800/600?random=3',
        FirestoreFields.tags: ['sports', 'championship', 'record'],
        FirestoreFields.readTime: 2,
        FirestoreFields.viewCount: 2100,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'New Healthcare Initiative Launched',
        FirestoreFields.description: 'City launches comprehensive healthcare program for residents.',
        FirestoreFields.content: 'The city has launched a new healthcare initiative aimed at improving access to medical services for all residents. The program includes free health screenings, mental health support, and preventive care services.\n\nThis initiative is funded through a combination of federal grants and local resources, ensuring sustainability for the next five years.',
        FirestoreFields.author: 'Health News',
        FirestoreFields.category: 'Health',
        FirestoreFields.imageUrl: 'https://picsum.photos/800/600?random=13',
        FirestoreFields.tags: ['health', 'initiative', 'community'],
        FirestoreFields.readTime: 3,
        FirestoreFields.viewCount: 1450,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Environmental Summit Addresses Climate Change',
        FirestoreFields.description: 'World leaders gather to discuss urgent climate action plans.',
        FirestoreFields.content: 'The International Environmental Summit brought together world leaders, scientists, and activists to address pressing climate change issues. Key topics included renewable energy adoption, carbon reduction strategies, and global cooperation frameworks.\n\nSeveral groundbreaking agreements were signed, including commitments to reduce carbon emissions by 50% over the next decade.',
        FirestoreFields.author: 'Green Report',
        FirestoreFields.category: 'Science',
        FirestoreFields.imageUrl: 'https://picsum.photos/800/600?random=14',
        FirestoreFields.tags: ['environment', 'climate', 'summit'],
        FirestoreFields.readTime: 5,
        FirestoreFields.viewCount: 1890,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
    ];

    final batch = _firestore.batch();
    for (final article in articles) {
      final docRef = _firestore.collection(FirestoreCollections.newsArticles).doc();
      batch.set(docRef, article);
    }
    await batch.commit();
  }

  static Future<void> _seedVideoNews() async {
    final videos = [
      {
        FirestoreFields.title: 'Climate Change Solutions: Latest Research Findings',
        FirestoreFields.description: 'Scientists present breakthrough research on renewable energy and carbon capture technologies.',
        FirestoreFields.videoId: 'c3yP9lPFKNk',
        FirestoreFields.videoUrl: 'https://www.youtube.com/watch?v=c3yP9lPFKNk',
        FirestoreFields.thumbnailUrl: 'https://img.youtube.com/vi/c3yP9lPFKNk/maxresdefault.jpg',
        FirestoreFields.duration: '8:45',
        FirestoreFields.category: 'Science',
        FirestoreFields.viewCount: 15420,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Tech Giants Announce AI Collaboration',
        FirestoreFields.description: 'Major technology companies join forces to develop responsible AI standards.',
        FirestoreFields.videoId: 'hTWKbfoikeg',
        FirestoreFields.videoUrl: 'https://www.youtube.com/watch?v=hTWKbfoikeg',
        FirestoreFields.thumbnailUrl: 'https://img.youtube.com/vi/hTWKbfoikeg/maxresdefault.jpg',
        FirestoreFields.duration: '6:22',
        FirestoreFields.category: 'Technology',
        FirestoreFields.viewCount: 28750,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Olympic Training: Behind the Scenes',
        FirestoreFields.description: 'Go behind the scenes with Olympic athletes as they prepare for the upcoming games.',
        FirestoreFields.videoId: '9bZkp7q19f0',
        FirestoreFields.videoUrl: 'https://www.youtube.com/watch?v=9bZkp7q19f0',
        FirestoreFields.thumbnailUrl: 'https://img.youtube.com/vi/9bZkp7q19f0/maxresdefault.jpg',
        FirestoreFields.duration: '12:18',
        FirestoreFields.category: 'Sports',
        FirestoreFields.viewCount: 42100,
        FirestoreFields.isActive: true,
        FirestoreFields.publishedAt: FieldValue.serverTimestamp(),
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
    ];

    final batch = _firestore.batch();
    for (final video in videos) {
      final docRef = _firestore.collection(FirestoreCollections.videoNews).doc();
      batch.set(docRef, video);
    }
    await batch.commit();
  }

  static Future<void> _seedJobListings() async {
    final jobs = [
      {
        FirestoreFields.title: 'Senior Software Engineer',
        FirestoreFields.description: 'We are seeking a Senior Software Engineer to join our dynamic team developing cutting-edge web applications.',
        FirestoreFields.company: 'TechCorp Solutions',
        FirestoreFields.location: 'San Francisco, CA',
        FirestoreFields.salary: '\$120,000 - \$150,000',
        FirestoreFields.jobType: 'Full-time',
        FirestoreFields.category: 'Technology',
        FirestoreFields.experience: '5+ years',
        FirestoreFields.requirements: ['Bachelor\'s in Computer Science', 'React/Flutter experience', 'Strong problem-solving skills'],
        FirestoreFields.benefits: ['Health insurance', 'Remote work options', '401(k) matching'],
        FirestoreFields.companyLogo: 'https://picsum.photos/200/200?random=4',
        FirestoreFields.applicationUrl: 'https://example.com/apply',
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Marketing Manager',
        FirestoreFields.description: 'Lead our marketing team in developing and executing comprehensive marketing strategies.',
        FirestoreFields.company: 'Growth Marketing Inc',
        FirestoreFields.location: 'New York, NY',
        FirestoreFields.salary: '\$80,000 - \$100,000',
        FirestoreFields.jobType: 'Full-time',
        FirestoreFields.category: 'Marketing',
        FirestoreFields.experience: '3-5 years',
        FirestoreFields.requirements: ['Bachelor\'s in Marketing', 'Digital marketing experience', 'Leadership skills'],
        FirestoreFields.benefits: ['Health insurance', 'Professional development', 'Flexible schedule'],
        FirestoreFields.companyLogo: 'https://picsum.photos/200/200?random=5',
        FirestoreFields.applicationUrl: 'https://example.com/apply',
        FirestoreFields.isPremium: false,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'UX/UI Designer',
        FirestoreFields.description: 'Join our design team to create amazing user experiences for our mobile and web applications.',
        FirestoreFields.company: 'Design Studio Pro',
        FirestoreFields.location: 'Austin, TX',
        FirestoreFields.salary: '\$75,000 - \$95,000',
        FirestoreFields.jobType: 'Full-time',
        FirestoreFields.category: 'Design',
        FirestoreFields.experience: '3+ years',
        FirestoreFields.requirements: ['Portfolio of design work', 'Figma/Sketch proficiency', 'User research experience'],
        FirestoreFields.benefits: ['Creative environment', 'Latest design tools', 'Professional development'],
        FirestoreFields.companyLogo: 'https://picsum.photos/200/200?random=15',
        FirestoreFields.applicationUrl: 'https://example.com/apply',
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
    ];

    final batch = _firestore.batch();
    for (final job in jobs) {
      final docRef = _firestore.collection(FirestoreCollections.jobListings).doc();
      batch.set(docRef, job);
    }
    await batch.commit();
  }

  static Future<void> _seedBusinessListings() async {
    final businesses = [
      {
        FirestoreFields.businessName: 'Cafe Central',
        FirestoreFields.description: 'Cozy neighborhood cafe serving artisanal coffee and fresh pastries.',
        FirestoreFields.category: 'Restaurants',
        FirestoreFields.address: '123 Main Street, Downtown',
        FirestoreFields.phone: '+1 (555) 123-4567',
        FirestoreFields.email: 'info@cafecentral.com',
        FirestoreFields.website: 'https://cafecentral.com',
        FirestoreFields.operatingHours: 'Mon-Fri: 7AM-6PM, Sat-Sun: 8AM-5PM',
        FirestoreFields.services: ['Coffee', 'Pastries', 'Light meals', 'Catering'],
        FirestoreFields.imageUrl: 'https://picsum.photos/400/300?random=6',
        FirestoreFields.rating: 4.5,
        FirestoreFields.reviewCount: 127,
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.businessName: 'Elite Fitness Gym',
        FirestoreFields.description: 'State-of-the-art fitness facility with personal training and group classes.',
        FirestoreFields.category: 'Beauty & Wellness',
        FirestoreFields.address: '456 Oak Avenue, Midtown',
        FirestoreFields.phone: '+1 (555) 987-6543',
        FirestoreFields.email: 'contact@elitefitness.com',
        FirestoreFields.website: 'https://elitefitness.com',
        FirestoreFields.operatingHours: 'Mon-Fri: 5AM-11PM, Sat-Sun: 6AM-10PM',
        FirestoreFields.services: ['Personal training', 'Group classes', 'Nutrition counseling', 'Equipment rental'],
        FirestoreFields.imageUrl: 'https://picsum.photos/400/300?random=7',
        FirestoreFields.rating: 4.2,
        FirestoreFields.reviewCount: 89,
        FirestoreFields.isPremium: false,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.businessName: 'Tech Repair Hub',
        FirestoreFields.description: 'Professional electronics repair services for phones, tablets, and laptops.',
        FirestoreFields.category: 'Services',
        FirestoreFields.address: '789 Tech Street, Innovation District',
        FirestoreFields.phone: '+1 (555) 456-7890',
        FirestoreFields.email: 'support@techrepairhub.com',
        FirestoreFields.website: 'https://techrepairhub.com',
        FirestoreFields.operatingHours: 'Mon-Sat: 9AM-7PM, Sun: Closed',
        FirestoreFields.services: ['Phone repair', 'Screen replacement', 'Data recovery', 'Hardware upgrades'],
        FirestoreFields.imageUrl: 'https://picsum.photos/400/300?random=16',
        FirestoreFields.rating: 4.8,
        FirestoreFields.reviewCount: 234,
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
    ];

    final batch = _firestore.batch();
    for (final business in businesses) {
      final docRef = _firestore.collection(FirestoreCollections.businessListings).doc();
      batch.set(docRef, business);
    }
    await batch.commit();
  }

  static Future<void> _seedRealEstateListings() async {
    final properties = [
      {
        FirestoreFields.title: 'Beautiful Family Home with Garden',
        FirestoreFields.description: 'Spacious 4-bedroom house with modern amenities and a large backyard perfect for families.',
        FirestoreFields.type: 'House',
        FirestoreFields.price: 750000.0,
        FirestoreFields.location: '789 Elm Street, Suburbia',
        FirestoreFields.bedrooms: 4,
        FirestoreFields.bathrooms: 3,
        FirestoreFields.area: 2500,
        FirestoreFields.amenities: ['Swimming pool', 'Garage', 'Garden', 'Modern kitchen'],
        FirestoreFields.contactInfo: 'Sarah Johnson - (555) 246-8135',
        FirestoreFields.images: [
          'https://picsum.photos/800/600?random=8',
          'https://picsum.photos/800/600?random=9'
        ],
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Downtown Luxury Condo',
        FirestoreFields.description: 'Modern 2-bedroom condo in the heart of downtown with city views.',
        FirestoreFields.type: 'Apartment',
        FirestoreFields.price: 450000.0,
        FirestoreFields.location: '321 City Center, Downtown',
        FirestoreFields.bedrooms: 2,
        FirestoreFields.bathrooms: 2,
        FirestoreFields.area: 1200,
        FirestoreFields.amenities: ['City views', 'Gym access', 'Concierge', 'Parking'],
        FirestoreFields.contactInfo: 'Mike Chen - (555) 369-2587',
        FirestoreFields.images: [
          'https://picsum.photos/800/600?random=10',
        ],
        FirestoreFields.isPremium: false,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Charming Victorian Townhouse',
        FirestoreFields.description: 'Historic 3-bedroom townhouse with original features and modern renovations.',
        FirestoreFields.type: 'Townhouse',
        FirestoreFields.price: 625000.0,
        FirestoreFields.location: '456 Heritage Lane, Old Town',
        FirestoreFields.bedrooms: 3,
        FirestoreFields.bathrooms: 2,
        FirestoreFields.area: 1800,
        FirestoreFields.amenities: ['Historic charm', 'Renovated kitchen', 'Original hardwood floors', 'Private patio'],
        FirestoreFields.contactInfo: 'Emma Thompson - (555) 789-1234',
        FirestoreFields.images: [
          'https://picsum.photos/800/600?random=17',
          'https://picsum.photos/800/600?random=18'
        ],
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
    ];

    final batch = _firestore.batch();
    for (final property in properties) {
      final docRef = _firestore.collection(FirestoreCollections.realEstateListings).doc();
      batch.set(docRef, property);
    }
    await batch.commit();
  }

  static Future<void> _seedRentalListings() async {
    final rentals = [
      {
        FirestoreFields.title: 'Cozy Studio Apartment',
        FirestoreFields.description: 'Perfect studio apartment for students or young professionals in a great location.',
        FirestoreFields.type: 'Studio',
        FirestoreFields.monthlyRent: 1200.0,
        FirestoreFields.deposit: 1200.0,
        FirestoreFields.location: '567 University Ave, College District',
        FirestoreFields.bedrooms: 0,
        FirestoreFields.bathrooms: 1,
        FirestoreFields.area: 500,
        FirestoreFields.furnished: true,
        FirestoreFields.amenities: ['Furnished', 'Utilities included', 'Laundry', 'Internet'],
        FirestoreFields.contactInfo: 'Lisa Rodriguez - (555) 147-2589',
        FirestoreFields.images: [
          'https://picsum.photos/600/400?random=11',
        ],
        FirestoreFields.isPremium: false,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Spacious 2BR Apartment with Balcony',
        FirestoreFields.description: 'Beautiful 2-bedroom apartment with balcony overlooking the park.',
        FirestoreFields.type: 'Apartment',
        FirestoreFields.monthlyRent: 2200.0,
        FirestoreFields.deposit: 2200.0,
        FirestoreFields.location: '890 Park View Lane, Green District',
        FirestoreFields.bedrooms: 2,
        FirestoreFields.bathrooms: 1,
        FirestoreFields.area: 900,
        FirestoreFields.furnished: false,
        FirestoreFields.amenities: ['Balcony', 'Park view', 'Parking', 'Pet-friendly'],
        FirestoreFields.contactInfo: 'David Kim - (555) 753-9514',
        FirestoreFields.images: [
          'https://picsum.photos/800/600?random=12',
        ],
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
      {
        FirestoreFields.title: 'Luxury Penthouse Suite',
        FirestoreFields.description: 'Exclusive penthouse with panoramic city views and premium amenities.',
        FirestoreFields.type: 'Penthouse',
        FirestoreFields.monthlyRent: 4500.0,
        FirestoreFields.deposit: 4500.0,
        FirestoreFields.location: '123 Skyline Tower, Financial District',
        FirestoreFields.bedrooms: 3,
        FirestoreFields.bathrooms: 3,
        FirestoreFields.area: 2000,
        FirestoreFields.furnished: true,
        FirestoreFields.amenities: ['Panoramic views', 'Rooftop access', 'Concierge service', 'Valet parking'],
        FirestoreFields.contactInfo: 'Robert Martinez - (555) 987-6543',
        FirestoreFields.images: [
          'https://picsum.photos/800/600?random=19',
          'https://picsum.photos/800/600?random=20'
        ],
        FirestoreFields.isPremium: true,
        FirestoreFields.isActive: true,
        FirestoreFields.createdAt: FieldValue.serverTimestamp(),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      },
    ];

    final batch = _firestore.batch();
    for (final rental in rentals) {
      final docRef = _firestore.collection(FirestoreCollections.rentalListings).doc();
      batch.set(docRef, rental);
    }
    await batch.commit();
  }

  static Future<bool> isDatabaseEmpty() async {
    try {
      final collections = [
        FirestoreCollections.newsArticles,
        FirestoreCollections.videoNews,
        FirestoreCollections.jobListings,
        FirestoreCollections.businessListings,
        FirestoreCollections.realEstateListings,
        FirestoreCollections.rentalListings,
      ];

      for (final collection in collections) {
        final snapshot = await _firestore.collection(collection).limit(1).get();
        if (snapshot.docs.isNotEmpty) {
          return false; // Database has data
        }
      }
      return true; // Database is empty
    } catch (e) {
      return false; // Assume not empty if error occurs
    }
  }
}