import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';
import 'package:town_square/services/image_upload_service.dart';

class AdminSettings extends StatefulWidget {
  const AdminSettings({super.key});

  @override
  State<AdminSettings> createState() => _AdminSettingsState();
}

class _AdminSettingsState extends State<AdminSettings> {
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _isChangingPassword = false;
  bool _obscureCurrentPassword = true;
  bool _obscureNewPassword = true;
  bool _obscureConfirmPassword = true;

  @override
  void dispose() {
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Settings',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          _buildAccountSection(user),
          const SizedBox(height: 32),
          _buildSecuritySection(),
          const SizedBox(height: 32),
          _buildSystemSection(),
          const SizedBox(height: 32),
          _buildDatabaseSection(),
        ],
      ),
    );
  }

  Widget _buildAccountSection(User? user) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Account Information',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.primary,
                child: Text(
                  user?.email?[0].toUpperCase() ?? 'A',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: const Text('Admin User'),
              subtitle: Text(user?.email ?? 'admin@townsquare.com'),
              trailing: const Icon(Icons.verified_user, color: Colors.green),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.login),
              title: const Text('Last Sign In'),
              subtitle: Text(
                user?.metadata.lastSignInTime != null
                    ? _formatDateTime(user!.metadata.lastSignInTime!)
                    : 'Never',
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person_add),
              title: const Text('Account Created'),
              subtitle: Text(
                user?.metadata.creationTime != null
                    ? _formatDateTime(user!.metadata.creationTime!)
                    : 'Unknown',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSecuritySection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Security',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.lock_outline),
              title: const Text('Change Password'),
              subtitle: const Text('Update your admin password'),
              trailing: ElevatedButton(
                onPressed: _showChangePasswordDialog,
                child: const Text('Change'),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.security),
              title: const Text('Two-Factor Authentication'),
              subtitle: const Text('Not configured'),
              trailing: ElevatedButton(
                onPressed: () => _showInfoDialog(
                  'Two-Factor Authentication',
                  'Two-factor authentication is not yet implemented in this admin panel. This feature will be available in future updates.',
                ),
                child: const Text('Setup'),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
              subtitle: const Text('Sign out from the admin panel'),
              trailing: ElevatedButton(
                onPressed: _signOut,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Sign Out'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'System Configuration',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.category),
              title: const Text('Content Categories'),
              subtitle: const Text('Manage news and classified categories'),
              trailing: ElevatedButton(
                onPressed: _showCategoriesDialog,
                child: const Text('Manage'),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.notifications_outlined),
              title: const Text('Push Notifications'),
              subtitle: const Text('Configure app notifications'),
              trailing: ElevatedButton(
                onPressed: () => _showInfoDialog(
                  'Push Notifications',
                  'Push notification configuration will be available once you set up Firebase Cloud Messaging (FCM) for your app.',
                ),
                child: const Text('Configure'),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.backup),
              title: const Text('Data Backup'),
              subtitle: const Text('Export and backup your data'),
              trailing: ElevatedButton(
                onPressed: _showBackupDialog,
                child: const Text('Backup'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDatabaseSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Database Management',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.data_usage),
              title: const Text('Database Status'),
              subtitle: const Text('Connected to Firestore'),
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  'Online',
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.w500,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.cloud_upload),
              title: const Text('Firebase Storage Status'),
              subtitle: const Text('Test image upload functionality'),
              trailing: ElevatedButton(
                onPressed: _testFirebaseStorage,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Test Upload'),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.cleaning_services),
              title: const Text('Clean Inactive Content'),
              subtitle: const Text('Remove old inactive content'),
              trailing: ElevatedButton(
                onPressed: _showCleanupDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Cleanup'),
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.warning, color: Colors.red),
              title: const Text('Reset Database', style: TextStyle(color: Colors.red)),
              subtitle: const Text('⚠️ This will delete all content permanently'),
              trailing: ElevatedButton(
                onPressed: _showResetDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Reset'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} at ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  void _showChangePasswordDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Change Password'),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _currentPasswordController,
                obscureText: _obscureCurrentPassword,
                decoration: InputDecoration(
                  labelText: 'Current Password',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_obscureCurrentPassword ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _obscureCurrentPassword = !_obscureCurrentPassword),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _newPasswordController,
                obscureText: _obscureNewPassword,
                decoration: InputDecoration(
                  labelText: 'New Password',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_obscureNewPassword ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _obscureNewPassword = !_obscureNewPassword),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _confirmPasswordController,
                obscureText: _obscureConfirmPassword,
                decoration: InputDecoration(
                  labelText: 'Confirm New Password',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_obscureConfirmPassword ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _obscureConfirmPassword = !_obscureConfirmPassword),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _clearPasswordFields();
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: _isChangingPassword ? null : _changePassword,
            child: _isChangingPassword
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Change Password'),
          ),
        ],
      ),
    );
  }

  Future<void> _changePassword() async {
    if (_newPasswordController.text != _confirmPasswordController.text) {
      _showErrorSnackBar('New passwords do not match');
      return;
    }

    if (_newPasswordController.text.length < 6) {
      _showErrorSnackBar('Password must be at least 6 characters long');
      return;
    }

    setState(() => _isChangingPassword = true);

    try {
      final user = FirebaseAuth.instance.currentUser!;
      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: _currentPasswordController.text,
      );

      await user.reauthenticateWithCredential(credential);
      await user.updatePassword(_newPasswordController.text);

      if (mounted) {
        Navigator.of(context).pop();
        _clearPasswordFields();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Password changed successfully')),
        );
      }
    } on FirebaseAuthException catch (e) {
      String message = 'Failed to change password';
      if (e.code == 'wrong-password') {
        message = 'Current password is incorrect';
      } else if (e.code == 'weak-password') {
        message = 'New password is too weak';
      }
      _showErrorSnackBar(message);
    } catch (e) {
      _showErrorSnackBar('An unexpected error occurred');
    } finally {
      setState(() => _isChangingPassword = false);
    }
  }

  void _clearPasswordFields() {
    _currentPasswordController.clear();
    _newPasswordController.clear();
    _confirmPasswordController.clear();
  }

  void _showErrorSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _signOut() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out of the admin panel?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await FirebaseAuth.instance.signOut();
    }
  }

  void _showInfoDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showCategoriesDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: 600,
          height: 500,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    'Content Categories',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('News Categories:', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: Categories.newsCategories.map((category) => Chip(
                          label: Text(category),
                          backgroundColor: Colors.blue.withValues(alpha: 0.1),
                        )).toList(),
                      ),
                      const SizedBox(height: 16),
                      const Text('Job Categories:', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: Categories.jobCategories.map((category) => Chip(
                          label: Text(category),
                          backgroundColor: Colors.green.withValues(alpha: 0.1),
                        )).toList(),
                      ),
                      const SizedBox(height: 16),
                      const Text('Business Categories:', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: Categories.businessCategories.map((category) => Chip(
                          label: Text(category),
                          backgroundColor: Colors.orange.withValues(alpha: 0.1),
                        )).toList(),
                      ),
                      const SizedBox(height: 16),
                      const Text('Property Types:', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [...Categories.realEstateTypes, ...Categories.rentalTypes].toSet().map((type) => Chip(
                          label: Text(type),
                          backgroundColor: Colors.purple.withValues(alpha: 0.1),
                        )).toList(),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Note: To modify categories, edit the Categories class in firestore_data_schema.dart',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showBackupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Data Backup'),
        content: const Text(
          'Data backup functionality allows you to export your content to JSON files. '
          'This feature would typically integrate with Firebase Admin SDK for full database exports.\n\n'
          'For now, individual content can be managed through the respective management sections.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showCleanupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clean Inactive Content'),
        content: const Text(
          'This will remove all content that has been inactive for more than 90 days. '
          'Are you sure you want to proceed?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _performCleanup();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
            child: const Text('Proceed'),
          ),
        ],
      ),
    );
  }

  void _showResetDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('⚠️ Reset Database'),
        content: const Text(
          'WARNING: This will permanently delete ALL content including:\n'
          '• News articles\n'
          '• Video news\n'
          '• Job listings\n'
          '• Business listings\n'
          '• Real estate listings\n'
          '• Rental listings\n\n'
          'This action cannot be undone!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _showFinalResetConfirmation();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }

  void _showFinalResetConfirmation() {
    final confirmationController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Final Confirmation'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Type "RESET DATABASE" to confirm:'),
            const SizedBox(height: 16),
            TextField(
              controller: confirmationController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'RESET DATABASE',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              confirmationController.dispose();
              Navigator.of(context).pop();
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (confirmationController.text == 'RESET DATABASE') {
                Navigator.of(context).pop();
                _performDatabaseReset();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Confirmation text does not match'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
              confirmationController.dispose();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('RESET'),
          ),
        ],
      ),
    );
  }

  Future<void> _performCleanup() async {
    try {
      final cutoffDate = Timestamp.fromDate(DateTime.now().subtract(const Duration(days: 90)));
      
      // This would typically involve batch operations
      // For demonstration, we're showing the concept
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cleanup completed successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cleanup failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _performDatabaseReset() async {
    try {
      final batch = FirebaseFirestore.instance.batch();
      
      // Get all collections
      final collections = [
        FirestoreCollections.newsArticles,
        FirestoreCollections.videoNews,
        FirestoreCollections.jobListings,
        FirestoreCollections.businessListings,
        FirestoreCollections.realEstateListings,
        FirestoreCollections.rentalListings,
      ];
      
      for (final collection in collections) {
        final snapshot = await FirebaseFirestore.instance.collection(collection).get();
        for (final doc in snapshot.docs) {
          batch.delete(doc.reference);
        }
      }
      
      await batch.commit();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Database reset completed successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Database reset failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _testFirebaseStorage() async {
    try {
      debugPrint('🔍 Starting Firebase Storage connectivity test...');
      
      final imageService = ImageUploadService();
      
      // Show loading dialog
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Testing Firebase Storage connection...'),
            ],
          ),
        ),
      );
      
      // Test storage connection
      final isConnected = await imageService.testStorageConnection();
      
      // Get storage info
      final storageInfo = await imageService.getStorageInfo();
      
      // Close loading dialog
      if (mounted) Navigator.of(context).pop();
      
      // Show results dialog
      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Row(
              children: [
                Icon(
                  isConnected ? Icons.check_circle : Icons.error,
                  color: isConnected ? Colors.green : Colors.red,
                ),
                const SizedBox(width: 8),
                Text(isConnected ? 'Storage Connected' : 'Connection Failed'),
              ],
            ),
            content: SizedBox(
              width: 400,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bucket: ${storageInfo['bucket'] ?? 'Unknown'}',
                    style: const TextStyle(fontFamily: 'monospace'),
                  ),
                  const SizedBox(height: 8),
                  if (storageInfo['folders'] != null) ...[
                    Text('Folders: ${(storageInfo['folders'] as List).length}'),
                    if ((storageInfo['folders'] as List).isNotEmpty)
                      Text('  • ${(storageInfo['folders'] as List).join(', ')}'),
                  ],
                  const SizedBox(height: 8),
                  if (storageInfo['files'] != null) ...[
                    Text('Root files: ${(storageInfo['files'] as List).length}'),
                  ],
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isConnected 
                          ? Colors.green.withValues(alpha: 0.1) 
                          : Colors.red.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      isConnected 
                          ? '✅ Firebase Storage is properly configured and ready for image uploads!' 
                          : '❌ Firebase Storage connection failed. Please check your configuration.',
                      style: TextStyle(
                        color: isConnected ? Colors.green : Colors.red,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK'),
              ),
              if (!isConnected)
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _showStorageTroubleshooting();
                  },
                  child: const Text('Troubleshoot'),
                ),
            ],
          ),
        );
      }
      
    } catch (e) {
      // Close loading dialog if still open
      if (mounted) Navigator.of(context).pop();
      
      debugPrint('❌ Firebase Storage test error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Storage test failed: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }

  void _showStorageTroubleshooting() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: 600,
          height: 500,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.help_outline, color: Colors.blue),
                  const SizedBox(width: 8),
                  const Text(
                    'Firebase Storage Troubleshooting',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Common Issues & Solutions:',
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                      ),
                      const SizedBox(height: 12),
                      
                      const Text('1. Storage Rules', style: TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 4),
                      const Text('Ensure your Firebase Storage rules allow authenticated users to upload:'),
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'allow write: if request.auth != null;',
                          style: TextStyle(fontFamily: 'monospace', fontSize: 12),
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      const Text('2. Authentication', style: TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 4),
                      const Text('Make sure you are logged in as an authenticated user before testing uploads.'),
                      
                      const SizedBox(height: 16),
                      const Text('3. Storage Bucket', style: TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 4),
                      const Text('Current bucket: f0zl2cytkqpiidwjnlqoh5jqiv3g9a.firebasestorage.app'),
                      const Text('Verify this matches your Firebase project settings.'),
                      
                      const SizedBox(height: 16),
                      const Text('4. Permissions', style: TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 4),
                      const Text('On mobile, ensure camera and storage permissions are granted.'),
                      
                      const SizedBox(height: 16),
                      const Text('5. Network Connectivity', style: TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 4),
                      const Text('Check your internet connection and Firebase project status.'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        _testFirebaseStorage();
                      },
                      child: const Text('Test Again'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Close'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}