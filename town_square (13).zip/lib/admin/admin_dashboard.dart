import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:town_square/admin_theme.dart';
import 'admin_news_management.dart';
import 'admin_video_news_management.dart';
import 'admin_classifieds_management.dart';
import 'admin_analytics.dart';
import 'admin_settings.dart';
import 'sample_data_seeder.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _selectedIndex = 0;
  late List<Widget> _pages;
  Map<String, int> _stats = {};
  bool _isLoadingStats = true;

  @override
  void initState() {
    super.initState();
    _pages = [
      DashboardOverview(stats: _stats, isLoading: _isLoadingStats),
      const AdminNewsManagement(),
      const AdminVideoNewsManagement(),
      const AdminClassifiedsManagement(),
      const AdminAnalytics(),
      const AdminSettings(),
    ];
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final results = await Future.wait([
        FirebaseFirestore.instance.collection('news_articles').count().get(),
        FirebaseFirestore.instance.collection('video_news').count().get(),
        FirebaseFirestore.instance.collection('job_listings').count().get(),
        FirebaseFirestore.instance.collection('business_listings').count().get(),
        FirebaseFirestore.instance.collection('real_estate_listings').count().get(),
        FirebaseFirestore.instance.collection('rental_listings').count().get(),
      ]);

      setState(() {
        _stats = {
          'news_articles': results[0].count ?? 0,
          'video_news': results[1].count ?? 0,
          'job_listings': results[2].count ?? 0,
          'business_listings': results[3].count ?? 0,
          'real_estate_listings': results[4].count ?? 0,
          'rental_listings': results[5].count ?? 0,
        };
        _isLoadingStats = false;
      });

      // Update the first page with new stats
      _pages[0] = DashboardOverview(stats: _stats, isLoading: _isLoadingStats);
    } catch (e) {
      setState(() => _isLoadingStats = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: adminTheme,
      child: Scaffold(
      appBar: AppBar(
        title: const Text('Town Square Admin'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadStats,
            tooltip: 'Refresh Stats',
          ),
          const SizedBox(width: 8),
          PopupMenuButton<String>(
            icon: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: Text(
                FirebaseAuth.instance.currentUser?.email?[0].toUpperCase() ?? 'A',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            onSelected: (value) {
              if (value == 'logout') {
                FirebaseAuth.instance.signOut();
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    const Icon(Icons.person_outline),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('Admin User'),
                        Text(
                          FirebaseAuth.instance.currentUser?.email ?? '',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Sign Out', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (index) => setState(() => _selectedIndex = index),
            labelType: NavigationRailLabelType.all,
            backgroundColor: AdminColors.adminSidebarBackground,
            destinations: const [
              NavigationRailDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard),
                label: Text('Dashboard'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.article_outlined),
                selectedIcon: Icon(Icons.article),
                label: Text('News'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.video_library_outlined),
                selectedIcon: Icon(Icons.video_library),
                label: Text('Video News'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.business_outlined),
                selectedIcon: Icon(Icons.business),
                label: Text('Classifieds'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.analytics_outlined),
                selectedIcon: Icon(Icons.analytics),
                label: Text('Analytics'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings),
                label: Text('Settings'),
              ),
            ],
          ),
          const VerticalDivider(thickness: 1, width: 1),
          Expanded(child: _pages[_selectedIndex]),
        ],
      ),
      ),
    );
  }
}

class DashboardOverview extends StatefulWidget {
  final Map<String, int> stats;
  final bool isLoading;

  const DashboardOverview({
    super.key,
    required this.stats,
    required this.isLoading,
  });

  @override
  State<DashboardOverview> createState() => _DashboardOverviewState();
}

class _DashboardOverviewState extends State<DashboardOverview> {

  @override
  Widget build(BuildContext context) {
    if (widget.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    final totalClassifieds = (widget.stats['job_listings'] ?? 0) +
        (widget.stats['business_listings'] ?? 0) +
        (widget.stats['real_estate_listings'] ?? 0) +
        (widget.stats['rental_listings'] ?? 0);

    final isEmpty = (widget.stats['news_articles'] ?? 0) == 0 &&
        (widget.stats['video_news'] ?? 0) == 0 &&
        totalClassifieds == 0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Dashboard Overview',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 4,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.2,
            children: [
              _buildStatCard(
                context,
                'News Articles',
                widget.stats['news_articles']?.toString() ?? '0',
                Icons.article,
                Colors.blue,
              ),
              _buildStatCard(
                context,
                'Video News',
                widget.stats['video_news']?.toString() ?? '0',
                Icons.video_library,
                Colors.red,
              ),
              _buildStatCard(
                context,
                'Total Classifieds',
                totalClassifieds.toString(),
                Icons.business,
                Colors.green,
              ),
              _buildStatCard(
                context,
                'Job Listings',
                widget.stats['job_listings']?.toString() ?? '0',
                Icons.work,
                Colors.orange,
              ),
            ],
          ),
          const SizedBox(height: 24),
          if (isEmpty) _buildEmptyDatabaseSection(),
          const SizedBox(height: 32),
          Row(
            children: [
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Quick Actions',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 16),
                        _buildQuickActionTile(
                          context,
                          'Add News Article',
                          Icons.add_circle_outline,
                          () {},
                        ),
                        _buildQuickActionTile(
                          context,
                          'Add Video News',
                          Icons.video_call_outlined,
                          () {},
                        ),
                        _buildQuickActionTile(
                          context,
                          'Manage Classifieds',
                          Icons.business_center_outlined,
                          () {},
                        ),
                        _buildQuickActionTile(
                          context,
                          'View Analytics',
                          Icons.bar_chart_outlined,
                          () {},
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Recent Activity',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 16),
                        _buildActivityItem(
                          context,
                          'News article published',
                          '2 minutes ago',
                          Icons.article,
                        ),
                        _buildActivityItem(
                          context,
                          'New job listing added',
                          '15 minutes ago',
                          Icons.work,
                        ),
                        _buildActivityItem(
                          context,
                          'Video news updated',
                          '1 hour ago',
                          Icons.video_library,
                        ),
                        _buildActivityItem(
                          context,
                          'Business listing approved',
                          '3 hours ago',
                          Icons.business,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(BuildContext context, String title, String count, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(
              count,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionTile(BuildContext context, String title, IconData icon, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
      contentPadding: EdgeInsets.zero,
    );
  }

  Widget _buildActivityItem(BuildContext context, String title, String time, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
            child: Icon(icon, size: 16, color: Theme.of(context).colorScheme.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.bodyMedium),
                Text(time, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey[600])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyDatabaseSection() {
    return Card(
      color: Colors.blue[50],
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(
              Icons.data_usage,
              size: 64,
              color: Colors.blue[600],
            ),
            const SizedBox(height: 16),
            Text(
              'Your database is empty',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.blue[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Get started by adding sample data to see how your admin panel works',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.blue[700],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _seedDatabase,
              icon: const Icon(Icons.auto_fix_high),
              label: const Text('Add Sample Data'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[600],
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => _showSeedInfo(),
              child: const Text('What data will be added?'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _seedDatabase() async {
    final success = await SampleDataSeeder.seedDatabase(context);
    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Sample data added successfully! Refresh to see the changes.'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  void _showSeedInfo() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sample Data Information'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('This will add the following sample data to your database:'),
              SizedBox(height: 12),
              Text('📰 News Articles (3 items)', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('• Technology conference announcement'),
              Text('• Real estate market growth'),
              Text('• Championship sports event'),
              SizedBox(height: 8),
              Text('🎥 Video News (3 items)', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('• Climate change research'),
              Text('• AI collaboration announcement'),
              Text('• Olympic training documentary'),
              SizedBox(height: 8),
              Text('💼 Job Listings (2 items)', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('• Senior Software Engineer'),
              Text('• Marketing Manager'),
              SizedBox(height: 8),
              Text('🏪 Business Listings (2 items)', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('• Cafe Central'),
              Text('• Elite Fitness Gym'),
              SizedBox(height: 8),
              Text('🏠 Real Estate (2 items)', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('• Family home with garden'),
              Text('• Downtown luxury condo'),
              SizedBox(height: 8),
              Text('🏡 Rentals (2 items)', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('• Cozy studio apartment'),
              Text('• 2BR apartment with balcony'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}