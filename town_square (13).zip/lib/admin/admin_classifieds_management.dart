import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';
import 'package:town_square/widgets/enhanced_image_widget.dart';
import 'package:town_square/widgets/image_upload_widget.dart';
import 'package:town_square/services/image_upload_service.dart';

class AdminClassifiedsManagement extends StatefulWidget {
  const AdminClassifiedsManagement({super.key});

  @override
  State<AdminClassifiedsManagement> createState() => _AdminClassifiedsManagementState();
}

class _AdminClassifiedsManagementState extends State<AdminClassifiedsManagement> {
  int _selectedIndex = 0;
  final List<String> _tabs = ['Jobs', 'Business', 'Real Estate', 'Rentals'];
  final List<String> _collections = [
    FirestoreCollections.jobListings,
    FirestoreCollections.businessListings,
    FirestoreCollections.realEstateListings,
    FirestoreCollections.rentalListings,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Classifieds Management',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _showAddClassifiedDialog(context),
                  icon: const Icon(Icons.add),
                  label: Text('Add ${_tabs[_selectedIndex]}'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _buildTabBar(),
            const SizedBox(height: 16),
            Expanded(child: _buildClassifiedsList()),
          ],
        ),
      ),
    );
  }

  Widget _buildTabBar() {
    return Card(
      child: Container(
        padding: const EdgeInsets.all(4),
        child: Row(
          children: _tabs.asMap().entries.map((entry) {
            final index = entry.key;
            final tab = entry.value;
            final isSelected = index == _selectedIndex;
            
            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _selectedIndex = index),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: isSelected ? Theme.of(context).colorScheme.primary : null,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    tab,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: isSelected ? Colors.white : null,
                      fontWeight: isSelected ? FontWeight.w600 : null,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildClassifiedsList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(_collections[_selectedIndex])
          .orderBy(FirestoreFields.createdAt, descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) {
          return Center(child: Text('No ${_tabs[_selectedIndex].toLowerCase()} found'));
        }

        return ListView.separated(
          itemCount: docs.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data() as Map<String, dynamic>;
            
            return _buildClassifiedCard(doc.id, data);
          },
        );
      },
    );
  }

  Widget _buildClassifiedCard(String id, Map<String, dynamic> data) {
    switch (_selectedIndex) {
      case 0: // Jobs
        return _buildJobCard(id, data);
      case 1: // Business
        return _buildBusinessCard(id, data);
      case 2: // Real Estate
        return _buildRealEstateCard(id, data);
      case 3: // Rentals
        return _buildRentalCard(id, data);
      default:
        return const SizedBox();
    }
  }

  Widget _buildJobCard(String id, Map<String, dynamic> data) {
    final isActive = data[FirestoreFields.isActive] ?? false;
    final isPremium = data[FirestoreFields.isPremium] ?? false;
    final createdAt = (data[FirestoreFields.createdAt] as Timestamp?)?.toDate() ?? DateTime.now();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundImage: data[FirestoreFields.companyLogo] != null
                      ? NetworkImage(data[FirestoreFields.companyLogo])
                      : null,
                  child: data[FirestoreFields.companyLogo] == null
                      ? const Icon(Icons.business)
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              data[FirestoreFields.title] ?? 'No Title',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (isPremium)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.amber,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'PREMIUM',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Text(
                        data[FirestoreFields.company] ?? '',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      Text(
                        '${data[FirestoreFields.location] ?? ''} • ${data[FirestoreFields.jobType] ?? ''}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      Text(
                        data[FirestoreFields.salary] ?? '',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: Colors.green[600],
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleAction(value, id, data),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [Icon(Icons.edit_outlined), SizedBox(width: 8), Text('Edit')],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_status',
                      child: Row(
                        children: [
                          Icon(isActive ? Icons.visibility_off : Icons.visibility),
                          const SizedBox(width: 8),
                          Text(isActive ? 'Hide' : 'Show'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_premium',
                      child: Row(
                        children: [
                          Icon(isPremium ? Icons.star_outline : Icons.star),
                          const SizedBox(width: 8),
                          Text(isPremium ? 'Remove Premium' : 'Make Premium'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.blue.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    data[FirestoreFields.category] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.blue,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  DateFormat('MMM dd, yyyy').format(createdAt),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(width: 8),
                Icon(
                  isActive ? Icons.visibility : Icons.visibility_off,
                  size: 16,
                  color: isActive ? Colors.green : Colors.grey,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBusinessCard(String id, Map<String, dynamic> data) {
    final isActive = data[FirestoreFields.isActive] ?? false;
    final isPremium = data[FirestoreFields.isPremium] ?? false;
    final createdAt = (data[FirestoreFields.createdAt] as Timestamp?)?.toDate() ?? DateTime.now();
    final rating = data[FirestoreFields.rating]?.toDouble() ?? 0.0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: NetworkImageWithFallback(
                    imageUrl: data[FirestoreFields.imageUrl],
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    fallbackIcon: Icons.business,
                    fallbackText: 'Business',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              data[FirestoreFields.businessName] ?? 'No Name',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (isPremium)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.amber,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'PREMIUM',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Text(
                        data[FirestoreFields.address] ?? '',
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Row(
                        children: [
                          ...List.generate(5, (index) {
                            return Icon(
                              index < rating ? Icons.star : Icons.star_border,
                              size: 14,
                              color: Colors.amber,
                            );
                          }),
                          const SizedBox(width: 4),
                          Text(
                            '${data[FirestoreFields.reviewCount] ?? 0} reviews',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleAction(value, id, data),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [Icon(Icons.edit_outlined), SizedBox(width: 8), Text('Edit')],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_status',
                      child: Row(
                        children: [
                          Icon(isActive ? Icons.visibility_off : Icons.visibility),
                          const SizedBox(width: 8),
                          Text(isActive ? 'Hide' : 'Show'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_premium',
                      child: Row(
                        children: [
                          Icon(isPremium ? Icons.star_outline : Icons.star),
                          const SizedBox(width: 8),
                          Text(isPremium ? 'Remove Premium' : 'Make Premium'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    data[FirestoreFields.category] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.green,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  DateFormat('MMM dd, yyyy').format(createdAt),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(width: 8),
                Icon(
                  isActive ? Icons.visibility : Icons.visibility_off,
                  size: 16,
                  color: isActive ? Colors.green : Colors.grey,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRealEstateCard(String id, Map<String, dynamic> data) {
    final isActive = data[FirestoreFields.isActive] ?? false;
    final isPremium = data[FirestoreFields.isPremium] ?? false;
    final createdAt = (data[FirestoreFields.createdAt] as Timestamp?)?.toDate() ?? DateTime.now();
    final price = data[FirestoreFields.price] ?? 0.0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: NetworkImageWithFallback(
                    imageUrl: (data[FirestoreFields.images] as List?)?.first ?? data[FirestoreFields.imageUrl],
                    width: 80,
                    height: 60,
                    fit: BoxFit.cover,
                    fallbackIcon: Icons.home,
                    fallbackText: 'Property',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              data[FirestoreFields.title] ?? 'No Title',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (isPremium)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.amber,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'PREMIUM',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Text(
                        data[FirestoreFields.location] ?? '',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      Row(
                        children: [
                          Text(
                            '\$${NumberFormat('#,###').format(price)}',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Colors.green[600],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '${data[FirestoreFields.bedrooms] ?? 0} bed • ${data[FirestoreFields.bathrooms] ?? 0} bath',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleAction(value, id, data),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [Icon(Icons.edit_outlined), SizedBox(width: 8), Text('Edit')],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_status',
                      child: Row(
                        children: [
                          Icon(isActive ? Icons.visibility_off : Icons.visibility),
                          const SizedBox(width: 8),
                          Text(isActive ? 'Hide' : 'Show'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_premium',
                      child: Row(
                        children: [
                          Icon(isPremium ? Icons.star_outline : Icons.star),
                          const SizedBox(width: 8),
                          Text(isPremium ? 'Remove Premium' : 'Make Premium'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.purple.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    data[FirestoreFields.type] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.purple,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  DateFormat('MMM dd, yyyy').format(createdAt),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(width: 8),
                Icon(
                  isActive ? Icons.visibility : Icons.visibility_off,
                  size: 16,
                  color: isActive ? Colors.green : Colors.grey,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRentalCard(String id, Map<String, dynamic> data) {
    final isActive = data[FirestoreFields.isActive] ?? false;
    final isPremium = data[FirestoreFields.isPremium] ?? false;
    final createdAt = (data[FirestoreFields.createdAt] as Timestamp?)?.toDate() ?? DateTime.now();
    final monthlyRent = data[FirestoreFields.monthlyRent] ?? 0.0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: NetworkImageWithFallback(
                    imageUrl: (data[FirestoreFields.images] as List?)?.first ?? data[FirestoreFields.imageUrl],
                    width: 80,
                    height: 60,
                    fit: BoxFit.cover,
                    fallbackIcon: Icons.apartment,
                    fallbackText: 'Rental',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              data[FirestoreFields.title] ?? 'No Title',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (isPremium)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.amber,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'PREMIUM',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Text(
                        data[FirestoreFields.location] ?? '',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      Row(
                        children: [
                          Text(
                            '\$${NumberFormat('#,###').format(monthlyRent)}/month',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Colors.orange[600],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '${data[FirestoreFields.bedrooms] ?? 0} bed • ${data[FirestoreFields.bathrooms] ?? 0} bath',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleAction(value, id, data),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [Icon(Icons.edit_outlined), SizedBox(width: 8), Text('Edit')],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_status',
                      child: Row(
                        children: [
                          Icon(isActive ? Icons.visibility_off : Icons.visibility),
                          const SizedBox(width: 8),
                          Text(isActive ? 'Hide' : 'Show'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'toggle_premium',
                      child: Row(
                        children: [
                          Icon(isPremium ? Icons.star_outline : Icons.star),
                          const SizedBox(width: 8),
                          Text(isPremium ? 'Remove Premium' : 'Make Premium'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    data[FirestoreFields.type] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.orange,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                if (data[FirestoreFields.furnished] == true)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.teal.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'Furnished',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.teal,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                const SizedBox(width: 8),
                Text(
                  DateFormat('MMM dd, yyyy').format(createdAt),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(width: 8),
                Icon(
                  isActive ? Icons.visibility : Icons.visibility_off,
                  size: 16,
                  color: isActive ? Colors.green : Colors.grey,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleAction(String action, String id, Map<String, dynamic> data) async {
    switch (action) {
      case 'edit':
        _showEditClassifiedDialog(context, id, data);
        break;
      case 'toggle_status':
        await _toggleStatus(id, data);
        break;
      case 'toggle_premium':
        await _togglePremium(id, data);
        break;
      case 'delete':
        await _deleteClassified(id, data);
        break;
    }
  }

  Future<void> _toggleStatus(String id, Map<String, dynamic> data) async {
    try {
      await FirebaseFirestore.instance
          .collection(_collections[_selectedIndex])
          .doc(id)
          .update({
        FirestoreFields.isActive: !(data[FirestoreFields.isActive] ?? false),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Listing ${data[FirestoreFields.isActive] ? 'hidden' : 'shown'} successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating listing: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _togglePremium(String id, Map<String, dynamic> data) async {
    try {
      await FirebaseFirestore.instance
          .collection(_collections[_selectedIndex])
          .doc(id)
          .update({
        FirestoreFields.isPremium: !(data[FirestoreFields.isPremium] ?? false),
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Premium status ${data[FirestoreFields.isPremium] ? 'removed' : 'added'} successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating premium status: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteClassified(String id, Map<String, dynamic> data) async {
    final title = data[FirestoreFields.title] ?? 
                 data[FirestoreFields.businessName] ?? 
                 'this listing';
    
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Listing'),
        content: Text('Are you sure you want to delete "$title"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await FirebaseFirestore.instance
          .collection(_collections[_selectedIndex])
          .doc(id)
          .delete();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Listing deleted successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting listing: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showAddClassifiedDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => ClassifiedDialog(
        type: _tabs[_selectedIndex],
        collection: _collections[_selectedIndex],
      ),
    );
  }

  void _showEditClassifiedDialog(BuildContext context, String id, Map<String, dynamic> data) {
    showDialog(
      context: context,
      builder: (context) => ClassifiedDialog(
        type: _tabs[_selectedIndex],
        collection: _collections[_selectedIndex],
        id: id,
        data: data,
      ),
    );
  }
}

class ClassifiedDialog extends StatefulWidget {
  final String type;
  final String collection;
  final String? id;
  final Map<String, dynamic>? data;

  const ClassifiedDialog({
    super.key,
    required this.type,
    required this.collection,
    this.id,
    this.data,
  });

  @override
  State<ClassifiedDialog> createState() => _ClassifiedDialogState();
}

class _ClassifiedDialogState extends State<ClassifiedDialog> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, TextEditingController> _controllers = {};
  bool _isActive = true;
  bool _isPremium = false;
  bool _isLoading = false;
  String _selectedCategory = '';
  String _selectedType = '';
  String? _imageUrl;
  String? _companyLogoUrl;
  List<String> _propertyImages = [];

  @override
  void initState() {
    super.initState();
    _initializeFields();
  }

  void _initializeFields() {
    switch (widget.type) {
      case 'Jobs':
        _selectedCategory = Categories.jobCategories.first;
        _controllers[FirestoreFields.title] = TextEditingController();
        _controllers[FirestoreFields.description] = TextEditingController();
        _controllers[FirestoreFields.company] = TextEditingController();
        _controllers[FirestoreFields.location] = TextEditingController();
        _controllers[FirestoreFields.salary] = TextEditingController();
        _controllers[FirestoreFields.jobType] = TextEditingController();
        _controllers[FirestoreFields.experience] = TextEditingController();
        _controllers[FirestoreFields.requirements] = TextEditingController();
        _controllers[FirestoreFields.benefits] = TextEditingController();
        _controllers[FirestoreFields.applicationUrl] = TextEditingController();
        // Company logo handled separately with image upload
        break;
      case 'Business':
        _selectedCategory = Categories.businessCategories.first;
        _controllers[FirestoreFields.businessName] = TextEditingController();
        _controllers[FirestoreFields.description] = TextEditingController();
        _controllers[FirestoreFields.address] = TextEditingController();
        _controllers[FirestoreFields.phone] = TextEditingController();
        _controllers[FirestoreFields.email] = TextEditingController();
        _controllers[FirestoreFields.website] = TextEditingController();
        _controllers[FirestoreFields.operatingHours] = TextEditingController();
        _controllers[FirestoreFields.services] = TextEditingController();
        // Business image handled separately with image upload
        break;
      case 'Real Estate':
        _selectedType = Categories.realEstateTypes.first;
        _controllers[FirestoreFields.title] = TextEditingController();
        _controllers[FirestoreFields.description] = TextEditingController();
        _controllers[FirestoreFields.price] = TextEditingController();
        _controllers[FirestoreFields.location] = TextEditingController();
        _controllers[FirestoreFields.bedrooms] = TextEditingController();
        _controllers[FirestoreFields.bathrooms] = TextEditingController();
        _controllers[FirestoreFields.area] = TextEditingController();
        _controllers[FirestoreFields.amenities] = TextEditingController();
        _controllers[FirestoreFields.contactInfo] = TextEditingController();
        // Property images handled separately with image upload
        break;
      case 'Rentals':
        _selectedType = Categories.rentalTypes.first;
        _controllers[FirestoreFields.title] = TextEditingController();
        _controllers[FirestoreFields.description] = TextEditingController();
        _controllers[FirestoreFields.monthlyRent] = TextEditingController();
        _controllers[FirestoreFields.deposit] = TextEditingController();
        _controllers[FirestoreFields.location] = TextEditingController();
        _controllers[FirestoreFields.bedrooms] = TextEditingController();
        _controllers[FirestoreFields.bathrooms] = TextEditingController();
        _controllers[FirestoreFields.area] = TextEditingController();
        _controllers[FirestoreFields.amenities] = TextEditingController();
        _controllers[FirestoreFields.contactInfo] = TextEditingController();
        // Rental images handled separately with image upload
        break;
    }

    // Populate fields if editing
    if (widget.data != null) {
      _isActive = widget.data![FirestoreFields.isActive] ?? true;
      _isPremium = widget.data![FirestoreFields.isPremium] ?? false;
      
      // Handle images separately
      _imageUrl = widget.data![FirestoreFields.imageUrl];
      _companyLogoUrl = widget.data![FirestoreFields.companyLogo];
      if (widget.data![FirestoreFields.images] is List) {
        _propertyImages = List<String>.from(widget.data![FirestoreFields.images] ?? []);
      }
      
      _controllers.forEach((field, controller) {
        // Skip image fields as they're handled separately
        if (field == FirestoreFields.imageUrl || 
            field == FirestoreFields.companyLogo || 
            field == FirestoreFields.images) return;
            
        final value = widget.data![field];
        if (value != null) {
          if (value is List) {
            controller.text = value.join(', ');
          } else {
            controller.text = value.toString();
          }
        }
      });

      if (widget.data![FirestoreFields.category] != null) {
        _selectedCategory = widget.data![FirestoreFields.category];
      }
      if (widget.data![FirestoreFields.type] != null) {
        _selectedType = widget.data![FirestoreFields.type];
      }
    }
  }

  @override
  void dispose() {
    _controllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 800,
        height: 600,
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  '${widget.id == null ? 'Add' : 'Edit'} ${widget.type}',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: _buildFormFields(),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Row(
                  children: [
                    Checkbox(
                      value: _isActive,
                      onChanged: (value) => setState(() => _isActive = value ?? true),
                    ),
                    const Text('Active'),
                  ],
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Checkbox(
                      value: _isPremium,
                      onChanged: (value) => setState(() => _isPremium = value ?? false),
                    ),
                    const Text('Premium'),
                  ],
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _isLoading ? null : _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(widget.id == null ? 'Add' : 'Update'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormFields() {
    switch (widget.type) {
      case 'Jobs':
        return _buildJobFields();
      case 'Business':
        return _buildBusinessFields();
      case 'Real Estate':
        return _buildRealEstateFields();
      case 'Rentals':
        return _buildRentalFields();
      default:
        return const SizedBox();
    }
  }

  Widget _buildJobFields() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              flex: 2,
              child: TextFormField(
                controller: _controllers[FirestoreFields.title],
                decoration: const InputDecoration(
                  labelText: 'Job Title *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: Categories.jobCategories
                    .map((category) => DropdownMenuItem(
                          value: category,
                          child: Text(category),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _selectedCategory = value!),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.description],
          decoration: const InputDecoration(
            labelText: 'Job Description *',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 4,
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.company],
                decoration: const InputDecoration(
                  labelText: 'Company *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.location],
                decoration: const InputDecoration(
                  labelText: 'Location *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.salary],
                decoration: const InputDecoration(
                  labelText: 'Salary Range',
                  border: OutlineInputBorder(),
                  hintText: '\$50,000 - \$70,000',
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.jobType],
                decoration: const InputDecoration(
                  labelText: 'Job Type',
                  border: OutlineInputBorder(),
                  hintText: 'Full-time, Part-time, Contract',
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.experience],
                decoration: const InputDecoration(
                  labelText: 'Experience',
                  border: OutlineInputBorder(),
                  hintText: '2-3 years',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.requirements],
          decoration: const InputDecoration(
            labelText: 'Requirements',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 3,
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.benefits],
          decoration: const InputDecoration(
            labelText: 'Benefits',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 2,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.applicationUrl],
                decoration: const InputDecoration(
                  labelText: 'Application URL',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Company Logo',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 8),
                  ImageUploadWidget(
                    initialImageUrl: _companyLogoUrl,
                    folder: ImageFolders.jobs,
                    fileName: 'company_logo_${DateTime.now().millisecondsSinceEpoch}',
                    width: 120,
                    height: 80,
                    placeholder: 'Upload company logo',
                    onImageChanged: (url) => setState(() => _companyLogoUrl = url),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBusinessFields() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              flex: 2,
              child: TextFormField(
                controller: _controllers[FirestoreFields.businessName],
                decoration: const InputDecoration(
                  labelText: 'Business Name *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: Categories.businessCategories
                    .map((category) => DropdownMenuItem(
                          value: category,
                          child: Text(category),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _selectedCategory = value!),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.description],
          decoration: const InputDecoration(
            labelText: 'Description *',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 3,
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.address],
          decoration: const InputDecoration(
            labelText: 'Address *',
            border: OutlineInputBorder(),
          ),
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.phone],
                decoration: const InputDecoration(
                  labelText: 'Phone',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.email],
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.website],
                decoration: const InputDecoration(
                  labelText: 'Website',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.operatingHours],
                decoration: const InputDecoration(
                  labelText: 'Operating Hours',
                  border: OutlineInputBorder(),
                  hintText: 'Mon-Fri: 9AM-6PM',
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Business Image',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 8),
                  ImageUploadWidget(
                    initialImageUrl: _imageUrl,
                    folder: ImageFolders.business,
                    fileName: 'business_${DateTime.now().millisecondsSinceEpoch}',
                    width: 150,
                    height: 100,
                    placeholder: 'Upload business image',
                    onImageChanged: (url) => setState(() => _imageUrl = url),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.services],
          decoration: const InputDecoration(
            labelText: 'Services (comma separated)',
            border: OutlineInputBorder(),
            hintText: 'Service 1, Service 2, Service 3',
          ),
        ),
      ],
    );
  }

  Widget _buildRealEstateFields() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              flex: 2,
              child: TextFormField(
                controller: _controllers[FirestoreFields.title],
                decoration: const InputDecoration(
                  labelText: 'Property Title *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _selectedType,
                decoration: const InputDecoration(
                  labelText: 'Property Type',
                  border: OutlineInputBorder(),
                ),
                items: Categories.realEstateTypes
                    .map((type) => DropdownMenuItem(
                          value: type,
                          child: Text(type),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _selectedType = value!),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.description],
          decoration: const InputDecoration(
            labelText: 'Description *',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 3,
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.price],
                decoration: const InputDecoration(
                  labelText: 'Price *',
                  border: OutlineInputBorder(),
                  prefixText: '\$',
                ),
                keyboardType: TextInputType.number,
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: TextFormField(
                controller: _controllers[FirestoreFields.location],
                decoration: const InputDecoration(
                  labelText: 'Location *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.bedrooms],
                decoration: const InputDecoration(
                  labelText: 'Bedrooms',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.bathrooms],
                decoration: const InputDecoration(
                  labelText: 'Bathrooms',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.area],
                decoration: const InputDecoration(
                  labelText: 'Area (sq ft)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.amenities],
          decoration: const InputDecoration(
            labelText: 'Amenities (comma separated)',
            border: OutlineInputBorder(),
            hintText: 'Pool, Gym, Parking, Garden',
          ),
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.contactInfo],
          decoration: const InputDecoration(
            labelText: 'Contact Info *',
            border: OutlineInputBorder(),
          ),
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Property Images',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  // Main property image
                  ImageUploadWidget(
                    initialImageUrl: _propertyImages.isNotEmpty ? _propertyImages[0] : null,
                    folder: ImageFolders.realEstate,
                    fileName: 'property_main_${DateTime.now().millisecondsSinceEpoch}',
                    width: 150,
                    height: 100,
                    placeholder: 'Main image',
                    onImageChanged: (url) {
                      setState(() {
                        if (_propertyImages.isEmpty) {
                          _propertyImages.add(url ?? '');
                        } else {
                          _propertyImages[0] = url ?? '';
                        }
                        _propertyImages.removeWhere((img) => img.isEmpty);
                      });
                    },
                  ),
                  const SizedBox(width: 8),
                  // Additional property images
                  ...List.generate(2, (index) {
                    final imageIndex = index + 1;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ImageUploadWidget(
                        initialImageUrl: _propertyImages.length > imageIndex ? _propertyImages[imageIndex] : null,
                        folder: ImageFolders.realEstate,
                        fileName: 'property_${imageIndex}_${DateTime.now().millisecondsSinceEpoch}',
                        width: 120,
                        height: 80,
                        placeholder: 'Image ${imageIndex + 1}',
                        onImageChanged: (url) {
                          setState(() {
                            if (url != null) {
                              while (_propertyImages.length <= imageIndex) {
                                _propertyImages.add('');
                              }
                              _propertyImages[imageIndex] = url;
                            } else if (_propertyImages.length > imageIndex) {
                              _propertyImages[imageIndex] = '';
                            }
                            _propertyImages.removeWhere((img) => img.isEmpty);
                          });
                        },
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRentalFields() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              flex: 2,
              child: TextFormField(
                controller: _controllers[FirestoreFields.title],
                decoration: const InputDecoration(
                  labelText: 'Rental Title *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _selectedType,
                decoration: const InputDecoration(
                  labelText: 'Property Type',
                  border: OutlineInputBorder(),
                ),
                items: Categories.rentalTypes
                    .map((type) => DropdownMenuItem(
                          value: type,
                          child: Text(type),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _selectedType = value!),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.description],
          decoration: const InputDecoration(
            labelText: 'Description *',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 3,
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.monthlyRent],
                decoration: const InputDecoration(
                  labelText: 'Monthly Rent *',
                  border: OutlineInputBorder(),
                  prefixText: '\$',
                ),
                keyboardType: TextInputType.number,
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.deposit],
                decoration: const InputDecoration(
                  labelText: 'Security Deposit',
                  border: OutlineInputBorder(),
                  prefixText: '\$',
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.location],
                decoration: const InputDecoration(
                  labelText: 'Location *',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.bedrooms],
                decoration: const InputDecoration(
                  labelText: 'Bedrooms',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.bathrooms],
                decoration: const InputDecoration(
                  labelText: 'Bathrooms',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _controllers[FirestoreFields.area],
                decoration: const InputDecoration(
                  labelText: 'Area (sq ft)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.amenities],
          decoration: const InputDecoration(
            labelText: 'Amenities (comma separated)',
            border: OutlineInputBorder(),
            hintText: 'Pool, Gym, Parking, Garden',
          ),
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _controllers[FirestoreFields.contactInfo],
          decoration: const InputDecoration(
            labelText: 'Contact Info *',
            border: OutlineInputBorder(),
          ),
          validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
        ),
        const SizedBox(height: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Rental Images',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  // Main rental image
                  ImageUploadWidget(
                    initialImageUrl: _propertyImages.isNotEmpty ? _propertyImages[0] : null,
                    folder: ImageFolders.rentals,
                    fileName: 'rental_main_${DateTime.now().millisecondsSinceEpoch}',
                    width: 150,
                    height: 100,
                    placeholder: 'Main image',
                    onImageChanged: (url) {
                      setState(() {
                        if (_propertyImages.isEmpty) {
                          _propertyImages.add(url ?? '');
                        } else {
                          _propertyImages[0] = url ?? '';
                        }
                        _propertyImages.removeWhere((img) => img.isEmpty);
                      });
                    },
                  ),
                  const SizedBox(width: 8),
                  // Additional rental images
                  ...List.generate(2, (index) {
                    final imageIndex = index + 1;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ImageUploadWidget(
                        initialImageUrl: _propertyImages.length > imageIndex ? _propertyImages[imageIndex] : null,
                        folder: ImageFolders.rentals,
                        fileName: 'rental_${imageIndex}_${DateTime.now().millisecondsSinceEpoch}',
                        width: 120,
                        height: 80,
                        placeholder: 'Image ${imageIndex + 1}',
                        onImageChanged: (url) {
                          setState(() {
                            if (url != null) {
                              while (_propertyImages.length <= imageIndex) {
                                _propertyImages.add('');
                              }
                              _propertyImages[imageIndex] = url;
                            } else if (_propertyImages.length > imageIndex) {
                              _propertyImages[imageIndex] = '';
                            }
                            _propertyImages.removeWhere((img) => img.isEmpty);
                          });
                        },
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final data = <String, dynamic>{
        FirestoreFields.isActive: _isActive,
        FirestoreFields.isPremium: _isPremium,
        FirestoreFields.updatedAt: FieldValue.serverTimestamp(),
      };

      // Add category/type fields
      if (_selectedCategory.isNotEmpty) {
        data[FirestoreFields.category] = _selectedCategory;
      }
      if (_selectedType.isNotEmpty) {
        data[FirestoreFields.type] = _selectedType;
      }

      // Add form fields
      _controllers.forEach((field, controller) {
        final value = controller.text.trim();
        if (value.isNotEmpty) {
          if (field == FirestoreFields.price || 
              field == FirestoreFields.monthlyRent || 
              field == FirestoreFields.deposit) {
            data[field] = double.tryParse(value.replaceAll(',', '')) ?? 0.0;
          } else if (field == FirestoreFields.bedrooms || 
                     field == FirestoreFields.bathrooms || 
                     field == FirestoreFields.area || 
                     field == FirestoreFields.reviewCount) {
            data[field] = int.tryParse(value) ?? 0;
          } else if (field == FirestoreFields.amenities || 
                     field == FirestoreFields.services || 
                     field == FirestoreFields.requirements ||
                     field == FirestoreFields.benefits) {
            data[field] = value.split(',').map((item) => item.trim()).where((item) => item.isNotEmpty).toList();
          } else {
            data[field] = value;
          }
        }
      });

      // Handle image fields separately
      if (_imageUrl != null && _imageUrl!.isNotEmpty) {
        data[FirestoreFields.imageUrl] = _imageUrl;
      }
      
      if (_companyLogoUrl != null && _companyLogoUrl!.isNotEmpty) {
        data[FirestoreFields.companyLogo] = _companyLogoUrl;
      }
      
      if (_propertyImages.isNotEmpty) {
        data[FirestoreFields.images] = _propertyImages;
      }

      // Add default values for new listings
      if (widget.id == null) {
        data[FirestoreFields.createdAt] = FieldValue.serverTimestamp();
        if (widget.type == 'Business') {
          data[FirestoreFields.rating] = 0.0;
          data[FirestoreFields.reviewCount] = 0;
        }
      }

      if (widget.id == null) {
        await FirebaseFirestore.instance
            .collection(widget.collection)
            .add(data);
      } else {
        await FirebaseFirestore.instance
            .collection(widget.collection)
            .doc(widget.id)
            .update(data);
      }

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${widget.type} ${widget.id == null ? 'added' : 'updated'} successfully',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving ${widget.type.toLowerCase()}: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
}