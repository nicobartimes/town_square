import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:town_square/models/news_article.dart';
import 'package:town_square/models/video_news.dart';
import 'package:town_square/models/classified_listing.dart';
import 'package:town_square/services/news_service.dart';
import 'package:town_square/services/video_news_service.dart';
import 'package:town_square/services/classifieds_service.dart';
import 'package:town_square/services/firebase_auth_service.dart';
import 'package:town_square/widgets/news_card.dart';
import 'package:town_square/widgets/classified_card.dart';
import 'package:town_square/widgets/enhanced_image_widget.dart';
import 'package:town_square/screens/news_detail_screen.dart';
import 'package:town_square/screens/video_player_screen.dart';
import 'package:town_square/screens/classified_detail_screen.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _authService = FirebaseAuthService();
  List<NewsArticle> _bookmarkedNews = [];
  List<VideoNews> _bookmarkedVideos = [];
  List<ClassifiedListing> _favoritedListings = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadBookmarks();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadBookmarks() async {
    setState(() => _isLoading = true);
    
    // Check if user is authenticated
    if (!_authService.isAuthenticated) {
      setState(() {
        _isLoading = false;
        _bookmarkedNews = [];
        _bookmarkedVideos = [];
        _favoritedListings = [];
      });
      return;
    }
    
    final bookmarkedNews = await NewsService.getBookmarkedNews();
    final bookmarkedVideos = await VideoNewsService.getBookmarkedVideoNews();
    final favoritedListings = await ClassifiedsService.getFavoritedListings();
    
    setState(() {
      _bookmarkedNews = bookmarkedNews;
      _bookmarkedVideos = bookmarkedVideos;
      _favoritedListings = favoritedListings;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildTabBar(),
            Expanded(child: _buildTabBarView()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Saved Items 💾',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Your bookmarked news and favorites',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                ),
              ),
            ],
          ),
          const Spacer(),
          IconButton(
            onPressed: _loadBookmarks,
            icon: Icon(
              Icons.refresh,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(8),
        ),
        indicatorPadding: const EdgeInsets.all(4),
        dividerColor: Colors.transparent,
        labelColor: Theme.of(context).colorScheme.onPrimary,
        unselectedLabelColor: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
        labelStyle: const TextStyle(fontWeight: FontWeight.w600),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
        tabs: [
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.newspaper, size: 16),
                const SizedBox(width: 4),
                Text('News (${_bookmarkedNews.length})'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.video_library, size: 16),
                const SizedBox(width: 4),
                Text('Videos (${_bookmarkedVideos.length})'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.favorite, size: 16),
                const SizedBox(width: 4),
                Text('Listings (${_favoritedListings.length})'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBarView() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return TabBarView(
      controller: _tabController,
      children: [
        _buildBookmarkedNews(),
        _buildBookmarkedVideos(),
        _buildFavoritedListings(),
      ],
    );
  }

  Widget _buildBookmarkedNews() {
    if (_bookmarkedNews.isEmpty) {
      return _buildEmptyState(
        icon: Icons.bookmark_outline,
        title: 'No bookmarked news',
        subtitle: 'Bookmark articles to read them later',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _bookmarkedNews.length,
      itemBuilder: (context, index) {
        final article = _bookmarkedNews[index];
        return NewsCard(
          article: article,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => NewsDetailScreen(article: article),
            ),
          ),
          onBookmarkToggle: () async {
            await NewsService.toggleBookmark(article.id);
            _loadBookmarks();
          },
        );
      },
    );
  }

  Widget _buildBookmarkedVideos() {
    if (_bookmarkedVideos.isEmpty) {
      return _buildEmptyState(
        icon: Icons.video_library_outlined,
        title: 'No bookmarked videos',
        subtitle: 'Bookmark videos to watch them later',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _bookmarkedVideos.length,
      itemBuilder: (context, index) {
        final video = _bookmarkedVideos[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          child: GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => VideoPlayerScreen(video: video),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainer.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.1),
                ),
              ),
              child: Row(
                children: [
                  Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: NetworkImageWithFallback(
                          imageUrl: video.thumbnailUrl,
                          width: 120,
                          height: 68,
                          fit: BoxFit.cover,
                          fallbackIcon: Icons.video_library,
                          fallbackText: 'Video Thumbnail',
                        ),
                      ),
                      Positioned(
                        bottom: 4,
                        right: 4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.8),
                            borderRadius: BorderRadius.circular(3),
                          ),
                          child: Text(
                            video.formattedDuration,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          video.title,
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          video.channelName,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          video.formattedViewCount,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () async {
                      await VideoNewsService.toggleBookmark(video.id);
                      _loadBookmarks();
                    },
                    icon: Icon(
                      Icons.bookmark,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFavoritedListings() {
    if (_favoritedListings.isEmpty) {
      return _buildEmptyState(
        icon: Icons.favorite_outline,
        title: 'No favorited listings',
        subtitle: 'Mark listings as favorites to save them here',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _favoritedListings.length,
      itemBuilder: (context, index) {
        final listing = _favoritedListings[index];
        return ClassifiedCard(
          listing: listing,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ClassifiedDetailScreen(listing: listing),
            ),
          ),
          onFavoriteToggle: () async {
            await ClassifiedsService.toggleFavorite(listing.id);
            _loadBookmarks();
          },
        );
      },
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 80,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.4),
          ),
          const SizedBox(height: 24),
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          ElevatedButton.icon(
            onPressed: () {
              final tabController = DefaultTabController.of(context);
              if (tabController != null) {
                if (icon == Icons.bookmark_outline) {
                  tabController.animateTo(0); // Navigate to News tab
                } else if (icon == Icons.video_library_outlined) {
                  tabController.animateTo(1); // Navigate to Videos tab  
                } else {
                  tabController.animateTo(2); // Navigate to Classifieds tab
                }
              }
            },
            icon: Icon(
              icon == Icons.bookmark_outline 
                ? Icons.newspaper 
                : icon == Icons.video_library_outlined 
                  ? Icons.video_library
                  : Icons.storefront,
              color: Theme.of(context).colorScheme.onPrimary,
            ),
            label: Text(
              icon == Icons.bookmark_outline 
                ? 'Browse News' 
                : icon == Icons.video_library_outlined
                  ? 'Browse Videos'
                  : 'Browse Classifieds',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}