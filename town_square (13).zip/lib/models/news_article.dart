import 'package:cloud_firestore/cloud_firestore.dart';

class NewsArticle {
  final String id;
  final String title;
  final String content;
  final String summary;
  final String description; // For Firebase compatibility
  final String imageUrl;
  final String? videoId;
  final String category;
  final String source;
  final String author; // For Firebase compatibility
  final DateTime publishedAt;
  final DateTime updatedAt;
  final int readTime;
  final int viewCount; // For Firebase compatibility
  final List<String> tags; // For Firebase compatibility
  final bool isActive; // For Firebase compatibility
  final bool isBookmarked;

  NewsArticle({
    required this.id,
    required this.title,
    required this.content,
    required this.summary,
    String? description,
    required this.imageUrl,
    this.videoId,
    required this.category,
    required this.source,
    String? author,
    required this.publishedAt,
    DateTime? updatedAt,
    required this.readTime,
    this.viewCount = 0,
    this.tags = const [],
    this.isActive = true,
    this.isBookmarked = false,
  }) : description = description ?? summary,
       author = author ?? source,
       updatedAt = updatedAt ?? publishedAt;

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'content': content,
    'summary': summary,
    'description': description,
    'imageUrl': imageUrl,
    'videoId': videoId,
    'category': category,
    'source': source,
    'author': author,
    'publishedAt': Timestamp.fromDate(publishedAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'readTime': readTime,
    'viewCount': viewCount,
    'tags': tags,
    'isActive': isActive,
    'isBookmarked': isBookmarked,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  // Firebase-compatible toJson
  Map<String, dynamic> toJson() => toMap();

  factory NewsArticle.fromMap(Map<String, dynamic> map) => NewsArticle(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    content: map['content'] ?? '',
    summary: map['summary'] ?? map['description'] ?? '',
    description: map['description'] ?? map['summary'] ?? '',
    imageUrl: map['imageUrl'] ?? '',
    videoId: map['videoId'],
    category: map['category'] ?? '',
    source: map['source'] ?? '',
    author: map['author'] ?? map['source'] ?? '',
    publishedAt: _parseDateTime(map['publishedAt']) ?? DateTime.now(),
    updatedAt: _parseDateTime(map['updatedAt']) ?? _parseDateTime(map['publishedAt']) ?? DateTime.now(),
    readTime: map['readTime'] ?? 0,
    viewCount: map['viewCount'] ?? 0,
    tags: List<String>.from(map['tags'] ?? []),
    isActive: map['isActive'] ?? true,
    isBookmarked: map['isBookmarked'] ?? false,
  );

  factory NewsArticle.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return NewsArticle.fromMap({...data, 'id': doc.id});
  }

  // Firebase-compatible fromJson
  factory NewsArticle.fromJson(Map<String, dynamic> json) => NewsArticle.fromMap(json);

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
    if (value is DateTime) return value;
    if (value is Timestamp) return value.toDate();
    return null;
  }

  NewsArticle copyWith({
    String? id,
    String? title,
    String? content,
    String? summary,
    String? description,
    String? imageUrl,
    String? videoId,
    String? category,
    String? source,
    String? author,
    DateTime? publishedAt,
    DateTime? updatedAt,
    int? readTime,
    int? viewCount,
    List<String>? tags,
    bool? isActive,
    bool? isBookmarked,
  }) => NewsArticle(
    id: id ?? this.id,
    title: title ?? this.title,
    content: content ?? this.content,
    summary: summary ?? this.summary,
    description: description ?? this.description,
    imageUrl: imageUrl ?? this.imageUrl,
    videoId: videoId ?? this.videoId,
    category: category ?? this.category,
    source: source ?? this.source,
    author: author ?? this.author,
    publishedAt: publishedAt ?? this.publishedAt,
    updatedAt: updatedAt ?? this.updatedAt,
    readTime: readTime ?? this.readTime,
    viewCount: viewCount ?? this.viewCount,
    tags: tags ?? this.tags,
    isActive: isActive ?? this.isActive,
    isBookmarked: isBookmarked ?? this.isBookmarked,
  );
}