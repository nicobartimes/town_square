import 'package:cloud_firestore/cloud_firestore.dart';

class ClassifiedListing {
  final String id;
  final String title;
  final String description;
  final double? price;
  final List<String> imageUrls;
  final String category;
  final String location;
  final String contactName;
  final String contactPhone;
  final String contactEmail;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPremium;
  final bool isFavorited;
  final String userId;
  final bool isActive;

  ClassifiedListing({
    required this.id,
    required this.title,
    required this.description,
    this.price,
    required this.imageUrls,
    required this.category,
    required this.location,
    required this.contactName,
    required this.contactPhone,
    required this.contactEmail,
    required this.createdAt,
    DateTime? updatedAt,
    this.isPremium = false,
    this.isFavorited = false,
    required this.userId,
    this.isActive = true,
  }) : updatedAt = updatedAt ?? createdAt;

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'price': price,
    'imageUrls': imageUrls,
    'category': category,
    'location': location,
    'contactName': contactName,
    'contactPhone': contactPhone,
    'contactEmail': contactEmail,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'isPremium': isPremium,
    'isFavorited': isFavorited,
    'userId': userId,
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  factory ClassifiedListing.fromMap(Map<String, dynamic> map) => ClassifiedListing(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    price: map['price']?.toDouble(),
    imageUrls: List<String>.from(map['imageUrls'] ?? []),
    category: map['category'] ?? '',
    location: map['location'] ?? '',
    contactName: map['contactName'] ?? '',
    contactPhone: map['contactPhone'] ?? '',
    contactEmail: map['contactEmail'] ?? '',
    createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    isPremium: map['isPremium'] ?? false,
    isFavorited: map['isFavorited'] ?? false,
    userId: map['userId'] ?? '',
    isActive: map['isActive'] ?? true,
  );

  factory ClassifiedListing.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ClassifiedListing.fromMap({...data, 'id': doc.id});
  }

  ClassifiedListing copyWith({
    String? id,
    String? title,
    String? description,
    double? price,
    List<String>? imageUrls,
    String? category,
    String? location,
    String? contactName,
    String? contactPhone,
    String? contactEmail,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPremium,
    bool? isFavorited,
    String? userId,
    bool? isActive,
  }) => ClassifiedListing(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    price: price ?? this.price,
    imageUrls: imageUrls ?? this.imageUrls,
    category: category ?? this.category,
    location: location ?? this.location,
    contactName: contactName ?? this.contactName,
    contactPhone: contactPhone ?? this.contactPhone,
    contactEmail: contactEmail ?? this.contactEmail,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isPremium: isPremium ?? this.isPremium,
    isFavorited: isFavorited ?? this.isFavorited,
    userId: userId ?? this.userId,
    isActive: isActive ?? this.isActive,
  );
}