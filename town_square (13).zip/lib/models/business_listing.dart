import 'package:cloud_firestore/cloud_firestore.dart';

class BusinessListing {
  final String id;
  final String businessName;
  final String description;
  final String category; // Restaurant, Retail, Service, Healthcare, etc.
  final List<String> imageUrls;
  final String address;
  final String phone;
  final String email;
  final String? website;
  final Map<String, String> operatingHours; // day -> hours
  final List<String> services;
  final double? rating;
  final int? reviewCount;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPremium;
  final bool isFavorited;
  final String userId;
  final String? socialMediaLinks; // JSON string for social links
  final bool isVerified;
  final bool isActive;

  BusinessListing({
    required this.id,
    required this.businessName,
    required this.description,
    required this.category,
    required this.imageUrls,
    required this.address,
    required this.phone,
    required this.email,
    this.website,
    required this.operatingHours,
    required this.services,
    this.rating,
    this.reviewCount,
    required this.createdAt,
    required this.updatedAt,
    this.isPremium = false,
    this.isFavorited = false,
    required this.userId,
    this.socialMediaLinks,
    this.isVerified = false,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'businessName': businessName,
    'description': description,
    'category': category,
    'imageUrls': imageUrls,
    'address': address,
    'phone': phone,
    'email': email,
    'website': website,
    'operatingHours': operatingHours,
    'services': services,
    'rating': rating,
    'reviewCount': reviewCount,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'isPremium': isPremium,
    'isFavorited': isFavorited,
    'userId': userId,
    'socialMediaLinks': socialMediaLinks,
    'isVerified': isVerified,
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  factory BusinessListing.fromMap(Map<String, dynamic> map) => BusinessListing(
    id: map['id'] ?? '',
    businessName: map['businessName'] ?? '',
    description: map['description'] ?? '',
    category: map['category'] ?? '',
    imageUrls: List<String>.from(map['imageUrls'] ?? []),
    address: map['address'] ?? '',
    phone: map['phone'] ?? '',
    email: map['email'] ?? '',
    website: map['website'],
    operatingHours: Map<String, String>.from(map['operatingHours'] ?? {}),
    services: List<String>.from(map['services'] ?? []),
    rating: map['rating']?.toDouble(),
    reviewCount: map['reviewCount'],
    createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    isPremium: map['isPremium'] ?? false,
    isFavorited: map['isFavorited'] ?? false,
    userId: map['userId'] ?? '',
    socialMediaLinks: map['socialMediaLinks'],
    isVerified: map['isVerified'] ?? false,
    isActive: map['isActive'] ?? true,
  );

  factory BusinessListing.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return BusinessListing.fromMap({...data, 'id': doc.id});
  }

  factory BusinessListing.fromJson(Map<String, dynamic> json) => BusinessListing.fromMap(json);

  Map<String, dynamic> toJson() => toMap();

  BusinessListing copyWith({
    String? id,
    String? businessName,
    String? description,
    String? category,
    List<String>? imageUrls,
    String? address,
    String? phone,
    String? email,
    String? website,
    Map<String, String>? operatingHours,
    List<String>? services,
    double? rating,
    int? reviewCount,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPremium,
    bool? isFavorited,
    String? userId,
    String? socialMediaLinks,
    bool? isVerified,
    bool? isActive,
  }) => BusinessListing(
    id: id ?? this.id,
    businessName: businessName ?? this.businessName,
    description: description ?? this.description,
    category: category ?? this.category,
    imageUrls: imageUrls ?? this.imageUrls,
    address: address ?? this.address,
    phone: phone ?? this.phone,
    email: email ?? this.email,
    website: website ?? this.website,
    operatingHours: operatingHours ?? this.operatingHours,
    services: services ?? this.services,
    rating: rating ?? this.rating,
    reviewCount: reviewCount ?? this.reviewCount,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isPremium: isPremium ?? this.isPremium,
    isFavorited: isFavorited ?? this.isFavorited,
    userId: userId ?? this.userId,
    socialMediaLinks: socialMediaLinks ?? this.socialMediaLinks,
    isVerified: isVerified ?? this.isVerified,
    isActive: isActive ?? this.isActive,
  );
}