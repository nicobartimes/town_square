import 'package:cloud_firestore/cloud_firestore.dart';

class VideoNews {
  final String id;
  final String title;
  final String description;
  final String thumbnailUrl;
  final String videoId; // YouTube video ID
  final String videoUrl; // Full YouTube URL
  final String category;
  final String source;
  final String channelName;
  final DateTime publishedAt;
  final DateTime updatedAt;
  final String duration; // Format: "MM:SS"
  final bool isBookmarked;
  final int viewCount;
  final bool isActive; // For Firebase compatibility

  VideoNews({
    required this.id,
    required this.title,
    required this.description,
    required this.thumbnailUrl,
    required this.videoId,
    String? videoUrl,
    required this.category,
    required this.source,
    required this.channelName,
    required this.publishedAt,
    DateTime? updatedAt,
    required this.duration,
    this.isBookmarked = false,
    required this.viewCount,
    this.isActive = true,
  }) : videoUrl = videoUrl ?? 'https://www.youtube.com/watch?v=$videoId',
       updatedAt = updatedAt ?? publishedAt;

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'thumbnailUrl': thumbnailUrl,
    'videoId': videoId,
    'videoUrl': videoUrl,
    'category': category,
    'source': source,
    'channelName': channelName,
    'publishedAt': Timestamp.fromDate(publishedAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'duration': duration,
    'isBookmarked': isBookmarked,
    'viewCount': viewCount,
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  // Firebase-compatible toJson
  Map<String, dynamic> toJson() => toMap();

  factory VideoNews.fromMap(Map<String, dynamic> map) => VideoNews(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    thumbnailUrl: map['thumbnailUrl'] ?? '',
    videoId: map['videoId'] ?? '',
    videoUrl: map['videoUrl'],
    category: map['category'] ?? '',
    source: map['source'] ?? '',
    channelName: map['channelName'] ?? '',
    publishedAt: _parseDateTime(map['publishedAt']) ?? DateTime.now(),
    updatedAt: _parseDateTime(map['updatedAt']) ?? _parseDateTime(map['publishedAt']) ?? DateTime.now(),
    duration: map['duration']?.toString() ?? '0:00',
    isBookmarked: map['isBookmarked'] ?? false,
    viewCount: map['viewCount'] ?? 0,
    isActive: map['isActive'] ?? true,
  );

  factory VideoNews.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return VideoNews.fromMap({...data, 'id': doc.id});
  }

  // Firebase-compatible fromJson
  factory VideoNews.fromJson(Map<String, dynamic> json) => VideoNews.fromMap(json);

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
    if (value is DateTime) return value;
    if (value is Timestamp) return value.toDate();
    return null;
  }

  VideoNews copyWith({
    String? id,
    String? title,
    String? description,
    String? thumbnailUrl,
    String? videoId,
    String? videoUrl,
    String? category,
    String? source,
    String? channelName,
    DateTime? publishedAt,
    DateTime? updatedAt,
    String? duration,
    bool? isBookmarked,
    int? viewCount,
    bool? isActive,
  }) => VideoNews(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
    videoId: videoId ?? this.videoId,
    videoUrl: videoUrl ?? this.videoUrl,
    category: category ?? this.category,
    source: source ?? this.source,
    channelName: channelName ?? this.channelName,
    publishedAt: publishedAt ?? this.publishedAt,
    updatedAt: updatedAt ?? this.updatedAt,
    duration: duration ?? this.duration,
    isBookmarked: isBookmarked ?? this.isBookmarked,
    viewCount: viewCount ?? this.viewCount,
    isActive: isActive ?? this.isActive,
  );

  String get formattedViewCount {
    if (viewCount >= 1000000) {
      return '${(viewCount / 1000000).toStringAsFixed(1)}M views';
    } else if (viewCount >= 1000) {
      return '${(viewCount / 1000).toStringAsFixed(1)}K views';
    }
    return '$viewCount views';
  }

  String get formattedDuration => duration;
}