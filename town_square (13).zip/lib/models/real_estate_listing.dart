import 'package:cloud_firestore/cloud_firestore.dart';

class RealEstateListing {
  final String id;
  final String title;
  final String description;
  final double price;
  final List<String> imageUrls;
  final String propertyType; // House, Land, Building, Condo, etc.
  final String listingType; // Sale, Rent-to-Own
  final String address;
  final int? bedrooms;
  final int? bathrooms;
  final int? squareFootage;
  final double? lotSize; // in acres or sq ft
  final int? yearBuilt;
  final String propertyCondition; // New, Good, Needs Work, etc.
  final List<String> features;
  final String? propertyTax; // annual
  final String? hoaFees; // monthly
  final bool hasGarage;
  final int? garageSpaces;
  final String zoningType; // Residential, Commercial, Mixed
  final String contactName;
  final String contactPhone;
  final String contactEmail;
  final String? agentLicense;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPremium;
  final bool isFavorited;
  final String userId;
  final DateTime? availableDate;
  final bool isActive;

  RealEstateListing({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.imageUrls,
    required this.propertyType,
    required this.listingType,
    required this.address,
    this.bedrooms,
    this.bathrooms,
    this.squareFootage,
    this.lotSize,
    this.yearBuilt,
    required this.propertyCondition,
    required this.features,
    this.propertyTax,
    this.hoaFees,
    this.hasGarage = false,
    this.garageSpaces,
    required this.zoningType,
    required this.contactName,
    required this.contactPhone,
    required this.contactEmail,
    this.agentLicense,
    required this.createdAt,
    required this.updatedAt,
    this.isPremium = false,
    this.isFavorited = false,
    required this.userId,
    this.availableDate,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'price': price,
    'imageUrls': imageUrls,
    'propertyType': propertyType,
    'listingType': listingType,
    'address': address,
    'bedrooms': bedrooms,
    'bathrooms': bathrooms,
    'squareFootage': squareFootage,
    'lotSize': lotSize,
    'yearBuilt': yearBuilt,
    'propertyCondition': propertyCondition,
    'features': features,
    'propertyTax': propertyTax,
    'hoaFees': hoaFees,
    'hasGarage': hasGarage,
    'garageSpaces': garageSpaces,
    'zoningType': zoningType,
    'contactName': contactName,
    'contactPhone': contactPhone,
    'contactEmail': contactEmail,
    'agentLicense': agentLicense,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'isPremium': isPremium,
    'isFavorited': isFavorited,
    'userId': userId,
    'availableDate': availableDate != null ? Timestamp.fromDate(availableDate!) : null,
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  factory RealEstateListing.fromMap(Map<String, dynamic> map) => RealEstateListing(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    price: map['price']?.toDouble() ?? 0.0,
    imageUrls: List<String>.from(map['imageUrls'] ?? []),
    propertyType: map['propertyType'] ?? '',
    listingType: map['listingType'] ?? '',
    address: map['address'] ?? '',
    bedrooms: map['bedrooms'],
    bathrooms: map['bathrooms'],
    squareFootage: map['squareFootage'],
    lotSize: map['lotSize']?.toDouble(),
    yearBuilt: map['yearBuilt'],
    propertyCondition: map['propertyCondition'] ?? '',
    features: List<String>.from(map['features'] ?? []),
    propertyTax: map['propertyTax'],
    hoaFees: map['hoaFees'],
    hasGarage: map['hasGarage'] ?? false,
    garageSpaces: map['garageSpaces'],
    zoningType: map['zoningType'] ?? '',
    contactName: map['contactName'] ?? '',
    contactPhone: map['contactPhone'] ?? '',
    contactEmail: map['contactEmail'] ?? '',
    agentLicense: map['agentLicense'],
    createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    isPremium: map['isPremium'] ?? false,
    isFavorited: map['isFavorited'] ?? false,
    userId: map['userId'] ?? '',
    availableDate: (map['availableDate'] as Timestamp?)?.toDate(),
    isActive: map['isActive'] ?? true,
  );

  factory RealEstateListing.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return RealEstateListing.fromMap({...data, 'id': doc.id});
  }

  factory RealEstateListing.fromJson(Map<String, dynamic> json) => RealEstateListing.fromMap(json);

  Map<String, dynamic> toJson() => toMap();

  RealEstateListing copyWith({
    String? id,
    String? title,
    String? description,
    double? price,
    List<String>? imageUrls,
    String? propertyType,
    String? listingType,
    String? address,
    int? bedrooms,
    int? bathrooms,
    int? squareFootage,
    double? lotSize,
    int? yearBuilt,
    String? propertyCondition,
    List<String>? features,
    String? propertyTax,
    String? hoaFees,
    bool? hasGarage,
    int? garageSpaces,
    String? zoningType,
    String? contactName,
    String? contactPhone,
    String? contactEmail,
    String? agentLicense,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPremium,
    bool? isFavorited,
    String? userId,
    DateTime? availableDate,
    bool? isActive,
  }) => RealEstateListing(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    price: price ?? this.price,
    imageUrls: imageUrls ?? this.imageUrls,
    propertyType: propertyType ?? this.propertyType,
    listingType: listingType ?? this.listingType,
    address: address ?? this.address,
    bedrooms: bedrooms ?? this.bedrooms,
    bathrooms: bathrooms ?? this.bathrooms,
    squareFootage: squareFootage ?? this.squareFootage,
    lotSize: lotSize ?? this.lotSize,
    yearBuilt: yearBuilt ?? this.yearBuilt,
    propertyCondition: propertyCondition ?? this.propertyCondition,
    features: features ?? this.features,
    propertyTax: propertyTax ?? this.propertyTax,
    hoaFees: hoaFees ?? this.hoaFees,
    hasGarage: hasGarage ?? this.hasGarage,
    garageSpaces: garageSpaces ?? this.garageSpaces,
    zoningType: zoningType ?? this.zoningType,
    contactName: contactName ?? this.contactName,
    contactPhone: contactPhone ?? this.contactPhone,
    contactEmail: contactEmail ?? this.contactEmail,
    agentLicense: agentLicense ?? this.agentLicense,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isPremium: isPremium ?? this.isPremium,
    isFavorited: isFavorited ?? this.isFavorited,
    userId: userId ?? this.userId,
    availableDate: availableDate ?? this.availableDate,
    isActive: isActive ?? this.isActive,
  );
}