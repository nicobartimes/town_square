import 'package:cloud_firestore/cloud_firestore.dart';

class UserProfile {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String avatarUrl;
  final List<String> bookmarkedArticles;
  final List<String> bookmarkedVideos;
  final List<String> favoritedListings;
  final List<String> userListings;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isActive;

  UserProfile({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.avatarUrl,
    required this.bookmarkedArticles,
    this.bookmarkedVideos = const [],
    required this.favoritedListings,
    required this.userListings,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.isActive = true,
  }) : createdAt = createdAt ?? DateTime.now(),
       updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'email': email,
    'phone': phone,
    'avatarUrl': avatarUrl,
    'bookmarkedArticles': bookmarkedArticles,
    'bookmarkedVideos': bookmarkedVideos,
    'favoritedListings': favoritedListings,
    'userListings': userListings,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  factory UserProfile.fromMap(Map<String, dynamic> map) => UserProfile(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    email: map['email'] ?? '',
    phone: map['phone'] ?? '',
    avatarUrl: map['avatarUrl'] ?? '',
    bookmarkedArticles: List<String>.from(map['bookmarkedArticles'] ?? []),
    bookmarkedVideos: List<String>.from(map['bookmarkedVideos'] ?? []),
    favoritedListings: List<String>.from(map['favoritedListings'] ?? []),
    userListings: List<String>.from(map['userListings'] ?? []),
    createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    isActive: map['isActive'] ?? true,
  );

  factory UserProfile.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserProfile.fromMap({...data, 'id': doc.id});
  }

  UserProfile copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? avatarUrl,
    List<String>? bookmarkedArticles,
    List<String>? bookmarkedVideos,
    List<String>? favoritedListings,
    List<String>? userListings,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isActive,
  }) => UserProfile(
    id: id ?? this.id,
    name: name ?? this.name,
    email: email ?? this.email,
    phone: phone ?? this.phone,
    avatarUrl: avatarUrl ?? this.avatarUrl,
    bookmarkedArticles: bookmarkedArticles ?? this.bookmarkedArticles,
    bookmarkedVideos: bookmarkedVideos ?? this.bookmarkedVideos,
    favoritedListings: favoritedListings ?? this.favoritedListings,
    userListings: userListings ?? this.userListings,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isActive: isActive ?? this.isActive,
  );
}