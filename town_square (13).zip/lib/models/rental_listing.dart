import 'package:cloud_firestore/cloud_firestore.dart';

class RentalListing {
  final String id;
  final String title;
  final String description;
  final double monthlyRent;
  final double? securityDeposit;
  final List<String> imageUrls;
  final String propertyType; // Apartment, House, Room, Studio, etc.
  final String address;
  final int bedrooms;
  final int bathrooms;
  final int? squareFootage;
  final List<String> amenities;
  final List<String> utilities; // What's included
  final bool petsAllowed;
  final bool smokingAllowed;
  final DateTime availableFrom;
  final int? leaseDuration; // in months
  final String contactName;
  final String contactPhone;
  final String contactEmail;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPremium;
  final bool isFavorited;
  final String userId;
  final bool furnished;
  final int? parkingSpaces;
  final bool isActive;

  RentalListing({
    required this.id,
    required this.title,
    required this.description,
    required this.monthlyRent,
    this.securityDeposit,
    required this.imageUrls,
    required this.propertyType,
    required this.address,
    required this.bedrooms,
    required this.bathrooms,
    this.squareFootage,
    required this.amenities,
    required this.utilities,
    this.petsAllowed = false,
    this.smokingAllowed = false,
    required this.availableFrom,
    this.leaseDuration,
    required this.contactName,
    required this.contactPhone,
    required this.contactEmail,
    required this.createdAt,
    required this.updatedAt,
    this.isPremium = false,
    this.isFavorited = false,
    required this.userId,
    this.furnished = false,
    this.parkingSpaces,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'monthlyRent': monthlyRent,
    'securityDeposit': securityDeposit,
    'imageUrls': imageUrls,
    'propertyType': propertyType,
    'address': address,
    'bedrooms': bedrooms,
    'bathrooms': bathrooms,
    'squareFootage': squareFootage,
    'amenities': amenities,
    'utilities': utilities,
    'petsAllowed': petsAllowed,
    'smokingAllowed': smokingAllowed,
    'availableFrom': availableFrom.millisecondsSinceEpoch,
    'leaseDuration': leaseDuration,
    'contactName': contactName,
    'contactPhone': contactPhone,
    'contactEmail': contactEmail,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'isPremium': isPremium,
    'isFavorited': isFavorited,
    'userId': userId,
    'furnished': furnished,
    'parkingSpaces': parkingSpaces,
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  factory RentalListing.fromMap(Map<String, dynamic> map) => RentalListing(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    monthlyRent: map['monthlyRent']?.toDouble() ?? 0.0,
    securityDeposit: map['securityDeposit']?.toDouble(),
    imageUrls: List<String>.from(map['imageUrls'] ?? []),
    propertyType: map['propertyType'] ?? '',
    address: map['address'] ?? '',
    bedrooms: map['bedrooms'] ?? 0,
    bathrooms: map['bathrooms'] ?? 0,
    squareFootage: map['squareFootage'],
    amenities: List<String>.from(map['amenities'] ?? []),
    utilities: List<String>.from(map['utilities'] ?? []),
    petsAllowed: map['petsAllowed'] ?? false,
    smokingAllowed: map['smokingAllowed'] ?? false,
    availableFrom: DateTime.fromMillisecondsSinceEpoch(map['availableFrom'] ?? 0),
    leaseDuration: map['leaseDuration'],
    contactName: map['contactName'] ?? '',
    contactPhone: map['contactPhone'] ?? '',
    contactEmail: map['contactEmail'] ?? '',
    createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    isPremium: map['isPremium'] ?? false,
    isFavorited: map['isFavorited'] ?? false,
    userId: map['userId'] ?? '',
    furnished: map['furnished'] ?? false,
    parkingSpaces: map['parkingSpaces'],
    isActive: map['isActive'] ?? true,
  );

  factory RentalListing.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return RentalListing.fromMap({...data, 'id': doc.id});
  }

  factory RentalListing.fromJson(Map<String, dynamic> json) => RentalListing.fromMap(json);

  Map<String, dynamic> toJson() => toMap();

  RentalListing copyWith({
    String? id,
    String? title,
    String? description,
    double? monthlyRent,
    double? securityDeposit,
    List<String>? imageUrls,
    String? propertyType,
    String? address,
    int? bedrooms,
    int? bathrooms,
    int? squareFootage,
    List<String>? amenities,
    List<String>? utilities,
    bool? petsAllowed,
    bool? smokingAllowed,
    DateTime? availableFrom,
    int? leaseDuration,
    String? contactName,
    String? contactPhone,
    String? contactEmail,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPremium,
    bool? isFavorited,
    String? userId,
    bool? furnished,
    int? parkingSpaces,
    bool? isActive,
  }) => RentalListing(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    monthlyRent: monthlyRent ?? this.monthlyRent,
    securityDeposit: securityDeposit ?? this.securityDeposit,
    imageUrls: imageUrls ?? this.imageUrls,
    propertyType: propertyType ?? this.propertyType,
    address: address ?? this.address,
    bedrooms: bedrooms ?? this.bedrooms,
    bathrooms: bathrooms ?? this.bathrooms,
    squareFootage: squareFootage ?? this.squareFootage,
    amenities: amenities ?? this.amenities,
    utilities: utilities ?? this.utilities,
    petsAllowed: petsAllowed ?? this.petsAllowed,
    smokingAllowed: smokingAllowed ?? this.smokingAllowed,
    availableFrom: availableFrom ?? this.availableFrom,
    leaseDuration: leaseDuration ?? this.leaseDuration,
    contactName: contactName ?? this.contactName,
    contactPhone: contactPhone ?? this.contactPhone,
    contactEmail: contactEmail ?? this.contactEmail,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isPremium: isPremium ?? this.isPremium,
    isFavorited: isFavorited ?? this.isFavorited,
    userId: userId ?? this.userId,
    furnished: furnished ?? this.furnished,
    parkingSpaces: parkingSpaces ?? this.parkingSpaces,
    isActive: isActive ?? this.isActive,
  );
}