import 'package:cloud_firestore/cloud_firestore.dart';

class JobListing {
  final String id;
  final String title;
  final String description;
  final String companyName;
  final String category; // Technology, Healthcare, Finance, etc.
  final String jobType; // Full-time, Part-time, Contract, Internship
  final String workArrangement; // Remote, Hybrid, On-site
  final double? salaryMin;
  final double? salaryMax;
  final String? salaryType; // Hourly, Annual
  final List<String> imageUrls;
  final String location;
  final List<String> requirements;
  final List<String> responsibilities;
  final List<String> benefits;
  final String experienceLevel; // Entry, Mid, Senior, Executive
  final String education; // High School, Bachelor's, Master's, etc.
  final List<String> skills;
  final String contactName;
  final String contactPhone;
  final String contactEmail;
  final String? applicationUrl;
  final DateTime applicationDeadline;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPremium;
  final bool isFavorited;
  final String userId;
  final bool isUrgent;
  final bool isActive;

  JobListing({
    required this.id,
    required this.title,
    required this.description,
    required this.companyName,
    required this.category,
    required this.jobType,
    required this.workArrangement,
    this.salaryMin,
    this.salaryMax,
    this.salaryType,
    required this.imageUrls,
    required this.location,
    required this.requirements,
    required this.responsibilities,
    required this.benefits,
    required this.experienceLevel,
    required this.education,
    required this.skills,
    required this.contactName,
    required this.contactPhone,
    required this.contactEmail,
    this.applicationUrl,
    required this.applicationDeadline,
    required this.createdAt,
    required this.updatedAt,
    this.isPremium = false,
    this.isFavorited = false,
    required this.userId,
    this.isUrgent = false,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'companyName': companyName,
    'category': category,
    'jobType': jobType,
    'workArrangement': workArrangement,
    'salaryMin': salaryMin,
    'salaryMax': salaryMax,
    'salaryType': salaryType,
    'imageUrls': imageUrls,
    'location': location,
    'requirements': requirements,
    'responsibilities': responsibilities,
    'benefits': benefits,
    'experienceLevel': experienceLevel,
    'education': education,
    'skills': skills,
    'contactName': contactName,
    'contactPhone': contactPhone,
    'contactEmail': contactEmail,
    'applicationUrl': applicationUrl,
    'applicationDeadline': applicationDeadline.millisecondsSinceEpoch,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'isPremium': isPremium,
    'isFavorited': isFavorited,
    'userId': userId,
    'isUrgent': isUrgent,
    'isActive': isActive,
  };

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id'); // Remove ID when saving to Firestore
    return data;
  }

  factory JobListing.fromMap(Map<String, dynamic> map) => JobListing(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    companyName: map['companyName'] ?? '',
    category: map['category'] ?? '',
    jobType: map['jobType'] ?? '',
    workArrangement: map['workArrangement'] ?? '',
    salaryMin: map['salaryMin']?.toDouble(),
    salaryMax: map['salaryMax']?.toDouble(),
    salaryType: map['salaryType'],
    imageUrls: List<String>.from(map['imageUrls'] ?? []),
    location: map['location'] ?? '',
    requirements: List<String>.from(map['requirements'] ?? []),
    responsibilities: List<String>.from(map['responsibilities'] ?? []),
    benefits: List<String>.from(map['benefits'] ?? []),
    experienceLevel: map['experienceLevel'] ?? '',
    education: map['education'] ?? '',
    skills: List<String>.from(map['skills'] ?? []),
    contactName: map['contactName'] ?? '',
    contactPhone: map['contactPhone'] ?? '',
    contactEmail: map['contactEmail'] ?? '',
    applicationUrl: map['applicationUrl'],
    applicationDeadline: DateTime.fromMillisecondsSinceEpoch(map['applicationDeadline'] ?? 0),
    createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    isPremium: map['isPremium'] ?? false,
    isFavorited: map['isFavorited'] ?? false,
    userId: map['userId'] ?? '',
    isUrgent: map['isUrgent'] ?? false,
    isActive: map['isActive'] ?? true,
  );

  factory JobListing.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return JobListing.fromMap({...data, 'id': doc.id});
  }

  factory JobListing.fromJson(Map<String, dynamic> json) => JobListing.fromMap(json);

  Map<String, dynamic> toJson() => toMap();

  JobListing copyWith({
    String? id,
    String? title,
    String? description,
    String? companyName,
    String? category,
    String? jobType,
    String? workArrangement,
    double? salaryMin,
    double? salaryMax,
    String? salaryType,
    List<String>? imageUrls,
    String? location,
    List<String>? requirements,
    List<String>? responsibilities,
    List<String>? benefits,
    String? experienceLevel,
    String? education,
    List<String>? skills,
    String? contactName,
    String? contactPhone,
    String? contactEmail,
    String? applicationUrl,
    DateTime? applicationDeadline,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPremium,
    bool? isFavorited,
    String? userId,
    bool? isUrgent,
    bool? isActive,
  }) => JobListing(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    companyName: companyName ?? this.companyName,
    category: category ?? this.category,
    jobType: jobType ?? this.jobType,
    workArrangement: workArrangement ?? this.workArrangement,
    salaryMin: salaryMin ?? this.salaryMin,
    salaryMax: salaryMax ?? this.salaryMax,
    salaryType: salaryType ?? this.salaryType,
    imageUrls: imageUrls ?? this.imageUrls,
    location: location ?? this.location,
    requirements: requirements ?? this.requirements,
    responsibilities: responsibilities ?? this.responsibilities,
    benefits: benefits ?? this.benefits,
    experienceLevel: experienceLevel ?? this.experienceLevel,
    education: education ?? this.education,
    skills: skills ?? this.skills,
    contactName: contactName ?? this.contactName,
    contactPhone: contactPhone ?? this.contactPhone,
    contactEmail: contactEmail ?? this.contactEmail,
    applicationUrl: applicationUrl ?? this.applicationUrl,
    applicationDeadline: applicationDeadline ?? this.applicationDeadline,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isPremium: isPremium ?? this.isPremium,
    isFavorited: isFavorited ?? this.isFavorited,
    userId: userId ?? this.userId,
    isUrgent: isUrgent ?? this.isUrgent,
    isActive: isActive ?? this.isActive,
  );
}