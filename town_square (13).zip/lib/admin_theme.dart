import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:town_square/theme.dart';

class AdminColors {
  static const adminPrimary = Color(0xFF2E7D32); // Deep green for admin
  static const adminOnPrimary = Color(0xFFFFFFFF);
  static const adminSecondary = Color(0xFF37474F); // Blue grey for secondary
  static const adminOnSecondary = Color(0xFFFFFFFF);
  static const adminAccent = Color(0xFF4CAF50); // Green accent
  static const adminError = Color(0xFFD32F2F);
  static const adminWarning = Color(0xFFFF9800);
  static const adminSuccess = Color(0xFF4CAF50);
  static const adminInfo = Color(0xFF2196F3);
  static const adminBackground = Color(0xFFF5F7FA);
  static const adminSurface = Color(0xFFFFFFFF);
  static const adminCardBackground = Color(0xFFFFFFFF);
  static const adminSidebarBackground = Color(0xFF263238);
  static const adminSidebarText = Color(0xFFECEFF1);
}

// Admin Theme for enhanced admin panel styling
ThemeData get adminTheme => ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.light(
    primary: AdminColors.adminPrimary,
    onPrimary: AdminColors.adminOnPrimary,
    secondary: AdminColors.adminSecondary,
    onSecondary: AdminColors.adminOnSecondary,
    tertiary: AdminColors.adminAccent,
    error: AdminColors.adminError,
    surface: AdminColors.adminSurface,
    onSurface: Colors.black87,
    surfaceContainerLowest: AdminColors.adminBackground,
    surfaceContainerLow: AdminColors.adminCardBackground,
  ),
  brightness: Brightness.light,
  appBarTheme: AppBarTheme(
    backgroundColor: AdminColors.adminPrimary,
    foregroundColor: Colors.white,
    elevation: 2,
    centerTitle: false,
    titleTextStyle: GoogleFonts.inter(
      fontSize: 20,
      fontWeight: FontWeight.w600,
      color: Colors.white,
    ),
  ),
  cardTheme: CardThemeData(
    elevation: 2,
    color: AdminColors.adminCardBackground,
    shadowColor: Colors.black.withValues(alpha: 0.1),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: AdminColors.adminPrimary,
      foregroundColor: Colors.white,
      elevation: 2,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    ),
  ),
  navigationRailTheme: NavigationRailThemeData(
    backgroundColor: AdminColors.adminSidebarBackground,
    selectedIconTheme: const IconThemeData(
      color: Colors.white,
      size: 24,
    ),
    unselectedIconTheme: IconThemeData(
      color: AdminColors.adminSidebarText.withValues(alpha: 0.7),
      size: 24,
    ),
    selectedLabelTextStyle: GoogleFonts.inter(
      color: Colors.white,
      fontWeight: FontWeight.w600,
      fontSize: 12,
    ),
    unselectedLabelTextStyle: GoogleFonts.inter(
      color: AdminColors.adminSidebarText.withValues(alpha: 0.7),
      fontWeight: FontWeight.w500,
      fontSize: 12,
    ),
    indicatorColor: AdminColors.adminAccent.withValues(alpha: 0.2),
  ),
  textTheme: TextTheme(
    displayLarge: GoogleFonts.inter(
      fontSize: FontSizes.displayLarge,
      fontWeight: FontWeight.bold,
      color: AdminColors.adminPrimary,
    ),
    headlineMedium: GoogleFonts.inter(
      fontSize: FontSizes.headlineMedium,
      fontWeight: FontWeight.w600,
      color: AdminColors.adminPrimary,
    ),
    titleLarge: GoogleFonts.inter(
      fontSize: FontSizes.titleLarge,
      fontWeight: FontWeight.w600,
      color: Colors.black87,
    ),
    bodyLarge: GoogleFonts.inter(
      fontSize: FontSizes.bodyLarge,
      fontWeight: FontWeight.normal,
      color: Colors.black87,
    ),
    bodyMedium: GoogleFonts.inter(
      fontSize: FontSizes.bodyMedium,
      fontWeight: FontWeight.normal,
      color: Colors.black87,
    ),
  ),
  scaffoldBackgroundColor: AdminColors.adminBackground,
);