// Firestore Data Schema for Town Square App
// This file defines the structure of data stored in Firebase Firestore

class FirestoreCollections {
  static const String newsArticles = 'news_articles';
  static const String videoNews = 'video_news';
  static const String jobListings = 'job_listings';
  static const String businessListings = 'business_listings';
  static const String realEstateListings = 'real_estate_listings';
  static const String rentalListings = 'rental_listings';
  static const String users = 'users';
  static const String adminUsers = 'admin_users';
}

class FirestoreFields {
  // Common fields
  static const String id = 'id';
  static const String title = 'title';
  static const String description = 'description';
  static const String imageUrl = 'image_url';
  static const String createdAt = 'created_at';
  static const String updatedAt = 'updated_at';
  static const String isActive = 'is_active';
  static const String isPremium = 'is_premium';
  
  // News Articles
  static const String content = 'content';
  static const String author = 'author';
  static const String category = 'category';
  static const String publishedAt = 'published_at';
  static const String readTime = 'read_time';
  static const String tags = 'tags';
  static const String viewCount = 'view_count';
  
  // Video News
  static const String videoId = 'video_id';
  static const String videoUrl = 'video_url';
  static const String duration = 'duration';
  static const String thumbnailUrl = 'thumbnail_url';
  
  // Job Listings
  static const String company = 'company';
  static const String location = 'location';
  static const String salary = 'salary';
  static const String jobType = 'job_type';
  static const String requirements = 'requirements';
  static const String benefits = 'benefits';
  static const String applicationUrl = 'application_url';
  static const String companyLogo = 'company_logo';
  static const String experience = 'experience';
  
  // Business Listings
  static const String businessName = 'business_name';
  static const String address = 'address';
  static const String phone = 'phone';
  static const String email = 'email';
  static const String website = 'website';
  static const String operatingHours = 'operating_hours';
  static const String services = 'services';
  static const String rating = 'rating';
  static const String reviewCount = 'review_count';
  
  // Real Estate & Rentals
  static const String price = 'price';
  static const String type = 'type';
  static const String bedrooms = 'bedrooms';
  static const String bathrooms = 'bathrooms';
  static const String area = 'area';
  static const String amenities = 'amenities';
  static const String contactInfo = 'contact_info';
  static const String images = 'images';
  static const String furnished = 'furnished';
  static const String deposit = 'deposit';
  static const String monthlyRent = 'monthly_rent';
  
  // Users
  static const String name = 'name';
  static const String profilePicture = 'profile_picture';
  static const String joinedAt = 'joined_at';
  static const String bookmarks = 'bookmarks';
  static const String preferences = 'preferences';
  
  // Admin Users
  static const String role = 'role';
  static const String permissions = 'permissions';
  static const String lastLogin = 'last_login';
}

// Default values for timestamps
class TimestampValues {
  static const String timestamp = 'TIMESTAMP';
}

// Validation rules for different content types
class ValidationRules {
  static const int maxTitleLength = 200;
  static const int maxDescriptionLength = 1000;
  static const int maxContentLength = 50000;
  static const int maxImageSize = 5 * 1024 * 1024; // 5MB
  static const List<String> allowedImageTypes = ['jpg', 'jpeg', 'png', 'webp'];
}

// Categories and types
class Categories {
  static const List<String> newsCategories = [
    'Breaking News',
    'Politics',
    'Technology',
    'Sports',
    'Entertainment',
    'Health',
    'Science',
    'Business',
    'World',
    'Local'
  ];
  
  static const List<String> jobCategories = [
    'Technology',
    'Healthcare',
    'Education',
    'Finance',
    'Marketing',
    'Sales',
    'Engineering',
    'Design',
    'Customer Service',
    'Administration',
    'Other'
  ];
  
  static const List<String> businessCategories = [
    'Restaurants',
    'Retail',
    'Healthcare',
    'Education',
    'Professional Services',
    'Home Services',
    'Automotive',
    'Beauty & Wellness',
    'Entertainment',
    'Technology',
    'Other'
  ];
  
  static const List<String> realEstateTypes = [
    'House',
    'Apartment',
    'Land',
    'Commercial',
    'Villa',
    'Townhouse'
  ];
  
  static const List<String> rentalTypes = [
    'Apartment',
    'House',
    'Room',
    'Studio',
    'Villa',
    'Townhouse'
  ];
}