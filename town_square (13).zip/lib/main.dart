import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:town_square/theme.dart';
import 'package:town_square/screens/home_screen.dart';
import 'package:town_square/screens/auth/login_screen.dart';
import 'package:town_square/screens/welcome_screen.dart';
import 'package:town_square/admin/admin_login_screen.dart';
import 'package:town_square/admin/admin_dashboard.dart';
import 'package:town_square/admin/admin_welcome_screen.dart';
import 'package:town_square/services/firebase_service_manager.dart';
import 'package:town_square/services/firebase_auth_service.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    debugPrint('✅ Firebase initialized successfully');
    debugPrint('🔥 Project: ${Firebase.app().options.projectId}');
    debugPrint('📂 Storage: ${Firebase.app().options.storageBucket}');
    
    // Initialize Firebase Service Manager
    await FirebaseServiceManager().initialize();
    
    // Create default admin user if it doesn't exist
    await _createDefaultAdmin();
  } catch (e) {
    // Firebase not configured yet - app will work with mock data
    debugPrint('❌ Firebase initialization failed: $e');
    if (e.toString().contains('network')) {
      debugPrint('🌐 Network error - check internet connection');
    } else if (e.toString().contains('configuration')) {
      debugPrint('⚙️ Configuration error - check Firebase setup');
    }
  }
  
  runApp(const MyApp());
}

/// Creates a default admin user for first-time setup
Future<void> _createDefaultAdmin() async {
  try {
    final serviceManager = FirebaseServiceManager();
    const adminEmail = 'admin@townsquare.com';
    const adminPassword = 'admin123';
    
    debugPrint('🔧 Setting up default admin user...');
    
    // Always ensure admin user exists in Firestore (this handles if it was deleted)
    await serviceManager.ensureAdminUserExists(adminEmail);
    
    // Try to create the admin user in Firebase Authentication
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: adminEmail,
        password: adminPassword,
      );
      debugPrint('✅ Default admin user created in Firebase Auth');
      
      // Update display name
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.updateDisplayName('Administrator');
      }
      
      // Sign out the admin user (we just created it for setup)
      await FirebaseAuth.instance.signOut();
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        debugPrint('✅ Admin user already exists in Firebase Auth');
        
        // Ensure Firestore entry exists even if Firebase Auth user exists
        await serviceManager.ensureAdminUserExists(adminEmail);
      } else {
        debugPrint('❌ Error creating admin in Firebase Auth: ${e.message}');
        // Still try to ensure Firestore entry exists
        await serviceManager.ensureAdminUserExists(adminEmail);
      }
    }
    
    // Verify admin setup
    final isAdminVerified = await serviceManager.isAdminUser(adminEmail);
    if (isAdminVerified) {
      debugPrint('🔐 DEFAULT ADMIN CREDENTIALS:');
      debugPrint('📧 Email: $adminEmail');
      debugPrint('🔑 Password: $adminPassword (or your custom password)');
      debugPrint('🌐 Access admin panel at: /#/admin');
      debugPrint('✅ Admin user setup completed and verified successfully!');
    } else {
      debugPrint('❌ Admin verification failed - admin user may not be properly set up');
    }
  } catch (e) {
    debugPrint('❌ Error creating default admin: $e');
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Town Square',
      debugShowCheckedModeBanner: false,
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: ThemeMode.system,
      initialRoute: '/',
      routes: {
        '/': (context) => const AuthWrapper(),
        '/admin': (context) => const AdminAuthWrapper(),
        '/admin-welcome': (context) => const AdminWelcomeScreen(),
        '/login': (context) => const LoginScreen(),
        '/welcome': (context) => const WelcomeScreen(),
      },
    );
  }
}

/// Main authentication wrapper for the app
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
        
        if (snapshot.hasData) {
          return const HomePage();
        }
        
        return const LoginScreen();
      },
    );
  }
}

class AdminAuthWrapper extends StatelessWidget {
  const AdminAuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
        
        if (snapshot.hasData) {
          // Check if user is admin
          return FutureBuilder<bool>(
            future: FirebaseAuthService().isAdminUser(),
            builder: (context, adminSnapshot) {
              if (adminSnapshot.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  body: Center(
                    child: CircularProgressIndicator(),
                  ),
                );
              }
              
              if (adminSnapshot.data == true) {
                return const AdminDashboard();
              } else {
                // User is logged in but not admin - show error and logout
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Access denied: Admin privileges required'),
                      backgroundColor: Colors.red,
                    ),
                  );
                  FirebaseAuth.instance.signOut();
                });
                return const AdminWelcomeScreen();
              }
            },
          );
        }
        
        return const AdminWelcomeScreen();
      },
    );
  }
}
