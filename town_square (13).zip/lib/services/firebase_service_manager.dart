import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

/// Central Firebase service manager that provides unified access to all Firebase services
/// and handles authentication, error handling, and service coordination
class FirebaseServiceManager {
  static final FirebaseServiceManager _instance = FirebaseServiceManager._internal();
  factory FirebaseServiceManager() => _instance;
  FirebaseServiceManager._internal();

  // Firebase service instances
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // Getters for service instances
  FirebaseAuth get auth => _auth;
  FirebaseFirestore get firestore => _firestore;
  FirebaseStorage get storage => _storage;

  // Current user stream
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Current user getter
  User? get currentUser => _auth.currentUser;

  // Check if user is authenticated
  bool get isAuthenticated => _auth.currentUser != null;

  /// Initialize Firebase services and set up configurations
  Future<void> initialize() async {
    try {
      // Configure Firestore settings for better performance
      _firestore.settings = const Settings(
        persistenceEnabled: true,
        cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
      );

      // Enable offline persistence for mobile platforms
      if (!kIsWeb) {
        await _firestore.enableNetwork();
      }

      debugPrint('Firebase services initialized successfully');
    } catch (e) {
      debugPrint('Error initializing Firebase services: $e');
    }
  }

  /// Sign in with email and password
  Future<UserCredential?> signInWithEmailAndPassword(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      debugPrint('User signed in: ${result.user?.email}');
      return result;
    } on FirebaseAuthException catch (e) {
      debugPrint('Firebase Auth Error: ${e.code} - ${e.message}');
      rethrow;
    } catch (e) {
      debugPrint('Sign in error: $e');
      rethrow;
    }
  }

  /// Create user account with email and password
  Future<UserCredential?> createUserWithEmailAndPassword(String email, String password) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      debugPrint('User account created: ${result.user?.email}');
      return result;
    } on FirebaseAuthException catch (e) {
      debugPrint('Firebase Auth Error: ${e.code} - ${e.message}');
      rethrow;
    } catch (e) {
      debugPrint('Create account error: $e');
      rethrow;
    }
  }

  /// Sign out current user
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      debugPrint('User signed out successfully');
    } catch (e) {
      debugPrint('Sign out error: $e');
      rethrow;
    }
  }

  /// Reset password for given email
  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      debugPrint('Password reset email sent to: $email');
    } on FirebaseAuthException catch (e) {
      debugPrint('Firebase Auth Error: ${e.code} - ${e.message}');
      rethrow;
    } catch (e) {
      debugPrint('Reset password error: $e');
      rethrow;
    }
  }

  /// Get a Firestore collection reference
  CollectionReference getCollection(String collectionName) {
    return _firestore.collection(collectionName);
  }

  /// Get a Firestore document reference
  DocumentReference getDocument(String collection, String documentId) {
    return _firestore.collection(collection).doc(documentId);
  }

  /// Add a document to a collection
  Future<DocumentReference> addDocument(String collection, Map<String, dynamic> data) async {
    try {
      // Add timestamps
      data[FirestoreFields.createdAt] = FieldValue.serverTimestamp();
      data[FirestoreFields.updatedAt] = FieldValue.serverTimestamp();
      
      DocumentReference result = await _firestore.collection(collection).add(data);
      debugPrint('Document added to $collection: ${result.id}');
      return result;
    } catch (e) {
      debugPrint('Error adding document to $collection: $e');
      rethrow;
    }
  }

  /// Update a document in a collection
  Future<void> updateDocument(String collection, String documentId, Map<String, dynamic> data) async {
    try {
      // Add updated timestamp
      data[FirestoreFields.updatedAt] = FieldValue.serverTimestamp();
      
      await _firestore.collection(collection).doc(documentId).update(data);
      debugPrint('Document updated in $collection: $documentId');
    } catch (e) {
      debugPrint('Error updating document in $collection: $e');
      rethrow;
    }
  }

  /// Delete a document from a collection
  Future<void> deleteDocument(String collection, String documentId) async {
    try {
      await _firestore.collection(collection).doc(documentId).delete();
      debugPrint('Document deleted from $collection: $documentId');
    } catch (e) {
      debugPrint('Error deleting document from $collection: $e');
      rethrow;
    }
  }

  /// Get documents from a collection with optional filters
  Future<QuerySnapshot> getDocuments(String collection, {
    String? orderBy,
    bool descending = false,
    int? limit,
    String? whereField,
    dynamic whereValue,
  }) async {
    try {
      Query query = _firestore.collection(collection);

      if (whereField != null && whereValue != null) {
        query = query.where(whereField, isEqualTo: whereValue);
      }

      if (orderBy != null) {
        query = query.orderBy(orderBy, descending: descending);
      }

      if (limit != null) {
        query = query.limit(limit);
      }

      QuerySnapshot result = await query.get();
      debugPrint('Retrieved ${result.docs.length} documents from $collection');
      return result;
    } catch (e) {
      debugPrint('Error getting documents from $collection: $e');
      rethrow;
    }
  }

  /// Get real-time stream of documents from a collection
  Stream<QuerySnapshot> getDocumentsStream(String collection, {
    String? orderBy,
    bool descending = false,
    int? limit,
    String? whereField,
    dynamic whereValue,
  }) {
    try {
      Query query = _firestore.collection(collection);

      if (whereField != null && whereValue != null) {
        query = query.where(whereField, isEqualTo: whereValue);
      }

      if (orderBy != null) {
        query = query.orderBy(orderBy, descending: descending);
      }

      if (limit != null) {
        query = query.limit(limit);
      }

      return query.snapshots();
    } catch (e) {
      debugPrint('Error getting documents stream from $collection: $e');
      rethrow;
    }
  }

  /// Upload file to Firebase Storage
  Future<String> uploadFile(String path, List<int> fileBytes, String fileName) async {
    try {
      Reference storageRef = _storage.ref().child('$path/$fileName');
      UploadTask uploadTask = storageRef.putData(Uint8List.fromList(fileBytes));
      TaskSnapshot snapshot = await uploadTask;
      String downloadUrl = await snapshot.ref.getDownloadURL();
      debugPrint('File uploaded successfully: $downloadUrl');
      return downloadUrl;
    } catch (e) {
      debugPrint('Error uploading file: $e');
      rethrow;
    }
  }

  /// Delete file from Firebase Storage
  Future<void> deleteFile(String url) async {
    try {
      Reference storageRef = _storage.refFromURL(url);
      await storageRef.delete();
      debugPrint('File deleted successfully: $url');
    } catch (e) {
      debugPrint('Error deleting file: $e');
      rethrow;
    }
  }

  /// Check if admin user exists
  Future<bool> isAdminUser(String email) async {
    try {
      QuerySnapshot result = await _firestore
          .collection(FirestoreCollections.adminUsers)
          .where(FirestoreFields.email, isEqualTo: email)
          .limit(1)
          .get();
      return result.docs.isNotEmpty;
    } catch (e) {
      debugPrint('Error checking admin user: $e');
      return false;
    }
  }

  /// Force create or update admin user entry in Firestore
  Future<void> ensureAdminUserExists(String email) async {
    try {
      // Check if admin already exists
      QuerySnapshot existingAdmin = await _firestore
          .collection(FirestoreCollections.adminUsers)
          .where(FirestoreFields.email, isEqualTo: email)
          .limit(1)
          .get();

      if (existingAdmin.docs.isEmpty) {
        // Create admin user document
        await addDocument(FirestoreCollections.adminUsers, {
          FirestoreFields.email: email,
          'role': 'super_admin',
          'isActive': true,
          'permissions': ['read', 'write', 'delete', 'manage_users'],
        });
        debugPrint('✅ Admin user created in Firestore: $email');
      } else {
        debugPrint('✅ Admin user already exists in Firestore: $email');
      }
    } catch (e) {
      debugPrint('❌ Error ensuring admin user exists: $e');
      rethrow;
    }
  }

  /// Get user profile data
  Future<DocumentSnapshot?> getUserProfile(String userId) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection(FirestoreCollections.users)
          .doc(userId)
          .get();
      return doc.exists ? doc : null;
    } catch (e) {
      debugPrint('Error getting user profile: $e');
      return null;
    }
  }

  /// Create or update user profile
  Future<void> setUserProfile(String userId, Map<String, dynamic> profileData) async {
    try {
      profileData[FirestoreFields.updatedAt] = FieldValue.serverTimestamp();
      await _firestore
          .collection(FirestoreCollections.users)
          .doc(userId)
          .set(profileData, SetOptions(merge: true));
      debugPrint('User profile updated: $userId');
    } catch (e) {
      debugPrint('Error setting user profile: $e');
      rethrow;
    }
  }

  /// Get analytics data for admin dashboard
  Future<Map<String, int>> getAnalyticsData() async {
    try {
      final results = await Future.wait([
        getDocuments(FirestoreCollections.newsArticles),
        getDocuments(FirestoreCollections.videoNews),
        getDocuments(FirestoreCollections.jobListings),
        getDocuments(FirestoreCollections.businessListings),
        getDocuments(FirestoreCollections.realEstateListings),
        getDocuments(FirestoreCollections.rentalListings),
        getDocuments(FirestoreCollections.users),
      ]);

      return {
        'newsArticles': results[0].docs.length,
        'videoNews': results[1].docs.length,
        'jobListings': results[2].docs.length,
        'businessListings': results[3].docs.length,
        'realEstateListings': results[4].docs.length,
        'rentalListings': results[5].docs.length,
        'users': results[6].docs.length,
      };
    } catch (e) {
      debugPrint('Error getting analytics data: $e');
      return {};
    }
  }

  /// Dispose resources when no longer needed
  void dispose() {
    // Clean up any listeners or resources if needed
    debugPrint('Firebase Service Manager disposed');
  }
}