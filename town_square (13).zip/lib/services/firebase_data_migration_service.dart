import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:town_square/services/firebase_service_manager.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

/// Firebase Data Migration Service
/// Handles initial data seeding and database migrations
class FirebaseDataMigrationService {
  static final FirebaseDataMigrationService _instance = FirebaseDataMigrationService._internal();
  factory FirebaseDataMigrationService() => _instance;
  FirebaseDataMigrationService._internal();

  final FirebaseServiceManager _serviceManager = FirebaseServiceManager();

  /// Seed database with initial sample data
  Future<bool> seedDatabase() async {
    try {
      debugPrint('🌱 Starting database seeding...');
      
      // Check if data already exists
      final hasData = await _hasExistingData();
      if (hasData) {
        debugPrint('📝 Database already contains data, skipping seeding');
        return true;
      }

      // Seed all data types
      await Future.wait([
        _seedNewsArticles(),
        _seedVideoNews(),
        _seedJobListings(),
        _seedBusinessListings(),
        _seedRealEstateListings(),
        _seedRentalListings(),
      ]);

      debugPrint('✅ Database seeding completed successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Error seeding database: $e');
      return false;
    }
  }

  /// Check if database already has data
  Future<bool> _hasExistingData() async {
    try {
      final snapshot = await _serviceManager.getCollection(FirestoreCollections.newsArticles).limit(1).get();
      return snapshot.docs.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  /// Seed news articles
  Future<void> _seedNewsArticles() async {
    final articles = [
      {
        'title': 'Local Tech Startup Raises \$2M in Series A Funding',
        'content': 'A local technology startup focused on sustainable urban solutions has successfully raised \$2 million in Series A funding. The company, founded in 2022, has developed an innovative platform that helps cities optimize their energy consumption and reduce carbon emissions.',
        'summary': 'Local tech startup secures \$2M to expand sustainable urban solutions platform.',
        'description': 'Local tech startup secures \$2M to expand sustainable urban solutions platform.',
        'source': 'Town Square News',
        'author': 'Town Square News',
        'category': 'Business',
        'imageUrl': 'https://picsum.photos/800/400?random=1',
        'publishedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 2))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 2))),
        'readTime': 3,
        'tags': ['technology', 'funding', 'sustainability', 'startups'],
        'isActive': true,
        'isBookmarked': false,
        'viewCount': 145,
      },
      {
        'title': 'New Community Park Opens Downtown with Modern Amenities',
        'content': 'The city\'s newest community park officially opened this weekend, featuring state-of-the-art playground equipment, walking trails, and recreational facilities. The 15-acre park represents a significant investment in community infrastructure and green space.',
        'summary': 'New 15-acre downtown park opens with modern amenities and sustainable features.',
        'description': 'New 15-acre downtown park opens with modern amenities and sustainable features.',
        'source': 'Town Square News',
        'author': 'Town Square News',
        'category': 'Local',
        'imageUrl': 'https://picsum.photos/800/400?random=2',
        'publishedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 6))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 6))),
        'readTime': 4,
        'tags': ['community', 'parks', 'recreation', 'sustainability'],
        'isActive': true,
        'isBookmarked': false,
        'viewCount': 298,
      },
      {
        'title': 'Local High School Team Wins State Championship',
        'content': 'The Jefferson High School Eagles made history this weekend by winning their first state championship in basketball in over two decades. The team defeated the defending champions 78-72 in a thrilling final game.',
        'summary': 'Jefferson High Eagles win first state basketball championship in 20 years.',
        'description': 'Jefferson High Eagles win first state basketball championship in 20 years.',
        'source': 'Sports Desk',
        'author': 'Sports Desk',
        'category': 'Sports',
        'imageUrl': 'https://picsum.photos/800/400?random=3',
        'publishedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 8))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 8))),
        'readTime': 2,
        'tags': ['sports', 'basketball', 'high school', 'championship'],
        'isActive': true,
        'isBookmarked': false,
        'viewCount': 521,
      },
    ];

    for (var article in articles) {
      await _serviceManager.addDocument(FirestoreCollections.newsArticles, article);
    }
    
    debugPrint('📰 Seeded ${articles.length} news articles');
  }

  /// Seed video news
  Future<void> _seedVideoNews() async {
    final videos = [
      {
        'title': 'Weekly City Council Meeting Highlights',
        'description': 'Key discussions from this week\'s city council meeting including budget approvals and new development projects.',
        'category': 'Politics',
        'source': 'City Council',
        'channelName': 'Town Square TV',
        'videoId': 'dQw4w9WgXcQ',
        'videoUrl': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        'thumbnailUrl': 'https://picsum.photos/480/360?random=10',
        'duration': '12:34',
        'publishedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 4))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 4))),
        'isActive': true,
        'isBookmarked': false,
        'viewCount': 89,
      },
      {
        'title': 'Local Business Spotlight: Green Coffee Roasters',
        'description': 'Meet the owners of Green Coffee Roasters, a local business making waves with their sustainable coffee sourcing practices.',
        'category': 'Business',
        'source': 'Business Spotlight',
        'channelName': 'Town Square TV',
        'videoId': 'dQw4w9WgXcQ',
        'videoUrl': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        'thumbnailUrl': 'https://picsum.photos/480/360?random=11',
        'duration': '8:45',
        'publishedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 12))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 12))),
        'isActive': true,
        'isBookmarked': false,
        'viewCount': 156,
      },
    ];

    for (var video in videos) {
      await _serviceManager.addDocument(FirestoreCollections.videoNews, video);
    }
    
    debugPrint('🎥 Seeded ${videos.length} video news items');
  }

  /// Seed job listings
  Future<void> _seedJobListings() async {
    final jobs = [
      {
        'title': 'Senior Software Engineer',
        'description': 'Join our growing tech team to build innovative solutions for modern challenges. We\'re looking for an experienced software engineer with expertise in mobile and web development.',
        'company': 'TechFlow Solutions',
        'companyName': 'TechFlow Solutions',
        'location': 'Downtown Tech District',
        'salary': '\$85,000 - \$110,000',
        'salaryRange': '\$85,000 - \$110,000',
        'jobType': 'Full-time',
        'workArrangement': 'Hybrid',
        'category': 'Technology',
        'requirements': ['5+ years experience', 'Flutter/React experience', 'Team collaboration skills'],
        'responsibilities': ['Develop mobile applications', 'Code reviews', 'Team collaboration'],
        'benefits': ['Health insurance', 'Remote work options', 'Professional development budget'],
        'skills': ['Flutter', 'React', 'JavaScript', 'Mobile Development'],
        'education': 'Bachelor\'s degree preferred',
        'experienceLevel': 'Senior',
        'applicationUrl': 'https://techflow.com/careers',
        'companyLogo': 'https://picsum.photos/100/100?random=20',
        'experience': 'Senior Level',
        'applicationDeadline': Timestamp.fromDate(DateTime.now().add(const Duration(days: 30))),
        'contactName': 'HR Department',
        'contactEmail': 'hr@techflow.com',
        'contactPhone': '(555) 123-4567',
        'imageUrl': 'https://picsum.photos/600/400?random=30',
        'imageUrls': ['https://picsum.photos/600/400?random=30'],
        'userId': 'admin',
        'createdAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 3))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 3))),
        'isActive': true,
        'isPremium': true,
      },
    ];

    for (var job in jobs) {
      await _serviceManager.addDocument(FirestoreCollections.jobListings, job);
    }
    
    debugPrint('💼 Seeded ${jobs.length} job listings');
  }

  /// Seed business listings
  Future<void> _seedBusinessListings() async {
    final businesses = [
      {
        'title': 'Green Coffee Roasters - Premium Local Coffee',
        'description': 'Family-owned coffee shop serving ethically sourced, locally roasted coffee. We offer a full menu of specialty drinks, pastries, and light lunch options in a cozy atmosphere.',
        'businessName': 'Green Coffee Roasters',
        'category': 'Restaurants',
        'address': '123 Main Street, Downtown',
        'phone': '(555) 123-4567',
        'email': 'info@greencoffee.com',
        'website': 'https://greencoffee.com',
        'operatingHours': {'monday': '6:00 AM - 8:00 PM', 'tuesday': '6:00 AM - 8:00 PM'},
        'services': ['Espresso drinks', 'Fresh pastries', 'Free Wi-Fi', 'Meeting space'],
        'rating': 4.8,
        'reviewCount': 127,
        'imageUrl': 'https://picsum.photos/600/400?random=31',
        'imageUrls': ['https://picsum.photos/600/400?random=31'],
        'contactName': 'Manager',
        'contactEmail': 'manager@greencoffee.com',
        'contactPhone': '(555) 123-4567',
        'userId': 'admin',
        'createdAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 2))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 2))),
        'isActive': true,
        'isPremium': true,
      },
    ];

    for (var business in businesses) {
      await _serviceManager.addDocument(FirestoreCollections.businessListings, business);
    }
    
    debugPrint('🏢 Seeded ${businesses.length} business listings');
  }

  /// Seed real estate listings
  Future<void> _seedRealEstateListings() async {
    final properties = [
      {
        'title': 'Beautiful Family Home in Oak Ridge',
        'description': 'Stunning 4-bedroom, 3-bathroom home in the desirable Oak Ridge neighborhood. Features include updated kitchen, hardwood floors, large backyard, and two-car garage.',
        'propertyType': 'House',
        'listingType': 'For Sale',
        'price': 450000.0,
        'address': '789 Oak Ridge Drive',
        'bedrooms': 4,
        'bathrooms': 3,
        'squareFootage': 2400.0,
        'lotSize': 0.5,
        'features': ['Updated kitchen', 'Hardwood floors', 'Large backyard', 'Two-car garage', 'Walk-in closets'],
        'propertyCondition': 'Excellent',
        'zoningType': 'Residential',
        'contactInfo': 'Call (555) 246-8135 or email: sarah@realestate.com',
        'contactName': 'Sarah Johnson',
        'contactEmail': 'sarah@realestate.com',
        'contactPhone': '(555) 246-8135',
        'imageUrl': 'https://picsum.photos/800/600?random=40',
        'imageUrls': ['https://picsum.photos/800/600?random=40', 'https://picsum.photos/800/600?random=41'],
        'userId': 'admin',
        'createdAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 1))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 1))),
        'isActive': true,
        'isPremium': true,
      },
    ];

    for (var property in properties) {
      await _serviceManager.addDocument(FirestoreCollections.realEstateListings, property);
    }
    
    debugPrint('🏠 Seeded ${properties.length} real estate listings');
  }

  /// Seed rental listings
  Future<void> _seedRentalListings() async {
    final rentals = [
      {
        'title': 'Cozy 2BR Apartment Near University',
        'description': 'Perfect for students or young professionals. Recently updated 2-bedroom apartment within walking distance of the university campus. Includes parking space.',
        'propertyType': 'Apartment',
        'monthlyRent': 1200.0,
        'securityDeposit': 1200.0,
        'address': '654 University Avenue, Unit 2A',
        'bedrooms': 2,
        'bathrooms': 1,
        'squareFootage': 900.0,
        'furnished': false,
        'availableFrom': Timestamp.fromDate(DateTime.now().add(const Duration(days: 7))),
        'leaseTerm': '12 months',
        'features': ['Parking space', 'Laundry in building', 'Pet-friendly', 'Near campus'],
        'utilities': ['Water included'],
        'contactInfo': 'Property Manager: (555) 159-7534',
        'contactName': 'Property Manager',
        'contactEmail': 'manager@university-rentals.com',
        'contactPhone': '(555) 159-7534',
        'imageUrl': 'https://picsum.photos/800/600?random=50',
        'imageUrls': ['https://picsum.photos/800/600?random=50', 'https://picsum.photos/800/600?random=51'],
        'userId': 'admin',
        'createdAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 4))),
        'updatedAt': Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 4))),
        'isActive': true,
        'isPremium': false,
      },
    ];

    for (var rental in rentals) {
      await _serviceManager.addDocument(FirestoreCollections.rentalListings, rental);
    }
    
    debugPrint('🏘️ Seeded ${rentals.length} rental listings');
  }

  /// Create admin users collection with default admin
  Future<void> createDefaultAdminUser() async {
    try {
      const adminEmail = 'admin@townsquare.com';
      
      // Check if admin already exists
      final adminExists = await _serviceManager.isAdminUser(adminEmail);
      if (adminExists) {
        debugPrint('Default admin user already exists');
        return;
      }

      // Create admin user document
      await _serviceManager.addDocument(FirestoreCollections.adminUsers, {
        'email': adminEmail,
        'role': 'super_admin',
        'permissions': ['read', 'write', 'delete', 'admin'],
        'isActive': true,
        'createdAt': Timestamp.now(),
        'lastLogin': null,
      });

      debugPrint('✅ Default admin user created in Firestore');
      debugPrint('📧 Admin Email: $adminEmail');
      debugPrint('🔑 Admin Password: admin123');
    } catch (e) {
      debugPrint('❌ Error creating default admin user: $e');
    }
  }
}