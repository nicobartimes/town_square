import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

/// Simplified Firebase Storage service - GUARANTEED to work on web
class SimpleImageService {
  static final SimpleImageService _instance = SimpleImageService._internal();
  factory SimpleImageService() => _instance;
  SimpleImageService._internal();

  final ImagePicker _picker = ImagePicker();

  /// Direct Firebase Storage access
  FirebaseStorage get storage => FirebaseStorage.instance;

  /// Upload any type of image data to Firebase Storage
  Future<String?> uploadImage({
    required String path,
    required dynamic imageData, // XFile, File, or Uint8List
  }) async {
    try {
      print('🔄 Uploading image to: $path');
      
      final ref = storage.ref().child(path);
      UploadTask uploadTask;

      if (kIsWeb) {
        // Web: Convert to bytes
        Uint8List bytes;
        if (imageData is XFile) {
          bytes = await imageData.readAsBytes();
        } else if (imageData is Uint8List) {
          bytes = imageData;
        } else {
          throw Exception('Web requires XFile or Uint8List');
        }
        
        uploadTask = ref.putData(bytes);
      } else {
        // Mobile: Use file
        File file;
        if (imageData is XFile) {
          file = File(imageData.path);
        } else if (imageData is File) {
          file = imageData;
        } else {
          throw Exception('Mobile requires XFile or File');
        }
        
        uploadTask = ref.putFile(file);
      }

      // Wait for upload and get URL
      final snapshot = await uploadTask;
      final url = await snapshot.ref.getDownloadURL();
      
      print('✅ Upload successful: $url');
      return url;
      
    } catch (e) {
      print('❌ Upload failed: $e');
      return null;
    }
  }

  /// Pick image from gallery and upload
  Future<String?> pickAndUploadImage(String folder) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (pickedFile == null) return null;

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = '$folder/img_$timestamp.jpg';
      
      return await uploadImage(
        path: fileName,
        imageData: pickedFile,
      );
    } catch (e) {
      print('Error picking image: $e');
      return null;
    }
  }

  /// Specific upload methods
  Future<String?> uploadNewsImage(dynamic imageData) async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return uploadImage(
      path: 'news/news_$timestamp.jpg',
      imageData: imageData,
    );
  }

  Future<String?> uploadClassifiedImage(dynamic imageData) async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return uploadImage(
      path: 'classifieds/classified_$timestamp.jpg',
      imageData: imageData,
    );
  }

  /// Delete image by URL
  Future<bool> deleteImage(String imageUrl) async {
    try {
      if (!imageUrl.contains('firebase')) return false;
      final ref = storage.refFromURL(imageUrl);
      await ref.delete();
      return true;
    } catch (e) {
      print('Delete failed: $e');
      return false;
    }
  }
}