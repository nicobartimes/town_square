import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:town_square/models/video_news.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

class FirebaseVideoNewsService {
  static final _firestore = FirebaseFirestore.instance;

  static Future<List<VideoNews>> getVideoNews() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.videoNews)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return VideoNews.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to mock data if Firebase is not available
      return _getMockVideoNews();
    }
  }

  static Future<List<VideoNews>> getVideoNewsByCategory(String category) async {
    if (category == 'All') return getVideoNews();
    
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.videoNews)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.category, isEqualTo: category)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return VideoNews.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allVideos = _getMockVideoNews();
      return allVideos.where((video) => video.category == category).toList();
    }
  }

  static Future<VideoNews?> getVideoNewsById(String id) async {
    try {
      final docSnapshot = await _firestore
          .collection(FirestoreCollections.videoNews)
          .doc(id)
          .get();

      if (!docSnapshot.exists) return null;

      final data = docSnapshot.data()!;
      final video = VideoNews.fromJson({...data, 'id': docSnapshot.id});
      
      // Increment view count
      await _incrementViewCount(id);
      
      return video;
    } catch (e) {
      // Fallback to mock data
      final mockVideos = _getMockVideoNews();
      return mockVideos.firstWhere((video) => video.id == id);
    }
  }

  static Future<void> _incrementViewCount(String videoId) async {
    try {
      await _firestore
          .collection(FirestoreCollections.videoNews)
          .doc(videoId)
          .update({
        FirestoreFields.viewCount: FieldValue.increment(1),
      });
    } catch (e) {
      // Ignore error if Firebase is not available
    }
  }

  static Future<List<VideoNews>> searchVideoNews(String query) async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.videoNews)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .get();

      final lowercaseQuery = query.toLowerCase();

      final allVideos = querySnapshot.docs.map((doc) {
        final data = doc.data();
        return VideoNews.fromJson({...data, 'id': doc.id});
      }).toList();

      return allVideos.where((video) {
        return video.title.toLowerCase().contains(lowercaseQuery) ||
               video.description.toLowerCase().contains(lowercaseQuery) ||
               video.category.toLowerCase().contains(lowercaseQuery);
      }).toList();
    } catch (e) {
      // Fallback to mock data search
      final allVideos = _getMockVideoNews();
      final lowercaseQuery = query.toLowerCase();
      return allVideos.where((video) {
        return video.title.toLowerCase().contains(lowercaseQuery) ||
               video.description.toLowerCase().contains(lowercaseQuery) ||
               video.category.toLowerCase().contains(lowercaseQuery);
      }).toList();
    }
  }

  static List<String> getCategories() {
    return ['All', ...Categories.newsCategories];
  }

  // Mock data fallback
  static List<VideoNews> _getMockVideoNews() {
    return [
      VideoNews(
        id: '1',
        title: 'Climate Change Solutions: Latest Research Findings',
        description: 'Scientists present breakthrough research on renewable energy and carbon capture technologies that could revolutionize our approach to climate change.',
        videoId: 'c3yP9lPFKNk',
        videoUrl: 'https://www.youtube.com/watch?v=c3yP9lPFKNk',
        thumbnailUrl: 'https://img.youtube.com/vi/c3yP9lPFKNk/maxresdefault.jpg',
        duration: '8:45',
        category: 'Science',
        source: 'Science Today',
        channelName: 'Science Today',
        publishedAt: DateTime.now().subtract(const Duration(hours: 3)),
        viewCount: 15420,
        isActive: true,
      ),
      VideoNews(
        id: '2',
        title: 'Tech Giants Announce AI Collaboration',
        description: 'Major technology companies join forces to develop responsible AI standards and share research for the benefit of humanity.',
        videoId: 'hTWKbfoikeg',
        videoUrl: 'https://www.youtube.com/watch?v=hTWKbfoikeg',
        thumbnailUrl: 'https://img.youtube.com/vi/hTWKbfoikeg/maxresdefault.jpg',
        duration: '6:22',
        category: 'Technology',
        source: 'Tech News Network',
        channelName: 'Tech News Network',
        publishedAt: DateTime.now().subtract(const Duration(hours: 8)),
        viewCount: 28750,
        isActive: true,
      ),
      VideoNews(
        id: '3',
        title: 'Olympic Training: Behind the Scenes',
        description: 'Go behind the scenes with Olympic athletes as they prepare for the upcoming games, showcasing their dedication and training regimens.',
        videoId: '9bZkp7q19f0',
        videoUrl: 'https://www.youtube.com/watch?v=9bZkp7q19f0',
        thumbnailUrl: 'https://img.youtube.com/vi/9bZkp7q19f0/maxresdefault.jpg',
        duration: '12:18',
        category: 'Sports',
        source: 'Sports Network',
        channelName: 'Sports Network',
        publishedAt: DateTime.now().subtract(const Duration(hours: 14)),
        viewCount: 42100,
        isActive: true,
      ),
      VideoNews(
        id: '4',
        title: 'Global Economy: Market Analysis 2025',
        description: 'Expert economists analyze current market trends and provide insights into what we can expect for the global economy in 2025.',
        videoId: 'JGwWNGJdvx8',
        videoUrl: 'https://www.youtube.com/watch?v=JGwWNGJdvx8',
        thumbnailUrl: 'https://img.youtube.com/vi/JGwWNGJdvx8/maxresdefault.jpg',
        duration: '15:33',
        category: 'Business',
        source: 'Business World',
        channelName: 'Business World',
        publishedAt: DateTime.now().subtract(const Duration(days: 1)),
        viewCount: 18650,
        isActive: true,
      ),
      VideoNews(
        id: '5',
        title: 'Healthcare Revolution: Telemedicine Advances',
        description: 'Discover how telemedicine is transforming healthcare delivery and making medical care more accessible to people worldwide.',
        videoId: 'oHg5SJYRHA0',
        videoUrl: 'https://www.youtube.com/watch?v=oHg5SJYRHA0',
        thumbnailUrl: 'https://img.youtube.com/vi/oHg5SJYRHA0/maxresdefault.jpg',
        duration: '10:07',
        category: 'Health',
        source: 'Health Today',
        channelName: 'Health Today',
        publishedAt: DateTime.now().subtract(const Duration(days: 1, hours: 8)),
        viewCount: 31250,
        isActive: true,
      ),
      VideoNews(
        id: '6',
        title: 'Space Exploration: Mars Mission Update',
        description: 'Latest updates from NASA\'s Mars exploration program, including new discoveries and future mission plans.',
        videoId: 'uelHwf8o7_U',
        videoUrl: 'https://www.youtube.com/watch?v=uelHwf8o7_U',
        thumbnailUrl: 'https://img.youtube.com/vi/uelHwf8o7_U/maxresdefault.jpg',
        duration: '9:42',
        category: 'Science',
        source: 'Space News',
        channelName: 'Space News',
        publishedAt: DateTime.now().subtract(const Duration(days: 2)),
        viewCount: 67800,
        isActive: true,
      ),
    ];
  }
}