import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:town_square/models/news_article.dart';
import 'package:town_square/services/firebase_news_service.dart';

class NewsService {
  static const String _bookmarksKey = 'bookmarked_articles';
  
  static List<NewsArticle> getSampleNews() {
    return [
      NewsArticle(
        id: '1',
        title: 'Breaking: Major Technology Conference Announced for 2025',
        content: 'The annual TechWorld conference has been announced for March 2025, featuring keynotes from industry leaders and demonstrations of cutting-edge technologies. This year\'s theme focuses on artificial intelligence, sustainable technology, and the future of work.\n\nExpected attendees include representatives from major tech companies, startups, and academic institutions. The three-day event will feature workshops, panel discussions, and networking opportunities.\n\nRegistration opens next month with early bird pricing available for the first 1000 registrants. The conference will be held at the Convention Center downtown with both in-person and virtual attendance options.',
        summary: 'TechWorld 2025 conference announced with focus on AI and sustainable technology.',
        imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800',
        category: 'Technology',
        source: 'Tech Today',
        publishedAt: DateTime.now().subtract(Duration(hours: 2)),
        readTime: 3,
      ),
      NewsArticle(
        id: '2',
        title: 'Local Housing Market Shows Strong Growth This Quarter',
        content: 'The local real estate market has demonstrated remarkable resilience and growth throughout the current quarter, with property values increasing by 8% compared to the same period last year.\n\nReal estate experts attribute this growth to several factors including low interest rates, increased demand from remote workers, and limited housing inventory. First-time homebuyers are particularly active in the market.\n\n"We\'re seeing unprecedented demand across all price ranges," said Sarah Johnson, lead realtor at City Properties. "The combination of lifestyle changes post-pandemic and favorable lending conditions has created a perfect storm for sellers."\n\nNew construction projects are also on the rise, with several mixed-use developments approved for the downtown area.',
        summary: 'Local real estate market grows 8% with high demand from buyers.',
        imageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800',
        category: 'Real Estate',
        source: 'City News',
        publishedAt: DateTime.now().subtract(Duration(hours: 5)),
        readTime: 4,
      ),
      NewsArticle(
        id: '3',
        title: 'Championship Finals Draw Record Crowds',
        content: 'Last night\'s championship game broke attendance records with over 75,000 fans packing the stadium to witness one of the most exciting finales in recent memory.\n\nThe match went into overtime, with spectacular plays from both teams keeping fans on the edge of their seats. The winning goal came in the final minutes of extra time, securing the championship for the home team.\n\n"The energy in the stadium was absolutely electric," commented sports broadcaster Mike Chen. "You could feel the passion from every single person in attendance."\n\nCelebrations continued throughout the night as fans poured into the streets to celebrate their team\'s victory. Local businesses reported record sales as the celebratory crowd visited restaurants and bars.',
        summary: 'Championship finals breaks attendance records with thrilling overtime victory.',
        imageUrl: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800',
        videoId: 'dQw4w9WgXcQ',
        category: 'Sports',
        source: 'Sports Central',
        publishedAt: DateTime.now().subtract(Duration(hours: 12)),
        readTime: 2,
      ),
      NewsArticle(
        id: '4',
        title: 'New Business District to Create Thousands of Jobs',
        content: 'City officials announced plans for a new business district that is expected to create over 5,000 jobs over the next five years. The development will feature modern office spaces, retail establishments, and public amenities.\n\nThe project represents a \$2 billion investment in the local economy and is expected to attract major corporations looking to establish regional headquarters. Construction is set to begin next year.\n\n"This development will transform our city into a major business hub," said Mayor Jennifer Adams. "We\'re not just building offices; we\'re creating a community where people can work, shop, and enjoy recreational activities."\n\nThe district will also include green spaces, bike paths, and public transportation connections to ensure sustainable urban development.',
        summary: 'New \$2B business district to create 5,000 jobs and transform city center.',
        imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800',
        category: 'Business',
        source: 'Business Weekly',
        publishedAt: DateTime.now().subtract(Duration(days: 1)),
        readTime: 5,
      ),
      NewsArticle(
        id: '5',
        title: 'Climate Initiative Launches Community Gardens Program',
        content: 'A new environmental initiative has launched community gardens across the city, providing residents with spaces to grow their own food while promoting sustainable living practices.\n\nThe program includes 20 garden locations, each equipped with composting systems, rainwater collection, and educational workshops for participants of all ages.\n\n"These gardens represent more than just food production," explained Dr. Maria Rodriguez, program coordinator. "They\'re creating stronger communities while teaching valuable skills about sustainable agriculture."\n\nFamilies can rent plots for a nominal fee, and the program includes mentorship from experienced gardeners. The initiative has already attracted over 500 participants in its first month.',
        summary: 'Community gardens program launches with 20 locations to promote sustainable living.',
        imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
        category: 'Environment',
        source: 'Green Living',
        publishedAt: DateTime.now().subtract(Duration(days: 2)),
        readTime: 3,
      ),
      NewsArticle(
        id: '6',
        title: 'Local University Receives Major Research Grant',
        content: 'The State University has been awarded a \$10 million research grant to study renewable energy solutions, marking one of the largest grants in the institution\'s history.\n\nThe five-year project will focus on developing more efficient solar panel technology and energy storage solutions. The research team includes faculty from engineering, chemistry, and environmental science departments.\n\n"This grant validates our commitment to solving real-world problems through innovative research," said Dr. Robert Kim, lead researcher. "We expect our findings to have significant impact on the renewable energy industry."\n\nThe project will also provide research opportunities for graduate students and is expected to result in several patent applications and startup companies.',
        summary: 'University receives \$10M grant for renewable energy research project.',
        imageUrl: 'https://images.unsplash.com/photo-1562774053-701939374585?w=800',
        category: 'Education',
        source: 'Education Today',
        publishedAt: DateTime.now().subtract(Duration(days: 3)),
        readTime: 4,
      ),
    ];
  }

  static Future<List<NewsArticle>> getNews() async {
    try {
      // Try Firebase first
      return await FirebaseNewsService.getNews();
    } catch (e) {
      // Fallback to mock data if Firebase is not available
      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
      
      return getSampleNews().map((article) {
        return article.copyWith(isBookmarked: bookmarkedIds.contains(article.id));
      }).toList();
    }
  }

  static Future<List<NewsArticle>> getNewsByCategory(String category) async {
    try {
      // Try Firebase first
      return await FirebaseNewsService.getNewsByCategory(category);
    } catch (e) {
      // Fallback to mock data
      final allNews = await getNews();
      return allNews.where((article) => article.category == category).toList();
    }
  }

  static Future<List<NewsArticle>> getBookmarkedNews() async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
    final allNews = getSampleNews();
    
    return allNews.where((article) => bookmarkedIds.contains(article.id)).toList();
  }

  static Future<void> toggleBookmark(String articleId) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
    
    if (bookmarkedIds.contains(articleId)) {
      bookmarkedIds.remove(articleId);
    } else {
      bookmarkedIds.add(articleId);
    }
    
    await prefs.setStringList(_bookmarksKey, bookmarkedIds);
  }

  static Future<List<NewsArticle>> searchNews(String query) async {
    final allNews = await getNews();
    final lowercaseQuery = query.toLowerCase();
    
    return allNews.where((article) {
      return article.title.toLowerCase().contains(lowercaseQuery) ||
             article.content.toLowerCase().contains(lowercaseQuery) ||
             article.category.toLowerCase().contains(lowercaseQuery);
    }).toList();
  }

  static List<String> getCategories() {
    return ['All', 'Technology', 'Business', 'Sports', 'Real Estate', 'Environment', 'Education'];
  }
}