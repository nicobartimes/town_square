import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:town_square/services/firebase_service_manager.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

/// Firebase Authentication Service
/// Handles user authentication, registration, and profile management
class FirebaseAuthService {
  static final FirebaseAuthService _instance = FirebaseAuthService._internal();
  factory FirebaseAuthService() => _instance;
  FirebaseAuthService._internal();

  final FirebaseServiceManager _serviceManager = FirebaseServiceManager();

  // Stream of authentication state changes
  Stream<User?> get authStateChanges => _serviceManager.authStateChanges;

  // Current user
  User? get currentUser => _serviceManager.currentUser;

  // Check if user is authenticated
  bool get isAuthenticated => _serviceManager.isAuthenticated;

  /// Sign in with email and password
  Future<AuthResult> signInWithEmailAndPassword(String email, String password) async {
    try {
      UserCredential? result = await _serviceManager.signInWithEmailAndPassword(email, password);
      if (result?.user != null) {
        await _updateUserLastLogin(result!.user!.uid);
        return AuthResult.success(result.user!, 'Sign in successful');
      } else {
        return AuthResult.error('Sign in failed');
      }
    } on FirebaseAuthException catch (e) {
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      return AuthResult.error('An unexpected error occurred');
    }
  }

  /// Register new user with email and password
  Future<AuthResult> registerWithEmailAndPassword(String email, String password, String name) async {
    try {
      UserCredential? result = await _serviceManager.createUserWithEmailAndPassword(email, password);
      if (result?.user != null) {
        // Update user display name
        await result!.user!.updateDisplayName(name);
        
        // Create user profile in Firestore
        await _createUserProfile(result.user!, name);
        
        return AuthResult.success(result.user!, 'Registration successful');
      } else {
        return AuthResult.error('Registration failed');
      }
    } on FirebaseAuthException catch (e) {
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      return AuthResult.error('An unexpected error occurred during registration');
    }
  }

  /// Sign out current user
  Future<AuthResult> signOut() async {
    try {
      await _serviceManager.signOut();
      return AuthResult.success(null, 'Signed out successfully');
    } catch (e) {
      return AuthResult.error('Error signing out');
    }
  }

  /// Reset password for given email
  Future<AuthResult> resetPassword(String email) async {
    try {
      await _serviceManager.resetPassword(email);
      return AuthResult.success(null, 'Password reset email sent');
    } on FirebaseAuthException catch (e) {
      return AuthResult.error(_getAuthErrorMessage(e.code));
    } catch (e) {
      return AuthResult.error('Error sending password reset email');
    }
  }

  /// Update user profile information
  Future<AuthResult> updateProfile(String name, String? photoURL) async {
    try {
      User? user = currentUser;
      if (user == null) {
        return AuthResult.error('No user signed in');
      }

      // Update Firebase Auth profile
      await user.updateDisplayName(name);
      if (photoURL != null) {
        await user.updatePhotoURL(photoURL);
      }

      // Update Firestore profile
      await _serviceManager.setUserProfile(user.uid, {
        FirestoreFields.name: name,
        if (photoURL != null) FirestoreFields.profilePicture: photoURL,
        FirestoreFields.email: user.email,
      });

      return AuthResult.success(user, 'Profile updated successfully');
    } catch (e) {
      return AuthResult.error('Error updating profile');
    }
  }

  /// Check if user is admin
  Future<bool> isAdminUser() async {
    User? user = currentUser;
    if (user == null) return false;
    
    return await _serviceManager.isAdminUser(user.email!);
  }

  /// Get user profile data
  Future<Map<String, dynamic>?> getUserProfileData() async {
    User? user = currentUser;
    if (user == null) return null;

    try {
      var doc = await _serviceManager.getUserProfile(user.uid);
      return doc?.data() as Map<String, dynamic>?;
    } catch (e) {
      debugPrint('Error getting user profile data: $e');
      return null;
    }
  }

  /// Create user profile in Firestore
  Future<void> _createUserProfile(User user, String name) async {
    try {
      await _serviceManager.setUserProfile(user.uid, {
        FirestoreFields.name: name,
        FirestoreFields.email: user.email,
        FirestoreFields.profilePicture: user.photoURL ?? '',
        FirestoreFields.joinedAt: DateTime.now().toIso8601String(),
        FirestoreFields.bookmarks: [],
        FirestoreFields.preferences: {},
        FirestoreFields.isActive: true,
      });
    } catch (e) {
      debugPrint('Error creating user profile: $e');
    }
  }

  /// Update user's last login timestamp
  Future<void> _updateUserLastLogin(String userId) async {
    try {
      await _serviceManager.updateDocument(
        FirestoreCollections.users,
        userId,
        {FirestoreFields.lastLogin: DateTime.now().toIso8601String()},
      );
    } catch (e) {
      debugPrint('Error updating last login: $e');
    }
  }

  /// Get user-friendly error messages for Firebase Auth errors
  String _getAuthErrorMessage(String errorCode) {
    switch (errorCode) {
      case 'user-not-found':
        return 'No user found with this email address.';
      case 'wrong-password':
        return 'Invalid password. Please try again.';
      case 'email-already-in-use':
        return 'This email address is already registered.';
      case 'weak-password':
        return 'Password is too weak. Please use at least 6 characters.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many failed attempts. Please try again later.';
      case 'operation-not-allowed':
        return 'This operation is not allowed.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }
}

/// Result class for authentication operations
class AuthResult {
  final bool isSuccess;
  final User? user;
  final String message;

  AuthResult._(this.isSuccess, this.user, this.message);

  factory AuthResult.success(User? user, String message) {
    return AuthResult._(true, user, message);
  }

  factory AuthResult.error(String message) {
    return AuthResult._(false, null, message);
  }
}