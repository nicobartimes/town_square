import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:town_square/models/news_article.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';

class FirebaseNewsService {
  static const String _bookmarksKey = 'bookmarked_articles';
  static final _firestore = FirebaseFirestore.instance;

  static Future<List<NewsArticle>> getNews() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.newsArticles)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .get();

      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        final article = NewsArticle.fromJson({...data, 'id': doc.id});
        return article.copyWith(isBookmarked: bookmarkedIds.contains(doc.id));
      }).toList();
    } catch (e) {
      // Fallback to mock data if Firebase is not available
      return _getMockNews();
    }
  }

  static Future<List<NewsArticle>> getNewsByCategory(String category) async {
    if (category == 'All') return getNews();
    
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.newsArticles)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.category, isEqualTo: category)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .get();

      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        final article = NewsArticle.fromJson({...data, 'id': doc.id});
        return article.copyWith(isBookmarked: bookmarkedIds.contains(doc.id));
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allNews = _getMockNews();
      return allNews.where((article) => article.category == category).toList();
    }
  }

  static Future<List<NewsArticle>> getBookmarkedNews() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
      
      if (bookmarkedIds.isEmpty) return [];

      final querySnapshot = await _firestore
          .collection(FirestoreCollections.newsArticles)
          .where(FieldPath.documentId, whereIn: bookmarkedIds)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        final article = NewsArticle.fromJson({...data, 'id': doc.id});
        return article.copyWith(isBookmarked: true);
      }).toList();
    } catch (e) {
      // Fallback to mock data filtering
      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
      final allNews = _getMockNews();
      return allNews.where((article) => bookmarkedIds.contains(article.id)).toList();
    }
  }

  static Future<List<NewsArticle>> searchNews(String query) async {
    try {
      // Note: Firestore doesn't support full-text search natively
      // For production, you'd use Firebase Search (Algolia) or implement client-side filtering
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.newsArticles)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .get();

      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
      final lowercaseQuery = query.toLowerCase();

      final allArticles = querySnapshot.docs.map((doc) {
        final data = doc.data();
        final article = NewsArticle.fromJson({...data, 'id': doc.id});
        return article.copyWith(isBookmarked: bookmarkedIds.contains(doc.id));
      }).toList();

      return allArticles.where((article) {
        return article.title.toLowerCase().contains(lowercaseQuery) ||
               article.content.toLowerCase().contains(lowercaseQuery) ||
               article.category.toLowerCase().contains(lowercaseQuery);
      }).toList();
    } catch (e) {
      // Fallback to mock data search
      final allNews = _getMockNews();
      final lowercaseQuery = query.toLowerCase();
      return allNews.where((article) {
        return article.title.toLowerCase().contains(lowercaseQuery) ||
               article.content.toLowerCase().contains(lowercaseQuery) ||
               article.category.toLowerCase().contains(lowercaseQuery);
      }).toList();
    }
  }

  static Future<NewsArticle?> getNewsById(String id) async {
    try {
      final docSnapshot = await _firestore
          .collection(FirestoreCollections.newsArticles)
          .doc(id)
          .get();

      if (!docSnapshot.exists) return null;

      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];

      final data = docSnapshot.data()!;
      final article = NewsArticle.fromJson({...data, 'id': docSnapshot.id});
      
      // Increment view count
      await _incrementViewCount(id);
      
      return article.copyWith(isBookmarked: bookmarkedIds.contains(id));
    } catch (e) {
      // Fallback to mock data
      final mockNews = _getMockNews();
      return mockNews.firstWhere((article) => article.id == id);
    }
  }

  static Future<void> _incrementViewCount(String articleId) async {
    try {
      await _firestore
          .collection(FirestoreCollections.newsArticles)
          .doc(articleId)
          .update({
        FirestoreFields.viewCount: FieldValue.increment(1),
      });
    } catch (e) {
      // Ignore error if Firebase is not available
    }
  }

  static Future<void> toggleBookmark(String articleId) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
    
    if (bookmarkedIds.contains(articleId)) {
      bookmarkedIds.remove(articleId);
    } else {
      bookmarkedIds.add(articleId);
    }
    
    await prefs.setStringList(_bookmarksKey, bookmarkedIds);
  }

  static List<String> getCategories() {
    return ['All', ...Categories.newsCategories];
  }

  // Mock data fallback
  static List<NewsArticle> _getMockNews() {
    return [
      NewsArticle(
        id: '1',
        title: 'Breaking: Major Technology Conference Announced for 2025',
        content: 'The annual TechWorld conference has been announced for March 2025, featuring keynotes from industry leaders and demonstrations of cutting-edge technologies...',
        summary: 'TechWorld 2025 conference announced with focus on AI and sustainable technology.',
        description: 'TechWorld 2025 conference announced with focus on AI and sustainable technology.',
        imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800',
        category: 'Technology',
        source: 'Tech Today',
        author: 'Tech Today',
        publishedAt: DateTime.now().subtract(const Duration(hours: 2)),
        readTime: 3,
        viewCount: 1250,
        tags: ['tech', 'conference', 'AI'],
        isActive: true,
      ),
      NewsArticle(
        id: '2',
        title: 'Local Housing Market Shows Strong Growth This Quarter',
        content: 'The local real estate market has demonstrated remarkable resilience and growth throughout the current quarter...',
        summary: 'Local real estate market grows 8% with high demand from buyers.',
        description: 'Local real estate market grows 8% with high demand from buyers.',
        imageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800',
        category: 'Business',
        source: 'City News',
        author: 'City News',
        publishedAt: DateTime.now().subtract(const Duration(hours: 5)),
        readTime: 4,
        viewCount: 890,
        tags: ['real estate', 'market', 'growth'],
        isActive: true,
      ),
      NewsArticle(
        id: '3',
        title: 'Championship Finals Draw Record Crowds',
        content: 'Last night\'s championship game broke attendance records with over 75,000 fans packing the stadium...',
        summary: 'Championship finals breaks attendance records with thrilling overtime victory.',
        description: 'Championship finals breaks attendance records with thrilling overtime victory.',
        imageUrl: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800',
        category: 'Sports',
        source: 'Sports Central',
        author: 'Sports Central',
        publishedAt: DateTime.now().subtract(const Duration(hours: 12)),
        readTime: 2,
        viewCount: 2100,
        tags: ['sports', 'championship', 'record'],
        isActive: true,
      ),
      NewsArticle(
        id: '4',
        title: 'New Business District to Create Thousands of Jobs',
        content: 'City officials announced plans for a new business district that is expected to create over 5,000 jobs...',
        summary: 'New \$2B business district to create 5,000 jobs and transform city center.',
        description: 'New \$2B business district to create 5,000 jobs and transform city center.',
        imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800',
        category: 'Business',
        source: 'Business Weekly',
        author: 'Business Weekly',
        publishedAt: DateTime.now().subtract(const Duration(days: 1)),
        readTime: 5,
        viewCount: 750,
        tags: ['business', 'jobs', 'development'],
        isActive: true,
      ),
      NewsArticle(
        id: '5',
        title: 'Climate Initiative Launches Community Gardens Program',
        content: 'A new environmental initiative has launched community gardens across the city...',
        summary: 'Community gardens program launches with 20 locations to promote sustainable living.',
        description: 'Community gardens program launches with 20 locations to promote sustainable living.',
        imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
        category: 'Local',
        source: 'Green Living',
        author: 'Green Living',
        publishedAt: DateTime.now().subtract(const Duration(days: 2)),
        readTime: 3,
        viewCount: 420,
        tags: ['environment', 'community', 'sustainability'],
        isActive: true,
      ),
    ];
  }
}