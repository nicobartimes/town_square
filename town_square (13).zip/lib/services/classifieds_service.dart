import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:town_square/models/classified_listing.dart';
import 'package:town_square/models/job_listing.dart';
import 'package:town_square/models/business_listing.dart';
import 'package:town_square/models/real_estate_listing.dart';
import 'package:town_square/models/rental_listing.dart';
import 'package:town_square/services/firebase_classifieds_service.dart';

class ClassifiedsService {
  static const String _favoritesKey = 'favorited_listings';
  static const String _userListingsKey = 'user_listings';

  static List<ClassifiedListing> getSampleListings() {
    return [
      ClassifiedListing(
        id: '1',
        title: 'Software Developer - Full Stack',
        description: 'Join our dynamic team as a Full Stack Developer! We\'re looking for someone with 3+ years experience in React, Node.js, and MongoDB. Competitive salary, flexible work arrangements, and great benefits package.\n\nResponsibilities:\n• Develop web applications using modern frameworks\n• Collaborate with design and product teams\n• Write clean, maintainable code\n• Participate in code reviews\n\nRequirements:\n• Bachelor\'s degree in Computer Science or related field\n• Experience with JavaScript, HTML, CSS\n• Knowledge of database design\n• Strong problem-solving skills',
        price: 85000,
        imageUrls: ['https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=800'],
        category: 'Jobs',
        location: 'Downtown Office',
        contactName: 'HR Department',
        contactPhone: '(555) 123-4567',
        contactEmail: 'careers@techcorp.com',
        createdAt: DateTime.now().subtract(Duration(days: 1)),
        isPremium: true,
        userId: 'company_1',
      ),
      ClassifiedListing(
        id: '2',
        title: 'Beautiful 3BR House for Sale',
        description: 'Stunning 3-bedroom, 2-bathroom home in prestigious Oak Grove neighborhood. Recently renovated kitchen with granite countertops, hardwood floors throughout, and spacious backyard perfect for entertaining.\n\nFeatures:\n• 2,200 sq ft of living space\n• Updated kitchen with stainless appliances\n• Master suite with walk-in closet\n• Attached 2-car garage\n• Landscaped yard with mature trees\n• Close to schools and shopping\n\nThis home is move-in ready and won\'t last long in today\'s market!',
        price: 450000,
        imageUrls: [
          'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800',
          'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800'
        ],
        category: 'Real Estate',
        location: 'Oak Grove',
        contactName: 'Jennifer Smith',
        contactPhone: '(555) 987-6543',
        contactEmail: 'jennifer@realestate.com',
        createdAt: DateTime.now().subtract(Duration(hours: 8)),
        isPremium: true,
        userId: 'realtor_1',
      ),
      ClassifiedListing(
        id: '3',
        title: 'Modern Apartment for Rent',
        description: 'Luxury 2-bedroom apartment available for immediate move-in. Located in the heart of downtown with amazing city views. Building amenities include fitness center, rooftop deck, and concierge service.\n\nApartment features:\n• 1,100 sq ft\n• Floor-to-ceiling windows\n• In-unit washer/dryer\n• Stainless steel appliances\n• Hardwood floors\n• Balcony with city views\n\nRent includes water and garbage. Parking available for additional \$150/month.',
        price: 2200,
        imageUrls: [
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800'
        ],
        category: 'Rentals',
        location: 'Downtown',
        contactName: 'Mike Johnson',
        contactPhone: '(555) 456-7890',
        contactEmail: 'mike@cityapts.com',
        createdAt: DateTime.now().subtract(Duration(hours: 12)),
        userId: 'landlord_1',
      ),
      ClassifiedListing(
        id: '4',
        title: 'Established Restaurant for Sale',
        description: 'Turn-key restaurant opportunity in high-traffic location! This well-established Italian restaurant has been serving the community for over 15 years. Includes all equipment, furniture, and existing customer base.\n\nBusiness highlights:\n• Fully equipped commercial kitchen\n• Seats 80 customers\n• Excellent online reviews (4.8/5 stars)\n• Loyal customer base\n• Prime location with high foot traffic\n• All permits and licenses current\n\nPerfect for experienced restaurateur or someone looking to enter the food service industry. Serious inquiries only.',
        price: 295000,
        imageUrls: [
          'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
          'https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?w=800'
        ],
        category: 'Business',
        location: 'Main Street',
        contactName: 'Tony Martinelli',
        contactPhone: '(555) 234-5678',
        contactEmail: 'tony@italianbistro.com',
        createdAt: DateTime.now().subtract(Duration(days: 2)),
        isPremium: true,
        userId: 'business_1',
      ),
      ClassifiedListing(
        id: '5',
        title: 'Marketing Manager Position',
        description: 'Growing startup seeking experienced Marketing Manager to lead our marketing efforts. You\'ll develop strategies, manage campaigns, and work with a talented team in a fast-paced environment.\n\nWhat we offer:\n• Competitive salary + equity\n• Health, dental, vision insurance\n• Flexible PTO policy\n• Work from home options\n• Professional development budget\n• Fun, collaborative culture\n\nWe\'re looking for someone who\'s passionate about digital marketing and ready to make a significant impact on our company\'s growth.',
        price: 65000,
        imageUrls: ['https://images.unsplash.com/photo-1553484771-371a605b060b?w=800'],
        category: 'Jobs',
        location: 'Remote/Hybrid',
        contactName: 'Sarah Chen',
        contactPhone: '(555) 345-6789',
        contactEmail: 'sarah@startup.com',
        createdAt: DateTime.now().subtract(Duration(days: 3)),
        userId: 'startup_1',
      ),
      ClassifiedListing(
        id: '6',
        title: 'Cozy Studio Apartment',
        description: 'Charming studio apartment perfect for young professional or student. Recently updated with new flooring and paint. Great location near public transportation and university campus.\n\nFeatures:\n• 450 sq ft\n• Murphy bed saves space\n• Updated kitchen\n• Large windows for natural light\n• On-site laundry\n• Bike storage available\n\nQuiet building with responsible tenants. No smoking, pets negotiable with deposit.',
        price: 1200,
        imageUrls: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800'],
        category: 'Rentals',
        location: 'University District',
        contactName: 'Lisa Wong',
        contactPhone: '(555) 567-8901',
        contactEmail: 'lisa@rentals.com',
        createdAt: DateTime.now().subtract(Duration(days: 4)),
        userId: 'landlord_2',
      ),
    ];
  }

  static Future<List<ClassifiedListing>> getListings() async {
    try {
      // Try Firebase first
      final firebaseListings = await FirebaseClassifiedsService.getAllListings();
      return firebaseListings.cast<ClassifiedListing>();
    } catch (e) {
      // Fallback to mock data if Firebase is not available
      final prefs = await SharedPreferences.getInstance();
      final favoritedIds = prefs.getStringList(_favoritesKey) ?? [];
      
      final userListingsJson = prefs.getStringList(_userListingsKey) ?? [];
      final userListings = userListingsJson
          .map((json) => ClassifiedListing.fromMap(jsonDecode(json)))
          .toList();
      
      final allListings = [...getSampleListings(), ...userListings];
      
      return allListings.map((listing) {
        return listing.copyWith(isFavorited: favoritedIds.contains(listing.id));
      }).toList();
    }
  }

  static Future<List<ClassifiedListing>> getListingsByCategory(String category) async {
    try {
      // Try Firebase first
      final firebaseListings = await FirebaseClassifiedsService.getListingsByCategory(category);
      return firebaseListings.cast<ClassifiedListing>();
    } catch (e) {
      // Fallback to mock data
      final allListings = await getListings();
      return allListings.where((listing) => listing.category == category).toList();
    }
  }

  static Future<List<ClassifiedListing>> getFavoritedListings() async {
    final prefs = await SharedPreferences.getInstance();
    final favoritedIds = prefs.getStringList(_favoritesKey) ?? [];
    final allListings = await getListings();
    
    return allListings.where((listing) => favoritedIds.contains(listing.id)).toList();
  }

  static Future<List<ClassifiedListing>> getPremiumListings() async {
    final allListings = await getListings();
    return allListings.where((listing) => listing.isPremium).toList();
  }

  static Future<void> toggleFavorite(String listingId) async {
    final prefs = await SharedPreferences.getInstance();
    final favoritedIds = prefs.getStringList(_favoritesKey) ?? [];
    
    if (favoritedIds.contains(listingId)) {
      favoritedIds.remove(listingId);
    } else {
      favoritedIds.add(listingId);
    }
    
    await prefs.setStringList(_favoritesKey, favoritedIds);
  }

  static Future<void> addListing(ClassifiedListing listing) async {
    final prefs = await SharedPreferences.getInstance();
    final userListingsJson = prefs.getStringList(_userListingsKey) ?? [];
    
    userListingsJson.add(jsonEncode(listing.toMap()));
    await prefs.setStringList(_userListingsKey, userListingsJson);
  }

  static Future<List<ClassifiedListing>> searchListings(String query) async {
    final allListings = await getListings();
    final lowercaseQuery = query.toLowerCase();
    
    return allListings.where((listing) {
      return listing.title.toLowerCase().contains(lowercaseQuery) ||
             listing.description.toLowerCase().contains(lowercaseQuery) ||
             listing.category.toLowerCase().contains(lowercaseQuery) ||
             listing.location.toLowerCase().contains(lowercaseQuery);
    }).toList();
  }

  static List<String> getCategories() {
    return ['All', 'Jobs', 'Real Estate', 'Rentals', 'Business'];
  }

  // Category-specific sample data methods
  static List<JobListing> getSampleJobs() {
    return [
      JobListing(
        id: '1',
        title: 'Software Developer - Full Stack',
        description: 'Join our dynamic team as a Full Stack Developer! We\'re looking for someone with 3+ years experience in React, Node.js, and MongoDB.',
        companyName: 'Tech Corp',
        category: 'Technology',
        jobType: 'Full-time',
        workArrangement: 'Hybrid',
        salaryMin: 75000,
        salaryMax: 95000,
        salaryType: 'Annual',
        imageUrls: ['https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=800'],
        location: 'Downtown Office',
        requirements: ['3+ years experience', 'React, Node.js, MongoDB', 'Bachelor\'s degree'],
        responsibilities: ['Develop web applications', 'Code reviews', 'Team collaboration'],
        benefits: ['Health insurance', 'Flexible work', 'Professional development'],
        experienceLevel: 'Mid',
        education: 'Bachelor\'s',
        skills: ['JavaScript', 'React', 'Node.js', 'MongoDB'],
        contactName: 'HR Department',
        contactPhone: '(555) 123-4567',
        contactEmail: 'careers@techcorp.com',
        applicationDeadline: DateTime.now().add(Duration(days: 30)),
        createdAt: DateTime.now().subtract(Duration(days: 1)),
        updatedAt: DateTime.now().subtract(Duration(days: 1)),
        isPremium: true,
        userId: 'company_1',
        isUrgent: false,
      ),
      JobListing(
        id: '5',
        title: 'Marketing Manager Position',
        description: 'Growing startup seeking experienced Marketing Manager to lead our marketing efforts.',
        companyName: 'StartupCo',
        category: 'Marketing',
        jobType: 'Full-time',
        workArrangement: 'Remote',
        salaryMin: 60000,
        salaryMax: 70000,
        salaryType: 'Annual',
        imageUrls: ['https://images.unsplash.com/photo-1553484771-371a605b060b?w=800'],
        location: 'Remote/Hybrid',
        requirements: ['5+ years marketing experience', 'Digital marketing expertise'],
        responsibilities: ['Develop strategies', 'Manage campaigns', 'Team leadership'],
        benefits: ['Equity', 'Health insurance', 'Flexible PTO'],
        experienceLevel: 'Senior',
        education: 'Bachelor\'s',
        skills: ['Digital Marketing', 'Strategy', 'Analytics'],
        contactName: 'Sarah Chen',
        contactPhone: '(555) 345-6789',
        contactEmail: 'sarah@startup.com',
        applicationDeadline: DateTime.now().add(Duration(days: 20)),
        createdAt: DateTime.now().subtract(Duration(days: 3)),
        updatedAt: DateTime.now().subtract(Duration(days: 3)),
        userId: 'startup_1',
      ),
    ];
  }

  static List<BusinessListing> getSampleBusinesses() {
    return [
      BusinessListing(
        id: '4',
        businessName: 'Tony\'s Italian Bistro',
        description: 'Turn-key restaurant opportunity in high-traffic location! Well-established Italian restaurant serving the community for over 15 years.',
        category: 'Restaurant',
        imageUrls: [
          'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
          'https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?w=800'
        ],
        address: 'Main Street',
        phone: '(555) 234-5678',
        email: 'tony@italianbistro.com',
        website: 'https://tonysbistro.com',
        operatingHours: {
          'Monday': '11:00 AM - 9:00 PM',
          'Tuesday': '11:00 AM - 9:00 PM',
          'Wednesday': '11:00 AM - 9:00 PM',
          'Thursday': '11:00 AM - 9:00 PM',
          'Friday': '11:00 AM - 10:00 PM',
          'Saturday': '11:00 AM - 10:00 PM',
          'Sunday': '12:00 PM - 8:00 PM',
        },
        services: ['Dine-in', 'Takeout', 'Catering'],
        rating: 4.8,
        reviewCount: 245,
        createdAt: DateTime.now().subtract(Duration(days: 2)),
        updatedAt: DateTime.now().subtract(Duration(days: 2)),
        isPremium: true,
        userId: 'business_1',
        isVerified: true,
      ),
    ];
  }

  static List<RealEstateListing> getSampleRealEstate() {
    return [
      RealEstateListing(
        id: '2',
        title: 'Beautiful 3BR House for Sale',
        description: 'Stunning 3-bedroom, 2-bathroom home in prestigious Oak Grove neighborhood. Recently renovated kitchen with granite countertops.',
        price: 450000,
        imageUrls: [
          'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800',
          'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800'
        ],
        propertyType: 'House',
        listingType: 'Sale',
        address: 'Oak Grove',
        bedrooms: 3,
        bathrooms: 2,
        squareFootage: 2200,
        lotSize: 0.25,
        yearBuilt: 1995,
        propertyCondition: 'Excellent',
        features: ['Hardwood floors', 'Granite countertops', 'Attached garage', 'Landscaped yard'],
        hasGarage: true,
        garageSpaces: 2,
        zoningType: 'Residential',
        contactName: 'Jennifer Smith',
        contactPhone: '(555) 987-6543',
        contactEmail: 'jennifer@realestate.com',
        createdAt: DateTime.now().subtract(Duration(hours: 8)),
        updatedAt: DateTime.now().subtract(Duration(hours: 8)),
        isPremium: true,
        userId: 'realtor_1',
      ),
    ];
  }

  static List<RentalListing> getSampleRentals() {
    return [
      RentalListing(
        id: '3',
        title: 'Modern Apartment for Rent',
        description: 'Luxury 2-bedroom apartment available for immediate move-in. Located in the heart of downtown with amazing city views.',
        monthlyRent: 2200,
        securityDeposit: 2200,
        imageUrls: [
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800'
        ],
        propertyType: 'Apartment',
        address: 'Downtown',
        bedrooms: 2,
        bathrooms: 1,
        squareFootage: 1100,
        amenities: ['Fitness center', 'Rooftop deck', 'Concierge', 'City views'],
        utilities: ['Water', 'Garbage'],
        petsAllowed: false,
        smokingAllowed: false,
        availableFrom: DateTime.now(),
        leaseDuration: 12,
        contactName: 'Mike Johnson',
        contactPhone: '(555) 456-7890',
        contactEmail: 'mike@cityapts.com',
        createdAt: DateTime.now().subtract(Duration(hours: 12)),
        updatedAt: DateTime.now().subtract(Duration(hours: 12)),
        userId: 'landlord_1',
        furnished: false,
      ),
      RentalListing(
        id: '6',
        title: 'Cozy Studio Apartment',
        description: 'Charming studio apartment perfect for young professional or student. Recently updated with new flooring and paint.',
        monthlyRent: 1200,
        securityDeposit: 1200,
        imageUrls: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800'],
        propertyType: 'Studio',
        address: 'University District',
        bedrooms: 0,
        bathrooms: 1,
        squareFootage: 450,
        amenities: ['On-site laundry', 'Bike storage'],
        utilities: ['Water'],
        petsAllowed: false,
        smokingAllowed: false,
        availableFrom: DateTime.now().add(Duration(days: 7)),
        leaseDuration: 12,
        contactName: 'Lisa Wong',
        contactPhone: '(555) 567-8901',
        contactEmail: 'lisa@rentals.com',
        createdAt: DateTime.now().subtract(Duration(days: 4)),
        updatedAt: DateTime.now().subtract(Duration(days: 4)),
        userId: 'landlord_2',
        furnished: false,
      ),
    ];
  }

  // Search methods
  static Future<List<JobListing>> searchJobs(String query) async {
    final jobs = getSampleJobs();
    final lowercaseQuery = query.toLowerCase();
    
    return jobs.where((job) {
      return job.title.toLowerCase().contains(lowercaseQuery) ||
             job.description.toLowerCase().contains(lowercaseQuery) ||
             job.companyName.toLowerCase().contains(lowercaseQuery) ||
             job.location.toLowerCase().contains(lowercaseQuery);
    }).toList();
  }

  static Future<List<BusinessListing>> searchBusinesses(String query) async {
    final businesses = getSampleBusinesses();
    final lowercaseQuery = query.toLowerCase();
    
    return businesses.where((business) {
      return business.businessName.toLowerCase().contains(lowercaseQuery) ||
             business.description.toLowerCase().contains(lowercaseQuery) ||
             business.category.toLowerCase().contains(lowercaseQuery) ||
             business.address.toLowerCase().contains(lowercaseQuery);
    }).toList();
  }
}