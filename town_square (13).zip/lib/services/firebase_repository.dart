import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:town_square/services/firebase_service_manager.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';
import 'package:town_square/models/news_article.dart';
import 'package:town_square/models/video_news.dart';
import 'package:town_square/models/job_listing.dart';
import 'package:town_square/models/business_listing.dart';
import 'package:town_square/models/real_estate_listing.dart';
import 'package:town_square/models/rental_listing.dart';
import 'package:town_square/models/classified_listing.dart';

/// Firebase Repository
/// Centralized data access layer for all Firebase operations
/// Implements repository pattern for clean architecture
class FirebaseRepository {
  static final FirebaseRepository _instance = FirebaseRepository._internal();
  factory FirebaseRepository() => _instance;
  FirebaseRepository._internal();

  final FirebaseServiceManager _serviceManager = FirebaseServiceManager();

  // MARK: - News Articles
  
  /// Get all news articles with optional filtering
  Future<List<NewsArticle>> getNewsArticles({
    String? category,
    int limit = 20,
    String? searchQuery,
  }) async {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.newsArticles)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true);

      if (category != null && category.isNotEmpty) {
        query = query.where(FirestoreFields.category, isEqualTo: category);
      }

      query = query.limit(limit);

      QuerySnapshot snapshot = await query.get();
      return snapshot.docs.map((doc) {
        return NewsArticle.fromFirestore(doc);
      }).toList();
    } catch (e) {
      debugPrint('Error getting news articles: $e');
      return [];
    }
  }

  /// Get news articles stream for real-time updates
  Stream<List<NewsArticle>> getNewsArticlesStream({String? category}) {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.newsArticles)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .limit(20);

      if (category != null && category.isNotEmpty) {
        query = query.where(FirestoreFields.category, isEqualTo: category);
      }

      return query.snapshots().map((snapshot) {
        return snapshot.docs.map((doc) => NewsArticle.fromFirestore(doc)).toList();
      });
    } catch (e) {
      debugPrint('Error getting news articles stream: $e');
      return Stream.value([]);
    }
  }

  /// Add new news article
  Future<bool> addNewsArticle(NewsArticle article) async {
    try {
      await _serviceManager.addDocument(
        FirestoreCollections.newsArticles,
        article.toFirestore(),
      );
      return true;
    } catch (e) {
      debugPrint('Error adding news article: $e');
      return false;
    }
  }

  /// Update news article
  Future<bool> updateNewsArticle(String articleId, NewsArticle article) async {
    try {
      await _serviceManager.updateDocument(
        FirestoreCollections.newsArticles,
        articleId,
        article.toFirestore(),
      );
      return true;
    } catch (e) {
      debugPrint('Error updating news article: $e');
      return false;
    }
  }

  /// Delete news article
  Future<bool> deleteNewsArticle(String articleId) async {
    try {
      await _serviceManager.updateDocument(
        FirestoreCollections.newsArticles,
        articleId,
        {FirestoreFields.isActive: false},
      );
      return true;
    } catch (e) {
      debugPrint('Error deleting news article: $e');
      return false;
    }
  }

  // MARK: - Video News

  /// Get all video news with optional filtering
  Future<List<VideoNews>> getVideoNews({
    String? category,
    int limit = 20,
  }) async {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.videoNews)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true);

      if (category != null && category.isNotEmpty) {
        query = query.where(FirestoreFields.category, isEqualTo: category);
      }

      query = query.limit(limit);

      QuerySnapshot snapshot = await query.get();
      return snapshot.docs.map((doc) => VideoNews.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting video news: $e');
      return [];
    }
  }

  /// Get video news stream
  Stream<List<VideoNews>> getVideoNewsStream({String? category}) {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.videoNews)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.publishedAt, descending: true)
          .limit(20);

      if (category != null && category.isNotEmpty) {
        query = query.where(FirestoreFields.category, isEqualTo: category);
      }

      return query.snapshots().map((snapshot) {
        return snapshot.docs.map((doc) => VideoNews.fromFirestore(doc)).toList();
      });
    } catch (e) {
      debugPrint('Error getting video news stream: $e');
      return Stream.value([]);
    }
  }

  /// Add new video news
  Future<bool> addVideoNews(VideoNews videoNews) async {
    try {
      await _serviceManager.addDocument(
        FirestoreCollections.videoNews,
        videoNews.toFirestore(),
      );
      return true;
    } catch (e) {
      debugPrint('Error adding video news: $e');
      return false;
    }
  }

  // MARK: - Classified Listings

  /// Get all classified listings (aggregated from all types)
  Future<List<ClassifiedListing>> getAllListings({
    String? category,
    int limit = 20,
    bool? isPremium,
  }) async {
    try {
      List<ClassifiedListing> allListings = [];

      // Get from all listing collections
      final futures = [
        getJobListings(category: category, limit: limit),
        getBusinessListings(category: category, limit: limit),
        getRealEstateListings(limit: limit),
        getRentalListings(limit: limit),
      ];

      final results = await Future.wait(futures);
      
      // Combine all results
      for (var listings in results) {
        allListings.addAll(listings.cast<ClassifiedListing>());
      }

      // Sort by creation date
      allListings.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      // Filter by premium if specified
      if (isPremium != null) {
        allListings = allListings.where((listing) => listing.isPremium == isPremium).toList();
      }

      // Apply limit
      return allListings.take(limit).toList();
    } catch (e) {
      debugPrint('Error getting all listings: $e');
      return [];
    }
  }

  /// Get job listings
  Future<List<JobListing>> getJobListings({
    String? category,
    int limit = 20,
  }) async {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.jobListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true);

      if (category != null && category.isNotEmpty) {
        query = query.where(FirestoreFields.category, isEqualTo: category);
      }

      query = query.limit(limit);

      QuerySnapshot snapshot = await query.get();
      return snapshot.docs.map((doc) => JobListing.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting job listings: $e');
      return [];
    }
  }

  /// Get business listings
  Future<List<BusinessListing>> getBusinessListings({
    String? category,
    int limit = 20,
  }) async {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.businessListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true);

      if (category != null && category.isNotEmpty) {
        query = query.where(FirestoreFields.category, isEqualTo: category);
      }

      query = query.limit(limit);

      QuerySnapshot snapshot = await query.get();
      return snapshot.docs.map((doc) => BusinessListing.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting business listings: $e');
      return [];
    }
  }

  /// Get real estate listings
  Future<List<RealEstateListing>> getRealEstateListings({
    String? propertyType,
    int limit = 20,
  }) async {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.realEstateListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true);

      if (propertyType != null && propertyType.isNotEmpty) {
        query = query.where(FirestoreFields.type, isEqualTo: propertyType);
      }

      query = query.limit(limit);

      QuerySnapshot snapshot = await query.get();
      return snapshot.docs.map((doc) => RealEstateListing.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting real estate listings: $e');
      return [];
    }
  }

  /// Get rental listings
  Future<List<RentalListing>> getRentalListings({
    String? propertyType,
    int limit = 20,
  }) async {
    try {
      Query query = _serviceManager.getCollection(FirestoreCollections.rentalListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true);

      if (propertyType != null && propertyType.isNotEmpty) {
        query = query.where(FirestoreFields.type, isEqualTo: propertyType);
      }

      query = query.limit(limit);

      QuerySnapshot snapshot = await query.get();
      return snapshot.docs.map((doc) => RentalListing.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting rental listings: $e');
      return [];
    }
  }

  /// Add new classified listing
  Future<bool> addClassifiedListing(ClassifiedListing listing) async {
    try {
      String collection;
      Map<String, dynamic> data;

      // Determine collection and convert to appropriate type
      if (listing is JobListing) {
        collection = FirestoreCollections.jobListings;
        data = listing.toFirestore();
      } else if (listing is BusinessListing) {
        collection = FirestoreCollections.businessListings;
        data = listing.toFirestore();
      } else if (listing is RealEstateListing) {
        collection = FirestoreCollections.realEstateListings;
        data = listing.toFirestore();
      } else if (listing is RentalListing) {
        collection = FirestoreCollections.rentalListings;
        data = listing.toFirestore();
      } else {
        debugPrint('Unknown listing type');
        return false;
      }

      await _serviceManager.addDocument(collection, data);
      return true;
    } catch (e) {
      debugPrint('Error adding classified listing: $e');
      return false;
    }
  }

  /// Search listings across all types
  Future<List<ClassifiedListing>> searchListings(String searchQuery) async {
    try {
      // This is a simplified search - in production you'd use Algolia or similar
      List<ClassifiedListing> allListings = await getAllListings(limit: 100);
      
      searchQuery = searchQuery.toLowerCase();
      return allListings.where((listing) {
        return listing.title.toLowerCase().contains(searchQuery) ||
               listing.description.toLowerCase().contains(searchQuery);
      }).toList();
    } catch (e) {
      debugPrint('Error searching listings: $e');
      return [];
    }
  }

  // MARK: - Analytics & Admin

  /// Get analytics data for admin dashboard
  Future<Map<String, int>> getAnalyticsData() async {
    return await _serviceManager.getAnalyticsData();
  }

  /// Get recent activity for admin dashboard
  Future<List<Map<String, dynamic>>> getRecentActivity({int limit = 10}) async {
    try {
      // Get recent items from all collections
      final futures = [
        _serviceManager.getDocuments(FirestoreCollections.newsArticles, 
            orderBy: FirestoreFields.createdAt, descending: true, limit: 3),
        _serviceManager.getDocuments(FirestoreCollections.videoNews, 
            orderBy: FirestoreFields.createdAt, descending: true, limit: 3),
        _serviceManager.getDocuments(FirestoreCollections.jobListings, 
            orderBy: FirestoreFields.createdAt, descending: true, limit: 2),
        _serviceManager.getDocuments(FirestoreCollections.businessListings, 
            orderBy: FirestoreFields.createdAt, descending: true, limit: 2),
      ];

      final results = await Future.wait(futures);
      List<Map<String, dynamic>> activities = [];

      // Process results and create activity items
      for (int i = 0; i < results.length; i++) {
        String type = ['News Article', 'Video News', 'Job Listing', 'Business Listing'][i];
        for (var doc in results[i].docs.take(2)) {
          var data = doc.data() as Map<String, dynamic>;
          activities.add({
            'type': type,
            'title': data[FirestoreFields.title] ?? 'Untitled',
            'timestamp': data[FirestoreFields.createdAt] ?? Timestamp.now(),
            'id': doc.id,
          });
        }
      }

      // Sort by timestamp and limit
      activities.sort((a, b) => (b['timestamp'] as Timestamp).compareTo(a['timestamp']));
      return activities.take(limit).toList();
    } catch (e) {
      debugPrint('Error getting recent activity: $e');
      return [];
    }
  }

  // MARK: - User Management

  /// Get user bookmarks
  Future<List<String>> getUserBookmarks(String userId) async {
    try {
      var profileDoc = await _serviceManager.getUserProfile(userId);
      if (profileDoc?.exists == true) {
        var data = profileDoc!.data() as Map<String, dynamic>;
        return List<String>.from(data[FirestoreFields.bookmarks] ?? []);
      }
      return [];
    } catch (e) {
      debugPrint('Error getting user bookmarks: $e');
      return [];
    }
  }

  /// Add bookmark
  Future<bool> addBookmark(String userId, String itemId) async {
    try {
      var bookmarks = await getUserBookmarks(userId);
      if (!bookmarks.contains(itemId)) {
        bookmarks.add(itemId);
        await _serviceManager.setUserProfile(userId, {
          FirestoreFields.bookmarks: bookmarks,
        });
      }
      return true;
    } catch (e) {
      debugPrint('Error adding bookmark: $e');
      return false;
    }
  }

  /// Remove bookmark
  Future<bool> removeBookmark(String userId, String itemId) async {
    try {
      var bookmarks = await getUserBookmarks(userId);
      bookmarks.remove(itemId);
      await _serviceManager.setUserProfile(userId, {
        FirestoreFields.bookmarks: bookmarks,
      });
      return true;
    } catch (e) {
      debugPrint('Error removing bookmark: $e');
      return false;
    }
  }
}