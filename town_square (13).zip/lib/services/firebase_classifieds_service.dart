import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:town_square/models/job_listing.dart';
import 'package:town_square/models/business_listing.dart';
import 'package:town_square/models/real_estate_listing.dart';
import 'package:town_square/models/rental_listing.dart';
import 'package:town_square/models/classified_listing.dart';
import 'package:town_square/firestore/firestore_data_schema.dart';
import 'package:town_square/services/classifieds_service.dart'; // For fallback mock data

class FirebaseClassifiedsService {
  static final _firestore = FirebaseFirestore.instance;

  // Job Listings
  static Future<List<JobListing>> getJobs() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.jobListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return JobListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to mock data
      return ClassifiedsService.getSampleJobs();
    }
  }

  static Future<List<JobListing>> getJobsByCategory(String category) async {
    if (category == 'All') return getJobs();
    
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.jobListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.category, isEqualTo: category)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return JobListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allJobs = ClassifiedsService.getSampleJobs();
      return allJobs.where((job) => job.category == category).toList();
    }
  }

  static Future<List<JobListing>> getPremiumJobs() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.jobListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.isPremium, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return JobListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allJobs = ClassifiedsService.getSampleJobs();
      return allJobs.where((job) => job.isPremium).toList();
    }
  }

  // Business Listings
  static Future<List<BusinessListing>> getBusinesses() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.businessListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return BusinessListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to mock data
      return ClassifiedsService.getSampleBusinesses();
    }
  }

  static Future<List<BusinessListing>> getBusinessesByCategory(String category) async {
    if (category == 'All') return getBusinesses();
    
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.businessListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.category, isEqualTo: category)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return BusinessListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allBusinesses = ClassifiedsService.getSampleBusinesses();
      return allBusinesses.where((business) => business.category == category).toList();
    }
  }

  // Real Estate Listings
  static Future<List<RealEstateListing>> getRealEstate() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.realEstateListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return RealEstateListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to mock data
      return ClassifiedsService.getSampleRealEstate();
    }
  }

  static Future<List<RealEstateListing>> getRealEstateByType(String type) async {
    if (type == 'All') return getRealEstate();
    
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.realEstateListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.type, isEqualTo: type)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return RealEstateListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allRealEstate = ClassifiedsService.getSampleRealEstate();
      return allRealEstate.where((property) => property.propertyType == type).toList();
    }
  }

  // Rental Listings
  static Future<List<RentalListing>> getRentals() async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.rentalListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return RentalListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to mock data
      return ClassifiedsService.getSampleRentals();
    }
  }

  static Future<List<RentalListing>> getRentalsByType(String type) async {
    if (type == 'All') return getRentals();
    
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.rentalListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .where(FirestoreFields.type, isEqualTo: type)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      return querySnapshot.docs.map((doc) {
        final data = doc.data();
        return RentalListing.fromJson({...data, 'id': doc.id});
      }).toList();
    } catch (e) {
      // Fallback to filtered mock data
      final allRentals = ClassifiedsService.getSampleRentals();
      return allRentals.where((rental) => rental.propertyType == type).toList();
    }
  }

  // Search functionality
  static Future<List<JobListing>> searchJobs(String query) async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.jobListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      final lowercaseQuery = query.toLowerCase();
      final allJobs = querySnapshot.docs.map((doc) {
        final data = doc.data();
        return JobListing.fromJson({...data, 'id': doc.id});
      }).toList();

      return allJobs.where((job) {
        return job.title.toLowerCase().contains(lowercaseQuery) ||
               job.description.toLowerCase().contains(lowercaseQuery) ||
               job.companyName.toLowerCase().contains(lowercaseQuery) ||
               job.location.toLowerCase().contains(lowercaseQuery);
      }).toList();
    } catch (e) {
      // Fallback to mock data search
      return ClassifiedsService.searchJobs(query);
    }
  }

  static Future<List<BusinessListing>> searchBusinesses(String query) async {
    try {
      final querySnapshot = await _firestore
          .collection(FirestoreCollections.businessListings)
          .where(FirestoreFields.isActive, isEqualTo: true)
          .orderBy(FirestoreFields.createdAt, descending: true)
          .get();

      final lowercaseQuery = query.toLowerCase();
      final allBusinesses = querySnapshot.docs.map((doc) {
        final data = doc.data();
        return BusinessListing.fromJson({...data, 'id': doc.id});
      }).toList();

      return allBusinesses.where((business) {
        return business.businessName.toLowerCase().contains(lowercaseQuery) ||
               business.description.toLowerCase().contains(lowercaseQuery) ||
               business.category.toLowerCase().contains(lowercaseQuery) ||
               business.address.toLowerCase().contains(lowercaseQuery);
      }).toList();
    } catch (e) {
      // Fallback to mock data search
      return ClassifiedsService.searchBusinesses(query);
    }
  }

  // Add new listings (for user submissions)
  static Future<String> addJobListing(JobListing job) async {
    try {
      final docRef = await _firestore
          .collection(FirestoreCollections.jobListings)
          .add(job.toJson()..remove('id'));
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to add job listing: $e');
    }
  }

  static Future<String> addBusinessListing(BusinessListing business) async {
    try {
      final docRef = await _firestore
          .collection(FirestoreCollections.businessListings)
          .add(business.toJson()..remove('id'));
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to add business listing: $e');
    }
  }

  static Future<String> addRealEstateListing(RealEstateListing property) async {
    try {
      final docRef = await _firestore
          .collection(FirestoreCollections.realEstateListings)
          .add(property.toJson()..remove('id'));
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to add real estate listing: $e');
    }
  }

  static Future<String> addRentalListing(RentalListing rental) async {
    try {
      final docRef = await _firestore
          .collection(FirestoreCollections.rentalListings)
          .add(rental.toJson()..remove('id'));
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to add rental listing: $e');
    }
  }

  // Get single listings by ID
  static Future<JobListing?> getJobById(String id) async {
    try {
      final docSnapshot = await _firestore
          .collection(FirestoreCollections.jobListings)
          .doc(id)
          .get();

      if (!docSnapshot.exists) return null;

      final data = docSnapshot.data()!;
      return JobListing.fromJson({...data, 'id': docSnapshot.id});
    } catch (e) {
      // Fallback to mock data
      final mockJobs = ClassifiedsService.getSampleJobs();
      try {
        return mockJobs.firstWhere((job) => job.id == id);
      } catch (e) {
        return null;
      }
    }
  }

  static Future<BusinessListing?> getBusinessById(String id) async {
    try {
      final docSnapshot = await _firestore
          .collection(FirestoreCollections.businessListings)
          .doc(id)
          .get();

      if (!docSnapshot.exists) return null;

      final data = docSnapshot.data()!;
      return BusinessListing.fromJson({...data, 'id': docSnapshot.id});
    } catch (e) {
      // Fallback to mock data
      final mockBusinesses = ClassifiedsService.getSampleBusinesses();
      try {
        return mockBusinesses.firstWhere((business) => business.id == id);
      } catch (e) {
        return null;
      }
    }
  }

  static Future<RealEstateListing?> getRealEstateById(String id) async {
    try {
      final docSnapshot = await _firestore
          .collection(FirestoreCollections.realEstateListings)
          .doc(id)
          .get();

      if (!docSnapshot.exists) return null;

      final data = docSnapshot.data()!;
      return RealEstateListing.fromJson({...data, 'id': docSnapshot.id});
    } catch (e) {
      // Fallback to mock data
      final mockRealEstate = ClassifiedsService.getSampleRealEstate();
      try {
        return mockRealEstate.firstWhere((property) => property.id == id);
      } catch (e) {
        return null;
      }
    }
  }

  static Future<RentalListing?> getRentalById(String id) async {
    try {
      final docSnapshot = await _firestore
          .collection(FirestoreCollections.rentalListings)
          .doc(id)
          .get();

      if (!docSnapshot.exists) return null;

      final data = docSnapshot.data()!;
      return RentalListing.fromJson({...data, 'id': docSnapshot.id});
    } catch (e) {
      // Fallback to mock data
      final mockRentals = ClassifiedsService.getSampleRentals();
      try {
        return mockRentals.firstWhere((rental) => rental.id == id);
      } catch (e) {
        return null;
      }
    }
  }

  // Categories
  static List<String> getJobCategories() {
    return ['All', ...Categories.jobCategories];
  }

  static List<String> getBusinessCategories() {
    return ['All', ...Categories.businessCategories];
  }

  static List<String> getRealEstateTypes() {
    return ['All', ...Categories.realEstateTypes];
  }

  static List<String> getRentalTypes() {
    return ['All', ...Categories.rentalTypes];
  }

  // Combined methods for ClassifiedsService compatibility
  static Future<List<dynamic>> getAllListings() async {
    final List<dynamic> allListings = [];
    
    try {
      final jobs = await getJobs();
      final businesses = await getBusinesses();
      final realEstate = await getRealEstate();
      final rentals = await getRentals();
      
      // Convert specialized listings to ClassifiedListing objects
      allListings.addAll(jobs.map((job) => _convertToClassifiedListing(job)));
      allListings.addAll(businesses.map((business) => _convertToClassifiedListing(business)));
      allListings.addAll(realEstate.map((property) => _convertToClassifiedListing(property)));
      allListings.addAll(rentals.map((rental) => _convertToClassifiedListing(rental)));
      
      return allListings;
    } catch (e) {
      // Fallback to mock data
      final jobs = ClassifiedsService.getSampleJobs();
      final businesses = ClassifiedsService.getSampleBusinesses();
      final realEstate = ClassifiedsService.getSampleRealEstate();
      final rentals = ClassifiedsService.getSampleRentals();
      
      // Convert mock data to ClassifiedListing objects too
      allListings.addAll(jobs.map((job) => _convertToClassifiedListing(job)));
      allListings.addAll(businesses.map((business) => _convertToClassifiedListing(business)));
      allListings.addAll(realEstate.map((property) => _convertToClassifiedListing(property)));
      allListings.addAll(rentals.map((rental) => _convertToClassifiedListing(rental)));
      
      return allListings;
    }
  }

  static Future<List<dynamic>> getListingsByCategory(String category) async {
    if (category == 'All') return getAllListings();
    
    try {
      switch (category) {
        case 'Jobs':
          final jobs = await getJobs();
          return jobs.map((job) => _convertToClassifiedListing(job)).toList();
        case 'Business':
          final businesses = await getBusinesses();
          return businesses.map((business) => _convertToClassifiedListing(business)).toList();
        case 'Real Estate':
          final realEstate = await getRealEstate();
          return realEstate.map((property) => _convertToClassifiedListing(property)).toList();
        case 'Rentals':
          final rentals = await getRentals();
          return rentals.map((rental) => _convertToClassifiedListing(rental)).toList();
        default:
          return [];
      }
    } catch (e) {
      // Fallback to mock data
      final allListings = await getAllListings();
      return allListings.where((listing) {
        if (listing is JobListing) return category == 'Jobs';
        if (listing is BusinessListing) return category == 'Business';
        if (listing is RealEstateListing) return category == 'Real Estate';
        if (listing is RentalListing) return category == 'Rentals';
        return false;
      }).toList();
    }
  }

  // Helper method to convert specialized listings to ClassifiedListing
  static dynamic _convertToClassifiedListing(dynamic listing) {
    if (listing is JobListing) {
      return ClassifiedListing(
        id: listing.id,
        title: listing.title,
        description: listing.description,
        price: listing.salaryMin?.toDouble(),
        imageUrls: listing.imageUrls,
        category: 'Jobs',
        location: listing.location,
        contactName: listing.contactName,
        contactPhone: listing.contactPhone,
        contactEmail: listing.contactEmail,
        createdAt: listing.createdAt,
        isPremium: listing.isPremium,
        userId: listing.userId,
      );
    } else if (listing is BusinessListing) {
      return ClassifiedListing(
        id: listing.id,
        title: listing.businessName,
        description: listing.description,
        price: null,
        imageUrls: listing.imageUrls,
        category: 'Business',
        location: listing.address,
        contactName: listing.businessName,
        contactPhone: listing.phone,
        contactEmail: listing.email,
        createdAt: listing.createdAt,
        isPremium: listing.isPremium,
        userId: listing.userId,
      );
    } else if (listing is RealEstateListing) {
      return ClassifiedListing(
        id: listing.id,
        title: listing.title,
        description: listing.description,
        price: listing.price,
        imageUrls: listing.imageUrls,
        category: 'Real Estate',
        location: listing.address,
        contactName: listing.contactName,
        contactPhone: listing.contactPhone,
        contactEmail: listing.contactEmail,
        createdAt: listing.createdAt,
        isPremium: listing.isPremium,
        userId: listing.userId,
      );
    } else if (listing is RentalListing) {
      return ClassifiedListing(
        id: listing.id,
        title: listing.title,
        description: listing.description,
        price: listing.monthlyRent,
        imageUrls: listing.imageUrls,
        category: 'Rentals',
        location: listing.address,
        contactName: listing.contactName,
        contactPhone: listing.contactPhone,
        contactEmail: listing.contactEmail,
        createdAt: listing.createdAt,
        isPremium: false, // rental listings don't have isPremium by default
        userId: listing.userId,
      );
    }
    
    return listing; // Return as-is if already a ClassifiedListing or unknown type
  }
}