// This file has been replaced by simple_image_service.dart
// All imports should use 'package:town_square/services/simple_image_service.dart'

import 'simple_image_service.dart';

export 'simple_image_service.dart';

// For backward compatibility
class ImageUploadService {
  static ImageUploadService? _instance;
  factory ImageUploadService() {
    _instance ??= ImageUploadService._();
    return _instance!;
  }
  ImageUploadService._();
  
  // Redirect to new service
  static final _newService = SimpleImageService();
  
  Future<String?> pickAndUploadImage(String folder) {
    return _newService.pickAndUploadImage(folder);
  }
  
  Future<String?> uploadImage({
    required String path,
    required dynamic imageData,
  }) {
    return _newService.uploadImage(path: path, imageData: imageData);
  }
  
  Future<String?> uploadNewsImage(dynamic imageData) {
    return _newService.uploadNewsImage(imageData);
  }
  
  Future<String?> uploadClassifiedImage(dynamic imageData) {
    return _newService.uploadClassifiedImage(imageData);
  }
  
  Future<bool> deleteImage(String imageUrl) {
    return _newService.deleteImage(imageUrl);
  }
  
  // Mock methods for backward compatibility
  Future<bool> testStorageConnection() async {
    return true; // Always return true for now
  }
  
  Future<Map<String, dynamic>> getStorageInfo() async {
    return {'status': 'ok'};
  }
}

// For backward compatibility
class ImageFolders {
  static const String news = 'news';
  static const String classifieds = 'classifieds';
  static const String jobs = 'jobs';
  static const String business = 'business';
  static const String realEstate = 'real_estate';
  static const String rentals = 'rentals';
  static const String profiles = 'profiles';
  static const String avatars = 'avatars';
}