import 'package:shared_preferences/shared_preferences.dart';
import 'package:town_square/models/video_news.dart';
import 'package:town_square/services/firebase_video_news_service.dart';

class VideoNewsService {
  static const String _bookmarksKey = 'bookmarked_video_news';
  
  static List<VideoNews> getSampleVideoNews() {
    return [
      VideoNews(
        id: 'v1',
        title: 'Breaking: Major Climate Summit Reaches Historic Agreement',
        description: 'World leaders announce unprecedented climate action plan with binding commitments from 195 countries. This historic agreement aims to limit global warming to 1.5°C and transition to renewable energy by 2040.',
        thumbnailUrl: 'https://images.unsplash.com/photo-1569163139394-de44cb86f54a?w=800',
        videoId: 'QAnzy4YXxVw', // Climate change documentary
        category: 'Environment',
        source: 'Global News Network',
        publishedAt: DateTime.now().subtract(Duration(hours: 1)),
        duration: '4:05',
        viewCount: 1250000,
        channelName: 'Global News Network',
      ),
      VideoNews(
        id: 'v2',
        title: 'Technology Giants Unveil Revolutionary AI Partnership',
        description: 'Major tech companies announce collaboration on ethical AI development. The partnership aims to create industry standards and ensure responsible AI deployment across various sectors.',
        thumbnailUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
        videoId: 'kCc8FmEb1nY', // AI and technology content
        category: 'Technology',
        source: 'Tech World Today',
        publishedAt: DateTime.now().subtract(Duration(hours: 3)),
        duration: '3:09',
        viewCount: 890000,
        channelName: 'Tech World Today',
      ),
      VideoNews(
        id: 'v3',
        title: 'Championship Victory: Stunning Overtime Finish',
        description: 'Witness the incredible championship game that had fans on the edge of their seats. The winning play came in the final seconds of overtime in what many are calling the game of the decade.',
        thumbnailUrl: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800',
        videoId: 'gG_dA32oH44', // Sports highlights content
        category: 'Sports',
        source: 'Sports Central',
        publishedAt: DateTime.now().subtract(Duration(hours: 6)),
        duration: '5:12',
        viewCount: 2100000,
        channelName: 'Sports Central',
      ),
      VideoNews(
        id: 'v4',
        title: 'Market Analysis: Economic Recovery Accelerates',
        description: 'Financial experts analyze the latest economic indicators showing strong growth across multiple sectors. The recovery appears to be gaining momentum with unemployment at historic lows.',
        thumbnailUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800',
        videoId: 'PHe0bXAIuk0', // Economics and finance content
        category: 'Business',
        source: 'Financial Report',
        publishedAt: DateTime.now().subtract(Duration(hours: 12)),
        duration: '2:36',
        viewCount: 456000,
        channelName: 'Financial Report',
      ),
      VideoNews(
        id: 'v5',
        title: 'Medical Breakthrough: New Treatment Shows Promise',
        description: 'Researchers announce promising results from clinical trials of a new treatment that could revolutionize healthcare. The breakthrough offers hope for millions of patients worldwide.',
        thumbnailUrl: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800',
        videoId: 'YQZ-lHEodBg', // Medical and health content
        category: 'Health',
        source: 'Medical News',
        publishedAt: DateTime.now().subtract(Duration(days: 1)),
        duration: '3:18',
        viewCount: 678000,
        channelName: 'Medical News',
      ),
      VideoNews(
        id: 'v6',
        title: 'Space Mission Success: Historic Mars Landing',
        description: 'Watch the historic moment as the latest Mars rover successfully lands on the Red Planet. This mission promises to unlock new secrets about our neighboring planet and search for signs of ancient life.',
        thumbnailUrl: 'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800',
        videoId: '4czjS9h4Fpg', // Space and science content
        category: 'Science',
        source: 'Space Today',
        publishedAt: DateTime.now().subtract(Duration(days: 2)),
        duration: '4:36',
        viewCount: 3200000,
        channelName: 'Space Today',
      ),
    ];
  }

  static Future<List<VideoNews>> getVideoNews() async {
    try {
      // Try Firebase first
      return await FirebaseVideoNewsService.getVideoNews();
    } catch (e) {
      // Fallback to mock data if Firebase is not available
      final prefs = await SharedPreferences.getInstance();
      final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
      
      return getSampleVideoNews().map((video) {
        return video.copyWith(isBookmarked: bookmarkedIds.contains(video.id));
      }).toList();
    }
  }

  static Future<List<VideoNews>> getVideoNewsByCategory(String category) async {
    try {
      // Try Firebase first
      return await FirebaseVideoNewsService.getVideoNewsByCategory(category);
    } catch (e) {
      // Fallback to mock data
      final allVideos = await getVideoNews();
      if (category == 'All') return allVideos;
      return allVideos.where((video) => video.category == category).toList();
    }
  }

  static Future<List<VideoNews>> getBookmarkedVideoNews() async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
    final allVideos = getSampleVideoNews();
    
    return allVideos.where((video) => bookmarkedIds.contains(video.id)).toList();
  }

  static Future<void> toggleBookmark(String videoId) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarkedIds = prefs.getStringList(_bookmarksKey) ?? [];
    
    if (bookmarkedIds.contains(videoId)) {
      bookmarkedIds.remove(videoId);
    } else {
      bookmarkedIds.add(videoId);
    }
    
    await prefs.setStringList(_bookmarksKey, bookmarkedIds);
  }

  static Future<List<VideoNews>> searchVideoNews(String query) async {
    final allVideos = await getVideoNews();
    final lowercaseQuery = query.toLowerCase();
    
    return allVideos.where((video) {
      return video.title.toLowerCase().contains(lowercaseQuery) ||
             video.description.toLowerCase().contains(lowercaseQuery) ||
             video.category.toLowerCase().contains(lowercaseQuery);
    }).toList();
  }

  static List<String> getCategories() {
    return ['All', 'Technology', 'Business', 'Sports', 'Environment', 'Health', 'Science'];
  }
}