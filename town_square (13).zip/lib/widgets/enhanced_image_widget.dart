import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:town_square/utils/image_utils.dart';

/// Enhanced Image Widget with proper error handling, caching, and loading states
/// Handles network images with fallbacks and placeholders
class EnhancedImageWidget extends StatelessWidget {
  final String? imageUrl;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius? borderRadius;
  final IconData? placeholderIcon;
  final String? placeholderText;
  final Color? placeholderColor;
  final bool showLoadingIndicator;

  const EnhancedImageWidget({
    super.key,
    this.imageUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius,
    this.placeholderIcon,
    this.placeholderText,
    this.placeholderColor,
    this.showLoadingIndicator = true,
  });

  @override
  Widget build(BuildContext context) {
    // If no URL provided, show placeholder immediately
    if (imageUrl == null || imageUrl!.isEmpty) {
      return _buildPlaceholder(context);
    }

    // Validate and optimize image URL
    final validImageUrl = ImageUtils.getValidImageUrl(imageUrl);
    
    // If no valid URL, show placeholder immediately
    if (validImageUrl.isEmpty) {
      debugPrint('⚠️ No valid image URL, showing placeholder for: $imageUrl');
      return _buildPlaceholder(context);
    }
    
    debugPrint('🇿 Building image widget for: $validImageUrl');

    // Use different image loading strategy for web vs mobile
    final Widget widget;
    
    if (kIsWeb) {
      // For web, use Image.network for better compatibility
      widget = Image.network(
        validImageUrl,
        width: width,
        height: height,
        fit: fit,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) {
            debugPrint('✅ Image loaded successfully: $validImageUrl');
            return child;
          }
          return showLoadingIndicator ? _buildLoadingIndicator(context) : const SizedBox();
        },
        errorBuilder: (context, error, stackTrace) {
          debugPrint('❌ Image failed to load: $validImageUrl - Error: $error');
          return _buildErrorWidget(context, error);
        },
      );
    } else {
      // For mobile, use CachedNetworkImage for better performance
      widget = CachedNetworkImage(
        imageUrl: validImageUrl,
        width: width,
        height: height,
        fit: fit,
        placeholder: showLoadingIndicator 
          ? (context, url) => _buildLoadingIndicator(context)
          : null,
        errorWidget: (context, url, error) {
          debugPrint('❌ Cached image failed to load: $validImageUrl - Error: $error');
          return _buildErrorWidget(context, error);
        },
        fadeInDuration: const Duration(milliseconds: 300),
        fadeOutDuration: const Duration(milliseconds: 300),
        httpHeaders: {
          'User-Agent': 'Mozilla/5.0 (compatible; TownSquareApp)',
        },
      );
    }

    return borderRadius != null
        ? ClipRRect(borderRadius: borderRadius!, child: widget)
        : widget;
  }

  Widget _buildLoadingIndicator(BuildContext context) {
    return Container(
      width: width,
      height: height,
      color: placeholderColor ?? Theme.of(context).colorScheme.surfaceContainer,
      child: Center(
        child: SizedBox(
          width: 30,
          height: 30,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(
              Theme.of(context).colorScheme.primary.withValues(alpha: 0.6),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlaceholder(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: placeholderColor ?? Theme.of(context).colorScheme.surfaceContainer,
        borderRadius: borderRadius,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            placeholderIcon ?? Icons.image_outlined,
            size: (height != null && height! < 100) ? 24 : 40,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.4),
          ),
          if (placeholderText != null) ...[
            const SizedBox(height: 8),
            Text(
              placeholderText!,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                fontSize: (height != null && height! < 100) ? 12 : 14,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildErrorWidget(BuildContext context, dynamic error) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: placeholderColor ?? Theme.of(context).colorScheme.errorContainer.withValues(alpha: 0.1),
        borderRadius: borderRadius,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.broken_image_outlined,
            size: (height != null && height! < 100) ? 24 : 40,
            color: Theme.of(context).colorScheme.error.withValues(alpha: 0.6),
          ),
          const SizedBox(height: 8),
          Text(
            'Image failed to load',
            style: TextStyle(
              color: Theme.of(context).colorScheme.error.withValues(alpha: 0.8),
              fontSize: (height != null && height! < 100) ? 10 : 12,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// Network Image with Enhanced Error Handling
/// A simple wrapper around Image.network with consistent error handling
class NetworkImageWithFallback extends StatelessWidget {
  final String? imageUrl;
  final double? width;
  final double? height;
  final BoxFit fit;
  final IconData? fallbackIcon;
  final String? fallbackText;

  const NetworkImageWithFallback({
    super.key,
    this.imageUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.fallbackIcon,
    this.fallbackText,
  });

  @override
  Widget build(BuildContext context) {
    if (imageUrl == null || imageUrl!.isEmpty) {
      debugPrint('🚫 No image URL provided, showing fallback');
      return _buildFallback(context);
    }

    // Validate URL using ImageUtils
    if (!ImageUtils.isValidImageUrl(imageUrl)) {
      debugPrint('❌ Invalid image URL, showing fallback: $imageUrl');
      return _buildFallback(context);
    }

    debugPrint('🖼️ Loading image: $imageUrl');

    return Image.network(
      imageUrl!,
      width: width,
      height: height,
      fit: fit,
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) {
          debugPrint('✅ Image loaded successfully: $imageUrl');
          return child;
        }
        return Container(
          width: width,
          height: height,
          color: Theme.of(context).colorScheme.surfaceContainer,
          child: Center(
            child: SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                value: loadingProgress.expectedTotalBytes != null
                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                    : null,
              ),
            ),
          ),
        );
      },
      errorBuilder: (context, error, stackTrace) {
        debugPrint('❌ Image failed to load: $imageUrl - Error: $error');
        return _buildFallback(context);
      },
    );
  }

  Widget _buildFallback(BuildContext context) {
    return Container(
      width: width,
      height: height,
      color: Theme.of(context).colorScheme.surfaceContainer,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            fallbackIcon ?? Icons.broken_image_outlined,
            size: (height != null && height! < 100) ? 24 : 40,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.4),
          ),
          if (fallbackText != null) ...[
            const SizedBox(height: 8),
            Text(
              fallbackText!,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}