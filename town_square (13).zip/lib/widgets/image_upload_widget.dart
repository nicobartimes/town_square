import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:town_square/services/image_upload_service.dart';
import 'package:town_square/widgets/enhanced_image_widget.dart';

class ImageUploadWidget extends StatefulWidget {
  final String? initialImageUrl;
  final String folder;
  final String fileName;
  final Function(String?) onImageChanged;
  final double width;
  final double height;
  final String? placeholder;
  final bool required;

  const ImageUploadWidget({
    super.key,
    this.initialImageUrl,
    required this.folder,
    required this.fileName,
    required this.onImageChanged,
    this.width = 200,
    this.height = 150,
    this.placeholder,
    this.required = false,
  });

  @override
  State<ImageUploadWidget> createState() => _ImageUploadWidgetState();
}

class _ImageUploadWidgetState extends State<ImageUploadWidget> {
  String? _currentImageUrl;
  bool _isUploading = false;
  final ImageUploadService _imageService = ImageUploadService();
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _currentImageUrl = widget.initialImageUrl;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.3),
          width: 2,
          style: BorderStyle.solid,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Stack(
        children: [
          // Image display
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: _buildImageContent(),
            ),
          ),
          
          // Upload overlay
          if (_isUploading)
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Colors.white),
                      SizedBox(height: 8),
                      Text(
                        'Uploading...',
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          
          // Action buttons
          if (!_isUploading)
            Positioned(
              top: 8,
              right: 8,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Upload button
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      onPressed: _showImageSourceDialog,
                      icon: const Icon(Icons.upload, color: Colors.white),
                      tooltip: 'Upload Image',
                      constraints: const BoxConstraints(
                        minWidth: 36,
                        minHeight: 36,
                      ),
                      padding: const EdgeInsets.all(6),
                    ),
                  ),
                  
                  // Delete button (only if image exists)
                  if (_currentImageUrl != null) ...[
                    const SizedBox(width: 4),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: 0.8),
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        onPressed: _removeImage,
                        icon: const Icon(Icons.delete, color: Colors.white),
                        tooltip: 'Remove Image',
                        constraints: const BoxConstraints(
                          minWidth: 36,
                          minHeight: 36,
                        ),
                        padding: const EdgeInsets.all(6),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          
          // Upload prompt (when no image)
          if (_currentImageUrl == null && !_isUploading)
            Positioned.fill(
              child: InkWell(
                onTap: _showImageSourceDialog,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.cloud_upload_outlined,
                        size: 48,
                        color: Colors.grey.withValues(alpha: 0.6),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.placeholder ?? 'Tap to upload image',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.grey.withValues(alpha: 0.8),
                          fontSize: 14,
                        ),
                      ),
                      if (widget.required)
                        const Text(
                          '*Required',
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 12,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildImageContent() {
    if (_currentImageUrl == null) {
      return Container(
        color: Colors.grey.withValues(alpha: 0.1),
      );
    }

    return NetworkImageWithFallback(
      imageUrl: _currentImageUrl!,
      width: widget.width,
      height: widget.height,
      fit: BoxFit.cover,
      fallbackIcon: Icons.image,
      fallbackText: 'Image',
    );
  }

  Future<void> _showImageSourceDialog() async {
    if (kIsWeb) {
      // On web, directly pick from gallery
      await _pickFromGallery();
      return;
    }

    // On mobile, show options
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickFromGallery();
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _takePhoto();
              },
            ),
            ListTile(
              leading: const Icon(Icons.cancel),
              title: const Text('Cancel'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickFromGallery() async {
    setState(() => _isUploading = true);
    
    try {
      final url = await _imageService.pickAndUploadImage(widget.folder);
      
      if (url != null) {
        setState(() => _currentImageUrl = url);
        widget.onImageChanged(url);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ Image uploaded successfully!'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception('Upload failed - no URL returned');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Failed to upload image: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _pickFromGallery,
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  Future<void> _takePhoto() async {
    setState(() => _isUploading = true);
    
    try {
      final XFile? photo = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
      );

      if (photo == null) return;

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = '${widget.folder}/photo_$timestamp.jpg';
      
      final url = await _imageService.uploadImage(
        path: fileName,
        imageData: photo,
      );
      
      if (url != null) {
        setState(() => _currentImageUrl = url);
        widget.onImageChanged(url);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ Photo uploaded successfully!'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception('Upload failed - no URL returned');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Failed to upload photo: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _takePhoto,
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  void _removeImage() {
    setState(() => _currentImageUrl = null);
    widget.onImageChanged(null);
  }
}